# TTS Studio -- Architecture &amp; Engine Research

Researched and written August 2026. Every license/status claim below was
checked against current sources (GitHub repos, PyPI, Hugging Face model
cards) rather than recalled from memory -- this space moves fast and
several load-bearing facts changed in the last year (see the Piper and
Qwen3-TTS entries especially).

> **Current implementation status: V4**, not V1, V2, or V3. Sections A-F
> below are the original research and design decisions and are still
> accurate as written. Sections G-J originally described the V1-only
> delivery, then were updated for V2 (document import beyond `.txt`,
> user-facing chunk-mode/length controls, a per-section table with
> independent translation editing and regeneration, MP3/FLAC/OGG export,
> and project save/load), then for V3: an in-app Download Manager for
> Argos language packages, Piper voices, and the Kokoro voice pack
> (replacing the manual steps V2's README described); Kokoro "character"
> presets (voice-style blending); real DirectML GPU wiring for Kokoro;
> and automatic espeak-ng installation via the Windows installer. A
> second, optional translation engine (LibreTranslate, talked to over
> HTTP) was added during V3 and then removed again by request -- Argos
> remains the sole translation engine; see section C and section J. V4
> adds this app's first voice-cloning engine, **Chatterbox** (MIT-licensed),
> installed by default rather than as an opt-in -- see sections B, F, H,
> and I for what that trade-off costs in install size. Those sections have been
> updated below to describe what's actually here -- see README.md for
> the current, accurate feature list and setup steps.

---

## A. Recommended architecture

**Ports and adapters (hexagonal architecture).** Two abstract interfaces,
`TranslationEngine` and `TTSEngine` (`tts_studio/core/interfaces.py`), are
the *only* thing the GUI and Core layers depend on. Concrete engines
(Argos, Piper, Kokoro, and anything added later) implement one of these
interfaces in `tts_studio/engines/` and register themselves with a small
`EngineRegistry` (`tts_studio/core/engine_registry.py`). Nothing outside
`engines/` imports an engine's actual package -- that boundary is what
lets a new engine be added by writing one file and one registration line,
with zero changes to the GUI, exactly per the brief.

```
GUI  --calls-->  TranslationEngine / TTSEngine (abstract)
                          ^                    ^
                          |                    |
                 ArgosTranslationEngine   PiperTTSEngine, KokoroTTSEngine
                 (engines/translation/)   (engines/tts/)
```

Supporting modules that are engine-agnostic by design:

- **TextChunker** (`text_processing/chunker.py`) -- paragraph/sentence/
  automatic/custom splitting. Hand-written rather than built on a
  dependency; see section I for why.
- **AudioProcessor** (`audio/audio_processor.py`) -- joining, format
  export. Knows nothing about TTS engines, only about `(samples,
  sample_rate)` tuples and file paths.
- **EngineRegistry** -- the extension point.
- **AppSettings** -- plain JSON, not tied to Qt.

Voice *capabilities* (speed/pitch/volume/cloning support) live on the
`Voice` dataclass itself, not hard-coded per engine in the GUI. The TTS
panel reads `voice.supports_pitch` etc. and shows/hides controls
accordingly -- this is what satisfies "don't show cloning controls for an
engine that can't clone" without an `if engine == "xtts"` anywhere in the
GUI code.

---

## B. Best open-source TTS engines

| Engine | Code license | Weights license | Commercial use | Windows | GPU/CPU | Voice cloning | Status (checked Aug 2026) |
|---|---|---|---|---|---|---|---|
| **Kokoro-82M** (hexgrad) | Apache-2.0 (inference lib) | **Apache-2.0** | Yes, explicitly welcomed | Yes (`kokoro-onnx`, pure onnxruntime) | CPU-friendly, ~5x realtime on Apple Silicon CPU; GPU via `onnxruntime-gpu`/DirectML | No | Active. v1.0 (Jan 2025), 82M params, 54 voices/8 languages, #1 on TTS Arena at launch |
| **Piper** (OHF-Voice/piper1-gpl) | **GPL-3.0** (changed! see below) | Per-voice, mostly permissive | Yes for the engine; check each voice | Yes, official wheels | CPU real-time even on a Raspberry Pi; `--cuda` optional | No | Active, frequent releases (v1.6.0 as of this writing) |
| ~~Piper~~ (rhasspy/piper, old) | MIT | -- | -- | Standalone `piper.exe` build exists | -- | No | **Archived Oct 2025, unmaintained.** Don't build on this one |
| **Coqui XTTS-v2** | MPL-2.0 (code) | **CPML -- non-commercial only** | **No**, and no one is left to sell a commercial license (Coqui Inc. shut down Jan 2024) | Via community fork `idiap/coqui-ai-TTS` | GPU strongly recommended | Yes, ~6s reference clip | Community-maintained fork only |
| **Chatterbox** (Resemble AI) | **MIT** | **MIT** | Yes | Yes | GPU recommended (6GB+ VRAM); "Nano" (110M) runs ~3x realtime on 8 CPU cores | Yes, ~5-10s reference clip | Active; Multilingual V3 (23 languages), Turbo, Nano variants |
| **F5-TTS** | MIT (code) | **CC-BY-NC-4.0 -- non-commercial** (Emilia dataset restriction) | **No** for the official checkpoints | Yes | GPU recommended | Yes | Active research project; `OpenF5-TTS-Base` (Apache-2.0, alpha quality) is the commercial-friendly variant if needed later |
| **Qwen3-TTS** (Alibaba) | **Apache-2.0** | **Apache-2.0** | Yes | Yes (transformers/onnx; GGUF port exists) | GPU recommended for the 0.6B/1.7B models; LM-based architecture, heavier than Kokoro/Piper | Yes, plus text-described "voice design" | **New** -- released ~Jan 22, 2026. Genuinely promising for V3+: permissive license *and* cloning, but bigger (2.5-4.5GB) and less battle-tested than Kokoro/Piper |

**V1 choice: Piper + Kokoro.** Both are small, CPU-friendly, offline, and
between them cover "no dependencies, fast, good quality" (Kokoro) and
"broadest language/voice selection, tiny footprint" (Piper). Neither does
voice cloning, which is fine -- cloning is explicitly a V4 feature.

**V4 choice: Chatterbox, as the first cloning engine.** Both code and
weights are MIT (verified against the repo's `LICENSE` file and the
`ResembleAI/chatterbox` Hugging Face model card, not assumed), it's the
most battle-tested of the cloning-capable options (Resemble AI, frequent
releases), and its Nano variant can run on CPU if no GPU is present --
consistent with this app's "works offline, degrades to CPU" philosophy
elsewhere. It was initially shipped as an opt-in `pip install
chatterbox-tts` engine specifically because it pulls PyTorch/torchaudio,
the multi-gigabyte dependency V1-V3 avoided requiring by default -- but
that meant the Engine dropdown showed Chatterbox as "(not installed)"
until someone ran that separate command, which in practice meant most
people couldn't actually use the feature this section just finished
justifying. The fix (see section F) is installed-by-default, but NOT via
a normal `requirements.txt` entry: `chatterbox-tts` turned out to pin
`numpy<2.0.0`, a hard conflict with `kokoro-onnx`'s `numpy>=2.0.2` that
makes the two genuinely unable to share one Python environment. Chatterbox
now gets its own environment (`.venv-chatterbox`) instead, installed
automatically by `windows_install.ps1` as a non-fatal step, with
`chatterbox_engine.py` talking to it over a subprocess.

**Important correction vs. older write-ups:** many guides (and Piper's
own reputation) say "Piper is MIT." That was true of the original
rhasspy/piper repo, which is now **archived and unmaintained**. The
actively developed continuation, OHF-Voice/piper1-gpl, is **GPL-3.0**.
This app works around that by running Piper as a subprocess instead of
importing it in-process -- see section I and the docstring in
`piper_engine.py`.

**Not chosen for V1, and why:**
- **XTTS-v2** -- best-known cloning model, but CPML weights are
  non-commercial with no one left to grant a commercial license. Still
  a candidate to *offer* with a loud license warning, not a default.
- **Chatterbox** -- not V1-appropriate given V1's "no PyTorch,
  CPU-first" default goal; became V4's first cloning engine once the
  in-app Download Manager (V3) existed to make an optional, heavier
  engine a comfortable add-on rather than a required install. See the
  "V4 choice" note above.
- **F5-TTS** -- non-commercial weights rule it out as a default; the
  Apache-2.0 `OpenF5-TTS-Base` variant is explicitly alpha-quality.
- **Qwen3-TTS** -- excellent license and feature set, but brand new
  (released after most of this app's other dependencies), heavier, and
  still staged for a future version once it has more track record in
  the wild -- see section J.

---

## C. Best open-source translation engines

| Engine | License | Offline | Windows/Python | Notes |
|---|---|---|---|---|
| **Argos Translate** | **MIT / CC0** (dual) | Yes, fully | Yes, pure Python (CTranslate2+OpenNMT under the hood) | **V1 choice.** Simple library call, no server process, automatic pivot translation (es→fr via en if no direct package exists) |
| **LibreTranslate** | **AGPL-3.0** | Yes (wraps Argos models) | Yes, but runs as a self-hosted server | Same translation quality as Argos (it's built on it) with an HTTP layer on top. Built as a V3 second engine, then removed by request -- see the note below the table |
| **NLLB-200** (Meta) | Code: MIT (fairseq) | Weights: **CC-BY-NC-4.0 -- non-commercial** | Yes | Broadest language coverage (200 languages) but ruled out as a default by the non-commercial weight license |
| **Marian / Helsinki-NLP OPUS-MT** | Marian: MIT. Models: tagged **Apache-2.0** on Hugging Face (project docs also cite CC-BY 4.0 for the same models -- both permit commercial use, CC-BY additionally wants attribution) | Yes | Yes | Good permissively-licensed option for language pairs Argos doesn't cover well; solid **V3** addition, not needed for V1 |

**V1 choice: Argos Translate only.** It is the simplest fully-offline,
fully-permissive option and is what LibreTranslate itself is built on --
adding LibreTranslate's AGPL-3.0 HTTP server on top would add moving
parts (a background process, port management, health checks) without
improving translation quality for a single-user desktop app.

**V3 update: LibreTranslate was added, then removed again.** It shipped
briefly as an optional second engine (an HTTP client, talked to over
plain sockets, never imported or bundled). In practice it added a real
usability cost -- a server most users don't have running, an extra engine
picker, and failure modes (unreachable server, stale capability guesses)
that don't exist with Argos -- for a translation-quality benefit Argos
already provides on its own. It was removed by explicit request; Argos is
again the sole, fully-offline translation engine. The evaluation above
and the architectural lessons from having built it (see section I) are
kept as a historical record in case a pluggable "translation server"
story is worth revisiting later.

---

## D. Recommended technology stack

| Layer | Choice | Why |
|---|---|---|
| Language | Python 3.12 | Required by current Lingua releases and supported by the Windows TTS dependencies |
| GUI | **PySide6** (kept, as requested to justify) | LGPLv3 -- unlike PyQt6 (GPL/commercial), LGPL does not require *your* application's source to be shared if you distribute it, only changes to Qt/PySide itself. That matters more here than usual because Piper (a runtime dependency) is already GPL-3.0; keeping the GUI toolkit itself unencumbered avoids compounding the licensing question. Official Qt bindings, native Windows look, mature. Tkinter/wxPython were considered and rejected: neither has PySide6's modern styling or media-playback support (`QtMultimedia`) needed for the audio preview |
| TTS runtime | **onnxruntime** (via Piper + kokoro-onnx) | Both V1 engines share one runtime instead of two, and it's a fraction of PyTorch's install size. GPU support (CUDA/DirectML) still available via `onnxruntime-gpu`; PyTorch wasn't a V1 requirement at all -- it only entered the picture once V4 added Chatterbox, and (per section F) is now installed by default rather than reserved as opt-in |
| Translation | Argos Translate | See section C |
| Audio I/O | `soundfile` (libsndfile) + `numpy` | Native WAV/FLAC/OGG read/write with no FFmpeg dependency; FFmpeg is reserved for MP3 specifically (V2) |
| Sentence/paragraph splitting | Hand-written (`text_processing/chunker.py`) | See section I -- the obvious dependency (`pysbd`) turned out to be unmaintained with an unresolved hang bug |
| Language ID | `lingua-language-detector` | Apache-2.0, offline, no model download, good accuracy even on short pasted text, actively maintained |
| Packaging (future) | PyInstaller or `pyside6-deploy` | Not implemented in V1; noted for the eventual "distributable .exe" goal |

---

## E. Project directory structure

```
tts_studio/
├── README.md                      Windows setup + run instructions
├── ARCHITECTURE.md                This document
├── requirements.txt
├── run.py                         Entry point: `python run.py`
├── Install TTS Studio.cmd         Windows installer entry point
├── Run TTS Studio.cmd             Windows launcher (after install)
├── windows_install.ps1            Does the actual installing
├── models/
│   ├── piper/                     Drop <voice>.onnx + <voice>.onnx.json here
│   └── kokoro/                    Drop kokoro-v1.0.onnx + voices-v1.0.bin here
└── tts_studio/
    ├── core/
    │   ├── models.py              Voice, SynthesisSettings, TextSection, Project, ...
    │   ├── interfaces.py          TranslationEngine, TTSEngine (the two ports)
    │   ├── exceptions.py          User-facing error hierarchy
    │   ├── engine_registry.py     Extension point for new engines
    │   └── device.py              CPU/GPU (onnxruntime provider) detection
    ├── engines/
    │   ├── translation/
    │   │   └── argos_engine.py    Sole translation engine (see section C on
    │   │                          LibreTranslate, added then removed in V3)
    │   └── tts/
    │       ├── piper_engine.py    Subprocess adapter (see licensing note)
    │       ├── kokoro_engine.py   In-process adapter; V3 adds character-preset
    │       │                      voice blending and DirectML session wiring
    │       ├── chatterbox_engine.py  V4: voice-cloning adapter (MIT). Talks to
    │       │                      a SEPARATE .venv-chatterbox environment over
    │       │                      a PERSISTENT subprocess (started once, reused
    │       │                      across calls, shut down on engine switch/app
    │       │                      close) -- not imported in-process like Kokoro
    │       │                      because of a numpy version conflict with
    │       │                      kokoro-onnx, not a licensing reason. Exposes
    │       │                      3 model tiers (Nano/Turbo/Original) as
    │       │                      ordinary Voice entries
    │       └── _chatterbox_worker.py  Runs INSIDE .venv-chatterbox, never
    │                              imported by the main app; the only file that
    │                              actually imports chatterbox/torch. Persistent
    │                              JSON-lines request loop, plus one-shot
    │                              --diagnose and --download-only CLI modes
    ├── text_processing/
    │   ├── chunker.py             Sentence/paragraph/automatic/custom splitting
    │   ├── language_id.py         lingua wrapper
    │   └── document_import.py     .txt/.md/.docx/.pdf -> plain text
    ├── audio/
    │   └── audio_processor.py     Join, resample; WAV/FLAC via soundfile,
    │                              MP3/OGG via FFmpeg
    ├── project/
    │   └── project_manager.py     Save/load a project directory (see below)
    ├── gui/
    │   ├── main_window.py         The only module that talks to both GUI and engines
    │   ├── workers.py             QThread workers (detection, translation, synthesis)
    │   ├── resource_manager.py    V3: LanguageManagerDialog (Argos packages) and
    │   │                          VoiceManagerDialog (Piper/Kokoro) -- deliberately
    │   │                          separate dialogs, not tabs in one, so the languages
    │   │                          button can never surface voice-download controls
    │   └── panels/
    │       ├── source_panel.py        Areas 1-2: source text, import, language, chunk mode
    │       ├── translation_panel.py   Area 3: target language picker,
    │       │                          "Download Languages..." (V3)
    │       ├── sections_panel.py      Per-section table: editable translation,
    │       │                          status, Regenerate, Translate All / Generate All
    │       ├── tts_panel.py           Areas 5-7: engine/voice/speed/volume/pitch/character,
    │       │                          "Download Voices..." (V3), reference-audio
    │       │                          picker for cloning-capable voices (V4)
    │       └── output_panel.py        Areas 8-9: preview + WAV/MP3/FLAC/OGG export
    └── settings/
        └── app_settings.py        Plain-JSON settings (not QSettings, toolkit-independent)
```

Project save/load (area 10 of the GUI spec) is fully wired up:
`project/project_manager.py` serializes `core/models.py::Project` to the
`project.json` + `source.txt` + `translation.txt` + `audio/` layout
described in the brief, and `MainWindow`'s File menu (New/Open/Save/Save
As) drives it.

---

## F. Dependency list

See `requirements.txt` for exact pins. Summary with the "why this one"
reasoning inline:

- **PySide6** &ndash; GUI (section D)
- **numpy**, **soundfile** &ndash; audio arrays and WAV/FLAC I/O
- **argostranslate** &ndash; translation (section C)
- **piper-tts** &ndash; one of three TTS engines, run as a subprocess
- **kokoro-onnx** &ndash; another TTS engine, run in-process; its
  `numpy>=2.0.2` requirement is exactly what pushed Chatterbox (below)
  into its own separate environment instead of joining this list

**`requirements-chatterbox.txt`** (a *separate* file, installed into a
*separate* `.venv-chatterbox` environment built from **Python 3.11**, not
3.12 like the main `.venv` -- see section I):
- **chatterbox-tts** (V4) &ndash; the voice-cloning TTS engine (section B).
  Pulls PyTorch/torchaudio and several other heavy dependencies
  transitively -- the multi-gigabyte download README.md's install-size
  heads-up refers to. It cannot be merged into the main `requirements.txt`
  above: it pins `numpy<2.0.0`, which directly conflicts with
  `kokoro-onnx`'s `numpy>=2.0.2` pin two bullets up -- there is no numpy
  version satisfying both, discovered when an earlier version of this
  file put `chatterbox-tts` straight into the main `requirements.txt` and
  a real Windows `pip install` failed with exactly that
  `ResolutionImpossible` error.
- **setuptools==80.9.0** &ndash; explicit, not just along for the ride,
  and explicitly version-pinned below 82: `perth` (chatterbox's
  watermarking dependency) needs `pkg_resources` at import time and fails
  silently instead of raising without it, and setuptools 82.0.0 removed
  `pkg_resources` outright -- see section I for both causes of this and
  why an unpinned `--upgrade` re-breaks it.
  `chatterbox_engine.py` talks to this whole environment over a
  **persistent** subprocess (`_chatterbox_worker.py`, kept alive across
  calls rather than restarted per section -- see section I) -- installed
  by default via `windows_install.ps1`, but as its own non-fatal setup
  step, not a `requirements.txt` line.
- **resemble-perth** (chatterbox-tts's transitive dependency, not listed
  directly in this file) is itself pinned to a `git+https://github.com/
  resemble-ai/Perth.git` URL in chatterbox-tts's own `pyproject.toml`
  (confirmed by reading it directly), not a normal PyPI release -- so
  installing `requirements-chatterbox.txt` needs `git.exe` on PATH, a
  requirement this app previously never checked for. `windows_install.ps1`
  now has a `Find-Git` step (same pattern as `Find-Python311`: check PATH,
  check common install locations, install via winget as `Git.Git` if
  still missing) before installing Chatterbox's requirements, and warns
  non-fatally rather than failing outright if it still can't find or
  install one. A PyPI-only override was considered (resemble-perth 1.0.1
  is separately published there) and rejected for this pass: overriding
  one of chatterbox-tts's own pinned transitive dependencies is a pip
  resolver interaction this sandbox has no way to actually test, and
  getting it wrong silently would be worse than requiring Git.

Back in the main environment:
- **lingua-language-detector** &ndash; source-language detection
- **python-docx**, **pypdf** &ndash; document import (.docx, .pdf)

No new pip dependency for V3's `gui/resource_manager.py` downloads: they
use the standard library's `urllib`, not `requests` or any HTTP client
package.

System-level (not pip-installable):
- **espeak-ng** &ndash; phonemization backend Kokoro calls out to
  (especially for non-English voices); GPL-3.0, installed as a system
  binary, not linked into this app's process. `windows_install.ps1`
  installs this automatically via winget (`eSpeak-NG.eSpeak-NG`),
  mirroring the FFmpeg block below; `run.py` also checks for it on PATH
  at startup as a safety net for manual/portable installs and warns
  (non-fatally) if it's missing.
- **FFmpeg** &ndash; needed for **both** MP3 and OGG export, not just MP3.
  `soundfile`/libsndfile *can* technically write OGG, but its OGG/Vorbis
  writer has real, currently-open reliability problems on some
  libsndfile versions (silently-empty files, a reproducible crash on
  Windows -- see `audio/audio_processor.py`'s module docstring for the
  specific upstream issue), so OGG is routed through the same
  battle-tested FFmpeg path as MP3 instead. WAV and FLAC never need
  FFmpeg. `windows_install.ps1` installs FFmpeg automatically via winget.

Deliberately **not** included in the *main* environment: pysbd (see
section I), onnxruntime-gpu/onnxruntime-directml (CPU-only by default
for Piper and Kokoro specifically; see README.md's "GPU acceleration"),
and PyTorch/torchaudio itself -- that's what makes Chatterbox's separate
`.venv-chatterbox` necessary rather than optional-in-name-only. PyTorch
*is* installed by default as of V4, just not into this environment; see
README.md's install-size heads-up and "Voice cloning (Chatterbox)" for
the user-facing framing.

---

## G. Data-flow diagram

```
 [Source text: paste, type, or import .txt/.md/.docx/.pdf]
              |
              v
   [lingua language detection] --(user can override)--> source_language
              |
              v
   [TextChunker: sentence / paragraph / automatic / custom-length]
              |
              v
   [Sections table: one row per TextSection]
              |
              v
   [Argos Translate: source_language -> target_language, per section]
              |
              v
   [Translated text -- independently editable per section in the GUI]
              |
              v
   [TTSEngine.synthesize() per section] --(Piper: subprocess | Kokoro: in-process)
              |         ^
              |         '-- a section still too long for one call is
              |             transparently sub-chunked and rejoined
              |             (SectionsSynthesisWorker), see section I
              v
   [AudioProcessor.join(): concatenate all sections with short gaps]
              |
              v
   [QMediaPlayer preview]  ------->  [AudioProcessor.export(): WAV/FLAC via
                                       soundfile, MP3/OGG via FFmpeg]
                                                |
                                                v
                                          output file on disk

   Any single row's Regenerate button re-runs just that section through
   translate -> synthesize -> rejoin, without touching the others.
   File > Save Project persists source text, translations, per-section
   audio, and settings to a project directory (see section E).
```

---

## H. Implementation status

Everything below is implemented and working in this delivery (not staged
or planned):

1. `core/` &ndash; models, interfaces, exceptions, device detection, registry
2. `engines/translation/argos_engine.py` &ndash; sole translation engine
   (a second, optional LibreTranslate engine existed briefly in V3 and
   was removed by request; see section C)
3. `engines/tts/piper_engine.py`, `engines/tts/kokoro_engine.py` &ndash;
   V3 adds in-app voice download/status methods to both, and Kokoro gains
   a `_CHARACTER_STYLES` voice-blending system plus DirectML-aware session
   construction (`Kokoro.from_session()` with `core/device.py`'s provider
   list, rather than relying on Kokoro's own env-var-driven autodetection)
4. `engines/tts/chatterbox_engine.py` + `_chatterbox_worker.py` (V4,
   installed by default) &ndash; voice cloning via a reference audio clip
   (`SynthesisSettings.reference_audio_path`) -- no interface change to
   `TTSEngine` itself beyond two new optional hooks, both default
   `None`/no-op for every other engine: `run_diagnostics()` for the
   "Diagnose..." button, and `warmup_notice()` so
   `SectionsSynthesisWorker` can show "this tier's model is loading for
   the first time" instead of a generic status line during Chatterbox's
   slow first model construction. Exposes three `Voice`
   entries (Nano/Turbo/Original model tiers, all `supports_cloning=True`);
   runs in its own `.venv-chatterbox` environment (Python 3.11) via a
   **persistent** subprocess (see section F for the numpy conflict that
   makes a separate environment necessary, and section I for why it's
   persistent rather than one-per-call) rather than importing
   `chatterbox`/`torch` in-process -- `_chatterbox_worker.py` picks
   CPU/CUDA using that environment's own `torch.cuda.is_available()`,
   since the main process has no torch installed to check with. Only
   Chatterbox's English models are wired up -- see its module docstring
   and section I for why the Multilingual variant is deliberately not
   included yet.

   A V4 follow-up pass added Chatterbox's own native generation-time
   controls, rather than leaving them at fixed defaults: seven new
   fields on `SynthesisSettings`/`Project`
   (`exaggeration`/`cfg_weight`/`temperature`/`repetition_penalty`/
   `min_p`/`top_p`/`top_k`, all prefixed `tts_` on `Project`), five new
   `Voice` capability flags (`supports_expression`, `supports_turbo_nano_presets`,
   `supports_advanced_sampling`, `supports_min_p`, `supports_top_k`) that
   `tts_panel.py` reads to show/hide the right controls per tier, and a
   new `_sampling_kwargs_for_tier()` function in `_chatterbox_worker.py`
   that is the single authoritative point deciding which of those seven
   values actually reach `model.generate()` -- gated strictly by tier
   (Original gets Expression/CFG/Min-P but no Top-K, since its
   `generate()` has no such parameter at all; Turbo/Nano get Top-K but
   silently ignore Expression/CFG/Min-P, since their own source accepts
   but warns on them) regardless of what the GUI or a saved project
   happens to be carrying, so a stale value from an old project can
   never reach a tier that doesn't support it. The GUI also gained a
   collapsible "Advanced" sampling section in `tts_panel.py`
   (Temperature/Top-P/Top-K/Min-P/Repetition-penalty), collapsed by
   default so the common case still looks like the pre-pass UI. This
   pass also briefly added Turbo/Nano-only sound-tag insert buttons
   (`[laugh]`/`[chuckle]`/`[cough]`, confirmed against Chatterbox's own
   README) in `source_panel.py` under a `supports_sound_tags` flag --
   removed in a later pass after a real user found `[laugh]`/`[chuckle]`
   didn't actually work and asked for all three to come out; the flag
   was renamed to `supports_turbo_nano_presets` once its only remaining
   job (picking which Style preset table applies) had nothing to do with
   sound tags any more. See section I for the design decisions behind
   this pass and what was deliberately left out of it.

   A second V4 follow-up pass then added the two controls deliberately
   deferred out of the first one: **Speed and Pitch**, both as ffmpeg
   DSP on the finished WAV (`_apply_speed_and_pitch()` in
   `chatterbox_engine.py`) rather than a model-level control Chatterbox
   doesn't have -- `atempo` for Speed, the standard
   `asetrate`+`aresample`+`atempo` trick for Pitch. All three tiers now
   set `supports_speed=True`/`supports_pitch=True`, with a narrower
   `speed_range`/`pitch_range` (0.75x-1.50x, +/-4 semitones) than Piper/
   Kokoro's native implementations use, since a naive DSP approach
   starts sounding artificial well before a native one would (see
   `Voice.speed_range`/`pitch_range`'s comment in `core/models.py`, a
   new pair of fields any engine can now declare its own safe range
   for, generically read by `TTSPanel._apply_voice_capabilities()`
   rather than hard-coded per engine name). The same pass also added
   **"Normalise final audio"**, a checkbox in `OutputPanel` wired to a
   new `AudioProcessor.normalize_peak()` method and a new
   `Project.normalize_output` field, applied once to the whole joined
   preview/export clip rather than per section. See section I for this
   pass's design decisions.

   A third V4 follow-up pass then implemented the
   **reference-conditional-caching** optimization deferred since the
   very first native-controls pass: `_chatterbox_worker.py`'s
   `_sync_reference_conditionals()` (new) now skips passing
   `audio_prompt_path` to `generate()` -- and therefore skips
   Chatterbox's own expensive `prepare_conditionals()` step -- whenever
   a `synthesize()` call's reference clip is unchanged from the one
   already reflected in the currently-loaded model's `self.conds`,
   tracked via two new `_MODEL_CACHE` fields
   (`prepared_reference_audio_path`, `default_conds`). Implementing this
   properly surfaced a real, separate, pre-existing bug rather than just
   a performance opportunity: clicking "Clear" on the reference-audio
   picker after using a custom clone earlier in the same session never
   actually reverted to a tier's built-in voice, since omitting
   `audio_prompt_path` just reuses whatever `self.conds` already is.
   `_load_model()` now stashes each freshly-loaded model's own default
   `self.conds` the moment it's constructed, and
   `_sync_reference_conditionals()` explicitly restores it (a cheap
   attribute assignment, not a re-run of `prepare_conditionals()`) when
   a request asks for "no reference" after a custom one was prepared.
   See section I for the full verification trail and design decisions.

   A fourth V4 follow-up pass then addressed a real user reporting the
   app itself as "cluttered and busy." Its first attempt (more spacing
   plus bold sub-heading labels inside `tts_panel.py`, all purely
   additive) made a real user's actual window *worse*, not better --
   see section I for why, and for the corrected fix that shipped
   instead: undoing that spacing/heading addition and, in its place,
   making `tts_panel.py`'s Expression/Voice Guidance/Style preset
   controls collapse behind a new toggle, off by default, the same
   progressive-disclosure pattern its existing "Advanced sampling
   controls" toggle already used. `source_panel.py`'s text box and
   `sections_panel.py`'s table also each gained a defensive
   `setMinimumHeight()` floor as part of the same pass.
5. `text_processing/chunker.py` (sentence/paragraph/automatic/custom modes,
   all exposed in the GUI), `text_processing/language_id.py`,
   `text_processing/document_import.py` (.txt/.md/.docx/.pdf)
6. `audio/audio_processor.py` &ndash; WAV/FLAC via `soundfile`; MP3/OGG via
   FFmpeg (see the module's own docstring for why OGG specifically isn't
   routed through libsndfile too)
7. `gui/` &ndash; five panels (source, translation target, sections table,
   TTS settings, output) + main window + background workers, including
   per-section translate/regenerate, a File menu with New/Open/Save/Save As,
   V3's `gui/resource_manager.py` (the in-app Download Manager dialog,
   opened from "Download Languages..." / "Download Voices..." buttons, plus
   an automatic "install this missing language pair now?" prompt the first
   time Translate All hits one), and V4's reference-audio picker in
   `tts_panel.py` for cloning-capable voices
8. `project/project_manager.py` &ndash; save/load a project directory
   (source text, translations, per-section audio, settings, including V3's
   `character_preset` field and V4's `tts_reference_audio_path`;
   `translation_engine` is stored too, always `"argos"` now, kept for
   backward-compatible loading of older projects)
9. `settings/app_settings.py`
10. `run.py`, `requirements.txt` (main environment; deliberately does
    NOT include Chatterbox -- see section F), `requirements-chatterbox.txt`
    (Chatterbox's own separate-environment dependency file, including
    `setuptools` explicitly -- see section I), `windows_install.ps1`
    (auto-installs espeak-ng via winget as of V3; as of V4 also seeds
    `.venv-chatterbox` from Python 3.11 when available, installs
    `requirements-chatterbox.txt` into it, and pre-downloads every model
    tier's weights via `_chatterbox_worker.py --download-only` -- without
    constructing a model -- all as one non-fatal step, and also runs a
    `Find-Git` check before installing Chatterbox's own requirements,
    since one of its transitive dependencies is pinned to a git URL, not
    a PyPI release -- see section F) + the two `.cmd` launchers
    (`Run TTS Studio.cmd` only checks for `pkg_resources` on every launch
    and prints a one-line repair hint if it's missing -- it deliberately
    does not install or modify anything itself any more; see section I),
    this document, `README.md`

**Still staged for later versions** (per the brief's own roadmap):
Qwen3-TTS as a second cloning engine, plus wiring up Chatterbox's own
Multilingual/Turbo/Nano variants once their exact language codes are
verified (see section I); XTTS-v2 and F5-TTS offered as clearly-labeled
non-commercial/CPML options. NLLB-200 as a third translation engine was considered for V3
alongside LibreTranslate but set aside for now -- its weights are
CC-BY-NC-4.0 (non-commercial only, see section I), which sits awkwardly
next to Argos/LibreTranslate's fully-open licenses without a clearer
signal that users actually want it.

---

## I. Risks and compatibility issues

**Piper's license changed from MIT to GPL-3.0.** The actively maintained
fork (OHF-Voice/piper1-gpl) is GPL-3.0; the MIT original is archived and
receives no updates. This app runs Piper as a separate `python -m piper`
subprocess specifically to avoid pulling GPL-3.0 into this application's
own process via an in-process `import`. This is a conservative,
defensible default, not legal advice -- if you're comfortable with the
whole app being GPL-3.0, the in-process Python API
(`from piper import PiperVoice`) is simpler and documented in Piper's own
repo.

**Voice-cloning engines are a licensing minefield.** XTTS-v2 (CPML,
non-commercial, and Coqui Inc. no longer exists to sell a commercial
license) and F5-TTS (CC-BY-NC-4.0) are both off the table for anything
beyond research/personal use. Chatterbox (MIT) and Qwen3-TTS
(Apache-2.0) are the commercial-safe options for V4 -- prioritize those
when that version is built, and keep XTTS/F5-TTS available but clearly
labeled non-commercial for anyone who wants them anyway.

**`pysbd` (the obvious sentence-splitting dependency) is unmaintained
with an unresolved hang bug.** An open GitHub issue from December 2025
asks the maintainer to archive the project; a known
catastrophic-backtracking regex can hang indefinitely on certain input.
Given this app's whole job is processing arbitrary long-form text, that
risk was unacceptable, so V1 ships a small hand-written splitter instead
(`text_processing/chunker.py`). It won't be linguistically perfect on
every edge case, but it's fast, has no ReDoS surface, and is easy to
extend.

**Kokoro caps input at ~510 tokens per synthesis call.** A naive
"synthesize the whole textbox in one call" would silently truncate or
error on anything longer than a couple of sentences. The user-facing
chunk-mode/length controls (SourcePanel) handle the common case, but
nothing stops someone from choosing PARAGRAPH mode on a single huge
paragraph and ending up with one section still too big for one
synthesize() call -- so `SectionsSynthesisWorker._synthesize_safely`
additionally sub-chunks any individual section that's still oversized
(automatic mode, ~400 characters/piece) and transparently rejoins the
audio before the section is marked done. That safety net runs regardless
of which chunk mode the user picked at the document level.

**NLLB and F5-TTS's non-commercial weight licenses are easy to miss.**
Both are frequently described as "open source" in blog posts and
tutorials without the CC-BY-NC-4.0 qualifier on the *weights* being
mentioned. Anyone extending this app with either should keep that
license attached to the relevant engine adapter's docstring, the way
this codebase does for the ones it already flags.

**Individual Piper voices can carry their own license,** separate from
the MIT-then-GPL-3.0 engine license. Most official voices are
permissive, but the project itself says to check each `MODEL_CARD`
before shipping.

**onnxruntime GPU support on Windows without an NVIDIA GPU** (e.g. Intel
integrated graphics, AMD) is best served by `onnxruntime-directml`
rather than `onnxruntime-gpu` (which targets CUDA). `core/device.py`
checks for `DmlExecutionProvider` in addition to `CUDAExecutionProvider`,
and as of V3 `kokoro_engine.py` actually uses that provider list: it
builds its own `onnxruntime.InferenceSession` and hands it to Kokoro via
`Kokoro.from_session()`, since Kokoro's own constructor takes no
`providers=` argument (verified against `kokoro_onnx`'s source -- its
own GPU support is either "install onnxruntime-gpu and it's
autodetected" or an `ONNX_PROVIDER` env var, neither of which lets this
app prefer DirectML deliberately). **Piper stays CPU/CUDA-only.** Its
CLI (`OHF-Voice/piper1-gpl`) was checked directly against its own
`CLI.md`/`API_PYTHON.md` while doing this work, and the only
acceleration flag it exposes at all is `--cuda` -- there is no DirectML
option on the CLI surface to wire up, so this is now a documented
upstream gap rather than an unwired task on this app's side. Revisit if
piper1-gpl ever adds one.

**LibreTranslate was added in V3, then removed again by request.** While
it existed, it ran as an optional, off-by-default-in-practice second
translation engine, talked to purely over HTTP (this app never imported,
subprocessed, or bundled any of its AGPL-3.0 code -- a plain HTTP client
is no different in kind from a web browser hitting the same API, so
AGPL-3.0's network-copyleft clause, which is about a service *offering*
functionality needing to share its own source, never actually applied to
this app's own license). It's kept out of the current codebase now, so
Argos is the only translation engine and there is no AGPL-3.0 exposure to
reason about at all.

**Design lesson from building and removing it, worth keeping even though
the engine itself is gone: a pre-flight capability guess is a hint, not a
gate.** An earlier version of `MainWindow._start_translation_with_lang`
used `has_translation()` (this app's own guess, from a separate
`/languages`-style call) to flatly refuse translation with an
"unsupported language pair" error whenever it returned False -- correct
for Argos, where that guess also decides whether to offer an in-app
*install*, but wrong for an engine with no in-app installer (as
LibreTranslate was): any mismatch between this app's guess and what the
real engine actually supports can permanently block something that would
otherwise have worked. The fix that shipped, and that the current
`argos`-only code still follows, is that the pre-flight check only ever
gates the Argos-style install prompt (which needs `install_package()` to
exist); if a future second engine is ever added without an installer, it
should attempt the real `translate()` call directly rather than being
pre-emptively blocked by this app's own guess, surfacing any genuine
unsupported-pair error from the engine's own answer, per-section, through
the normal translation-error path.

**Chatterbox cannot share an environment with Kokoro, full stop -- this
was found the hard way.** An earlier version of this app put
`chatterbox-tts` straight into the main `requirements.txt`, reasoning
(correctly, on its own) that shipping it as a separate opt-in `pip
install` step meant most people never ran that command and the feature
went unused. On a real Windows machine, `pip install -r requirements.txt`
then failed outright with `ResolutionImpossible`: `chatterbox-tts` pins
`numpy<2.0.0`, while `kokoro-onnx` (already in that same file) requires
`numpy>=2.0.2`. There is no numpy version satisfying both constraints at
once -- this isn't a "loosen a version pin" problem, the two packages
cannot coexist in one Python environment, period. The fix keeps the
install-by-default *goal* but changes the *mechanism*: Chatterbox now
gets its own environment, `.venv-chatterbox`, built from
`requirements-chatterbox.txt` (see section F), with `chatterbox_engine.py`
talking to it over a subprocess -- the same isolation *mechanism*
`piper_engine.py` already uses, for an entirely different *reason*
(there, GPL-3.0 licensing; here, an unresolvable dependency conflict).
`windows_install.ps1` creates that environment, installs into it, and
pre-downloads every model tier's weights (download-only, see below), all
as one **non-fatal** step -- if any part of it fails, every other engine
in the app is completely unaffected, and Chatterbox just shows
"(not installed)" until the step is retried.

**That environment now targets Python 3.11, not 3.12 like the main
`.venv`** -- also found the hard way, in the same debugging session as
the numpy conflict above, from a *second* real crash report against this
app: `TypeError: 'NoneType' object is not callable` on
`perth.PerthImplicitWatermarker()`. Root cause (confirmed against
resemble-ai/chatterbox issue #198 and resemble-ai/Perth issue #7):
`perth` (Chatterbox's watermarking dependency) needs `pkg_resources`
(from `setuptools`) at its own import time, and silently sets that
attribute to `None` instead of raising when it's missing. It goes
missing two different ways, both landing on the identical crash, and an
earlier round of this project only understood the first one:

1. Python 3.12's `venv` module stopped bundling `setuptools` into new
   environments by default, while chatterbox-tts's own README says it
   develops and tests against Python 3.11 (whose `venv` still does).
2. `setuptools` itself removed `pkg_resources` outright as of v82.0.0
   (confirmed directly against setuptools's own changelog at
   setuptools.pypa.io, "Deprecations and Removals" for that release) --
   so even on Python 3.11, installing "whatever `setuptools` is newest"
   with no version pin reintroduces the exact same crash. This was a
   real, not hypothetical, regression in this project: an earlier round
   of `windows_install.ps1` ran `pip install --upgrade pip setuptools
   wheel`, which would pull 82+ and quietly re-break a previously-working
   install the next time setup ran.

`windows_install.ps1` now seeds `.venv-chatterbox` from Python 3.11 when
it can find or install one (falling back to 3.12 non-fatally otherwise),
and installs `setuptools` pinned to an exact version below 82 (see
`requirements-chatterbox.txt` for which one and why) rather than
`--upgrade`ing it unconstrained -- covering both causes, not just the
first. `_chatterbox_worker.py` checks for `pkg_resources` directly
(`_check_pkg_resources_available`/`_check_perth_watermarker`) before ever
touching `perth`, raising a specific, actionable error instead of the
bare `TypeError` if it's somehow still missing or still the wrong
version, and its `--diagnose` output reports the actual installed
`setuptools` version, not just whether `pkg_resources` imports, so a
drifted pin is visible rather than only showing up as a recurrence of the
original crash. Both the worker and `Run TTS Studio.cmd` are check-only,
though, not fix-it-here: an earlier draft of this project ran `pip
install setuptools` from inside the worker on every Generate click, and
a later draft (after that was fixed) still ran an unpinned `pip install
setuptools` from `Run TTS Studio.cmd` on every single launch. Both were
rightly flagged in review as the same underlying problem twice over: a
silent, network-dependent environment change happening somewhere other
than an explicit install step -- and the launcher's version had a second
problem on top of that, an unpinned `pip install` with no `--upgrade`
flag is a no-op whenever *any* `setuptools` is already present, so it
could report success on every launch while never actually repairing a
broken environment. All repair now happens in exactly one place --
`windows_install.ps1` ("Install TTS Studio.cmd"), pinned, still just a
double-click -- and both the worker and the launcher only check and
report.

**A persistent worker process replaced one-subprocess-per-`synthesize()`
call, after a design review caught the problem before more people hit
it.** The original design started a fresh `_chatterbox_worker.py`
subprocess, loaded the full model, generated one section, and exited --
for every section, and again for every sub-chunk of a long section. On
CPU that's minutes of dead time per section just for model loading, on
top of the actual generation, which is exactly what "painfully slow" and
"may appear frozen" look like to someone trying to generate a real
document, not a hypothetical edge case. Fixed by keeping ONE worker
process alive for as long as Chatterbox stays selected (or the app stays
open): `chatterbox_engine.py` starts it once, and every `synthesize()`
call after that sends a JSON object over its stdin and reads one back
from its stdout, with the model loading once per (tier, device)
combination and staying resident between calls (see
`_chatterbox_worker.py`'s `_load_model` cache, which deliberately holds
at most one model at a time -- switching tiers mid-session swaps which
one is loaded rather than stacking several in memory). Process lifecycle
(start-once, reuse, shut down on engine switch or app close, restart if
the process died) lives in `chatterbox_engine.py`; `MainWindow` calls
`shutdown()` at both of those points. Since stdout is now a long-lived
protocol channel rather than a one-shot pipe read, `_chatterbox_worker.py`
seizes the real stdout file descriptor at the OS level
(`_stdout_seized_for_protocol`) before entering its request loop, so a
stray `print()` or a C-extension writing progress output can't corrupt
the JSON-lines stream and take down every subsequent request.

**Two more real bugs surfaced once this actually ran on a Windows
machine, both fixed the same way -- by finishing the stdout-seizing
protection above rather than adding a second mechanism:**

1. The GUI's "Diagnose..." button showed `"error": "Unreadable
   diagnostics output: ..."` instead of a real report. Root cause:
   `main()`'s `--diagnose` branch (a one-shot CLI invocation, not the
   persistent loop) never seized stdout in the first place -- its
   comment claimed "nothing else is reading it as JSON-lines," which is
   true but beside the point, since `chatterbox_engine.py`'s
   `run_diagnostics()` reads the whole captured stdout and does one
   `json.loads()` on it. `_diagnose()` loads a real model and runs a
   real short generation, and chatterbox's own library code prints plain
   progress text straight to stdout while doing that -- confirmed
   verbatim from a real report: "loaded PerthNet (Implicit) at step
   250,000" and "S3 Token -> Mel Inference..." landed glued to the front
   of the JSON. Fixed by wrapping the `--diagnose` branch in the same
   `_stdout_seized_for_protocol()` used above, and unit-tested
   in-process (redirect real fd 1 to a pipe this test owns, monkeypatch
   `_diagnose` with a stand-in that prints stray lines, run the real
   `main()`, confirm only JSON reached the pipe -- see
   `test_diagnose_cli_seizes_stdout_so_stray_prints_cant_corrupt_the_json()`
   in `test_chatterbox_worker_v4.py`).
2. A real user reported Chatterbox "freezes when trying to generate
   audio" -- on investigation (helped by the Diagnose report above,
   which showed the underlying pipeline completing a real test
   generation successfully once its own output-parsing bug was
   understood) this wasn't a hang: a model tier's first `synthesize()`
   call in a session has to construct that model from scratch inside the
   worker, which is genuinely slow on CPU -- anywhere from under a
   minute to several minutes, worse for "original" than "nano" -- with
   no progress of its own to report while it happens. Watching the
   generic "Generating audio 1 of N..." status sit unchanged for minutes
   is indistinguishable from a real freeze. Fixed with a new optional
   `TTSEngine.warmup_notice(settings)` hook (default `None`, same
   capability-flag reasoning as `run_diagnostics()`): `SectionsSynthesisWorker`
   (gui/workers.py) calls it before each section and shows its message
   in place of the normal status line when it returns one.
   `ChatterboxTTSEngine.warmup_notice()` returns a message unless
   `_loaded_voice_id` (now actually set, after a real successful
   response -- it was declared and reset in three places but never once
   assigned a real value before this fix, so it was always `None`)
   matches the tier being requested and the worker process is still
   alive; switching tiers or losing the worker (timeout, crash,
   `shutdown()`) brings the notice back, matching `_load_model`'s
   single-model cache on the worker side.

**Chatterbox's Nano and Turbo tiers are wired up as of this pass;
Multilingual V3 (23 languages) still isn't.** Nano and Turbo both come
from `chatterbox.tts_turbo.ChatterboxTurboTTS.from_pretrained(device=...,
nano=True/False)` -- verified against upstream's README and its own
`example_tts_nano.py`, which agree with each other on that exact call
signature. Worth flagging honestly: a direct source read of
`tts_turbo.py` on GitHub's `master` branch during this work did **not**
show a `nano` kwarg on `from_pretrained()` at all -- a real,
unreconciled discrepancy between upstream's own docs/examples and at
least one version of its source, not a guess made up for this app.
`_chatterbox_worker.py`'s `_load_model` retries the call without `nano=`
if passing it raises `TypeError`, so a chatterbox-tts release that
genuinely doesn't support the kwarg degrades to plain Turbo instead of
crashing, and this is unit-tested against fake `chatterbox.tts_turbo`
modules covering both shapes (see `test_chatterbox_worker_v4.py`).
Multilingual is still out: its own documentation lists 23 supported
languages by name, not in a verified code-to-`language_id=` table the
way Kokoro's `_KOKORO_VOICE_TABLE` was built from Kokoro's actual
VOICES.md -- guessing at 23 ISO-639 codes risks silently mistranslating
or erroring for languages this app already supports for translation.
Wiring it up once the exact codes are confirmed against source (not
assumed) is a good, contained follow-up.

**Chatterbox's pre-warm step downloads model weights without
constructing a model**, to avoid the installer allocating a full model
in RAM and looking hung on a modest machine. `_chatterbox_worker.py
--download-only` calls the exact same `hf_hub_download`/
`snapshot_download` functions (and repo IDs/file lists) that
`ChatterboxTTS.from_pretrained()`/`ChatterboxTurboTTS.from_pretrained()`
use internally -- verified directly against their source, where the
download step and the `from_local()`/model-construction step that
follows it are already two separate pieces of code upstream -- without
ever calling the construction half.

**A "Diagnose..." button gives a real, independent self-check without a
command prompt.** `TTSEngine.run_diagnostics()` (default `None` -- "this
engine doesn't have one") is the generic hook `TTSPanel` calls regardless
of which engine is selected, same reasoning as every capability flag on
`Voice`. Chatterbox's implementation runs `_chatterbox_worker.py
--diagnose` as a one-off subprocess (deliberately not through the
persistent worker, so it still works as a check even if that worker is
the thing stuck) and reports Python/Chatterbox/Torch/torchaudio versions,
CUDA availability, the actual installed `setuptools` version and whether
`setuptools`/`perth` are healthy (not just present -- v82+ installs fine
but is still broken for this purpose, see above), what's already in the
local Hugging Face cache, and the result of an actual short test
generation -- catching problems `is_available()`'s fast filesystem check
(see below) deliberately doesn't try to (a broken CUDA install, a
corrupted cached model, a correctly "installed" but wrong-version
`setuptools`, ...).

**`is_available()` is a plain filesystem check now, not a subprocess
import probe -- a third real bug from the same round, also traced back
through a live Diagnose report.** A user saw Chatterbox listed as
"Chatterbox (voice cloning, MIT)  (not installed)" in the engine
dropdown despite a Diagnose run moments earlier proving it worked (real
model load, real generation). Root cause: `is_available()` used to run
`python -c "import chatterbox.tts"` as a subprocess with a 15-second
timeout, and that import pulls in the same heavy torch-class dependency
stack that made the persistent worker necessary in the first place -- a
cold import of it on a real machine (first run after venv creation,
antivirus scanning every DLL, a slow disk) can easily exceed 15 seconds,
at which point `subprocess.TimeoutExpired` was caught and silently
turned into "not installed", hiding a working engine. `is_available()`
is also called far more often than a subprocess-per-call design can
justify regardless of timeout risk: once per engine at startup
(`MainWindow._populate_engines`) and again on every `available_voices()`
call (every engine switch). Fixed by checking for the `chatterbox`
package directory under `.venv-chatterbox\Lib\site-packages\` directly
-- instant, no subprocess, no timeout to get wrong -- accepting that this
only answers "does this look installed", not "does it definitely work";
that stronger guarantee is what `run_diagnostics()` and `synthesize()`'s
own error handling are for. Test coverage moved with it:
`test_chatterbox_engine_v4.py`'s `_FakeEnv` now lays down a fake
`Lib/site-packages/chatterbox/` directory instead of the tests faking
`subprocess.run`'s return code, and the now-unexercised `-c`-probe
branch of the test suite's `_PopenFactory`/`_FakeProbeProcess` was
removed rather than left as dead, misleading infrastructure.

**A fourth bug, cosmetic but visible, came from fixing the first
"freeze" report above: the new warmup-notice status message could force
the whole app window wider than the screen.** `OutputPanel.status_label`
(the audio-preview panel's status line, separate from the OS-level
status bar) is a plain `QLabel` with no word-wrap and no width
constraint added in an earlier version; Qt gives such a label a
`minimumSizeHint()` wide enough to fit its entire text on one line, and
that propagates up through its row's layout to the main window itself.
Every status message before this pass was short enough ("Generating
audio 1 of 3...") for this to never surface. `warmup_notice()`'s
original message was a full paragraph, and was immediately long enough
to trigger it. Fixed in two parts: `status_label` now has
`QSizePolicy.Ignored`, so the layout no longer sizes the window around
its text (a real fix, not a workaround, that protects against any future
long status message doing the same thing), plus its full text is kept in
a tooltip in case of visual clipping; and `warmup_notice()`'s message was
also cut down to one short line regardless, since a status bar is the
wrong place for a paragraph even when it isn't actively breaking the
layout.

**A second architectural review, done after the fixes above shipped,
found a real pipe-deadlock risk in the persistent worker itself --
`stderr=subprocess.PIPE` was never being read during normal operation,
only after the process had already died.** OS pipes have a finite
buffer; `_chatterbox_worker.py` deliberately routes chatterbox's/torch's/
perth's own chatty `print()` output to stderr (see
`_stdout_seized_for_protocol` above), so a model that logs enough while
loading or generating can fill that pipe. Once it's full, the worker's
own `print()` call blocks *inside its write() syscall*, before it can
ever get to sending the JSON response -- and `_send_request`'s response
read then waits out the full 1200-second timeout for a reply that was
never coming, which looks exactly like the "freezes when trying to
generate audio" report above, just from a different cause. Fixed the
standard way for an unread pipe: `_start_stderr_drain_thread` spawns one
background thread per worker-process lifetime that does nothing but
`proc.stderr.readline()` in a loop for as long as the process lives, not
just after something's already gone wrong, keeping the last 500 lines in
a bounded `collections.deque` so an error path can still report what the
worker printed right before it died.

Getting this right took two passes, and the second bug was subtler than
the first: **the drain thread and `_send_request` were sharing the same
lock (`self._lock`), which meant the drain thread could never actually
append anything while a request was in flight.** `_send_request` holds
`self._lock` for its entire round trip -- including the wait for a
response, which can be the full 1200 seconds -- so a drain thread that
also needed `self._lock` to append a line would simply block behind it,
defeating the whole point of draining continuously. Worse, it made
`_drain_stderr_after_death()` (called from inside that same locked
region on a crash) join a thread that could never finish, since the
thread it was joining was itself stuck waiting on the very lock the
joining thread already held -- avoided only by that join's 3-second
timeout, which meant a crash's real stderr content (e.g. a Python
traceback) was silently dropped in favor of the generic "exited
unexpectedly" fallback message. This was caught before shipping, not
after: unit tests written for the drain-thread fix itself
(`test_synthesize_raises_when_process_dies_without_responding`) started
failing that assertion once the test double was made realistic enough to
model a real blocking pipe (see `test_chatterbox_engine_v4.py`'s
`_FakeReadable`, queue-backed with an explicit EOF sentinel rather than
"empty list means EOF instantly"), which is exactly the kind of
lock-contention bug a less faithful test double would have hidden. Fixed
by giving the stderr buffer its own dedicated `self._stderr_lock`,
completely independent of `self._lock`, so the drain thread can append at
any time regardless of what `_send_request` is doing.

The rest of that review's findings, addressed in the same pass:

- **`is_available()` now checks for `torch`, `torchaudio`, and `perth`
  alongside `chatterbox` under `.venv-chatterbox`'s `site-packages`, not
  just `chatterbox` alone** -- a partially-failed `pip install` (network
  drop partway through the multi-gigabyte download) could previously
  leave the `chatterbox` package directory present while its actual
  dependencies were missing, which this single-directory check would have
  happily reported as "available."
- **`run_diagnostics()` now calls `self.shutdown()` before running its
  own worker subprocess**, so a Diagnose click can never have two full
  models resident in memory at once (the persistent worker's, if one was
  already loaded, plus the diagnostic subprocess's own) -- a real risk on
  a memory-constrained machine, previously untested. Its timeout was also
  raised from 180 seconds to the same 1200-second
  `_RESPONSE_TIMEOUT_SECONDS` `synthesize()` uses, since a cold model load
  during diagnostics is exactly as slow as a cold model load during
  synthesis and there was no reason for it to have a shorter, unrelated
  budget.
- **Switching model tiers mid-session now explicitly releases the
  previous model before constructing the new one.** `_load_model`'s cache
  already held at most one model at a time, but the old model reference
  was simply overwritten by assignment, leaving its release timing (and
  whether CUDA VRAM was ever actually freed) up to Python's garbage
  collector's own schedule -- on GPU specifically, `torch` doesn't return
  freed memory to the OS/driver until `torch.cuda.empty_cache()` is called
  regardless of when Python collects the object. `_release_cached_model()`
  now explicitly drops the reference, calls `gc.collect()`, and calls
  `torch.cuda.empty_cache()` when CUDA is in use, before the new tier's
  model is constructed -- avoiding a transient double-model memory peak
  during the switch, not just an eventual leak.
- **The CPU `torch.load` monkey-patch is now idempotent.** It's applied
  once per `_load_model()` call, which happens once per tier switch in a
  process that can switch tiers many times over its persistent lifetime;
  without a guard it would wrap the already-wrapped function again on
  every switch, one more layer deep each time. A marker attribute
  (`torch_module._tts_studio_cpu_load_patched`) now makes re-application a
  no-op.
- **The installer now also pre-fetches `ResembleAI/chatterbox-nano`
  directly, separately from the Turbo repo it already fetched.** Worth
  being precise about what is and isn't confirmed here, in the same spirit
  as the `nano=` kwarg discrepancy documented above: a real, distinct
  `ResembleAI/chatterbox-nano` model repo on Hugging Face was confirmed to
  exist (its own model card, 110M parameters vs. Turbo's 350M) via a
  direct fetch. A claim that `tts_turbo.py` contains a `NANO_REPO_ID`
  constant pointing at it was **not** confirmed -- two separate direct
  reads of `tts_turbo.py` on GitHub's `master` branch, one of them an
  explicit verbatim-reproduction request, both showed only
  `REPO_ID = "ResembleAI/chatterbox-turbo"` and a `from_pretrained()` with
  no repo-selection logic tied to the `nano=` flag at all. Rather than
  either trust that specific unverified claim or dismiss the underlying
  concern, `_download_all_tiers()` now fetches the Nano repo's weights
  directly as a second, independent, non-fatal `snapshot_download()` call
  -- so the files are present locally either way, regardless of which
  repo `chatterbox-tts`'s own code actually reads from internally at
  generation time.
- **`Run TTS Studio.cmd` no longer installs anything.** It used to run an
  unpinned `pip install --quiet setuptools` on every single launch, which
  (per the two-cause pkg_resources story above) was both the wrong place
  for a silent environment change to happen on every startup, and
  ineffective at actually fixing anything -- an unpinned `pip install`
  with no `--upgrade` flag is a no-op whenever *any* setuptools is already
  present, so it could report success while doing nothing for an already
  broken environment. It now only checks whether `pkg_resources` imports
  and prints a one-line "run Install TTS Studio.cmd again" hint if not;
  all actual repair still happens in exactly one place,
  `windows_install.ps1`, as noted above.
- **Session temp-file cleanup gained two missing prefixes:**
  `ttsstudio_chatterbox_` (covering Chatterbox's own temp WAV files, which
  weren't being swept up at all before this pass -- an independently
  discovered gap alongside `ttsstudio_export_`, which `audio_processor.py`
  already used for export-format temp files but which was likewise never
  in `main_window.py`'s cleanup list).
- **A test-hermeticity bug this project's own tests had, not the app
  itself:** `test_chatterbox_worker_v4.py`'s fake-module tests happened to
  pass or fail depending on whether the ambient Python interpreter running
  them had real `pkg_resources` installed -- exactly the kind of
  environment-dependent behavior the app's own pkg_resources bug was
  about, just one layer up in the test infrastructure instead of the
  product. Fixed by explicitly injecting a fake `pkg_resources` module
  into `sys.modules` for the duration of those tests, the same way every
  other real import the code under test performs (`torch`, `chatterbox`,
  `perth`) was already faked, rather than letting this one import "happen
  to work" against whatever the ambient interpreter provides.

Left deliberately out of this pass, and worth saying so plainly rather
than implying full coverage: installing only the Nano tier by default
with separate opt-in downloads for Turbo/Original in the GUI (currently
all three download during setup, which is more bandwidth/disk than most
users need up front) is a real UX feature, not a bug fix, and needs its
own design pass on the Download Manager rather than a quick patch here.
Likewise, stronger reference-audio validation (duration/format/sample-rate
checks before handing a clip to the worker, rather than just "does this
path exist") was raised and is a reasonable follow-up, but out of scope
for this round. And the request for one real Windows integration test
that actually creates `.venv-chatterbox`, loads Nano, and produces a WAV
remains an honest, stated limitation carried over from every prior round
of this project: this sandbox has no package-index network access, so
nothing here can install real PyTorch/chatterbox-tts or run against real
model weights -- every fix in this pass was verified with unit tests
against faked `torch`/`chatterbox`/`perth` modules and a fake `Popen`
(plus, where the bug was about test-double fidelity itself, hands-on
manual reproduction with a real blocking `queue.Queue`), not a real
end-to-end run.

**`.venv-chatterbox`'s path is resolved from `chatterbox_engine.py`'s own
file location, not the process's working directory.** A bare
`Path(".venv-chatterbox")` only ever worked because `run.py` happens to
`os.chdir()` to the app root before anything else runs; anything that
launched this module a different way would look for it wherever the
process happened to start instead of where it actually lives. Fixed by
walking up from `Path(__file__)` to the app root instead (four
`.parent`s, matching this file's fixed position in the tree).

**The "Download Voices..." button still only ever opens the Piper/Kokoro
dialog, even when Chatterbox is the selected engine.** That's correct,
not a bug -- Chatterbox has no local voice files for this app to manage
(see the point above), so there was nothing to add a third tab for -- but
it does mean clicking that button while Chatterbox is selected takes you
to a dialog about a different engine's voices, which reads a little oddly
even though it's harmless. A cleaner fix (hiding/disabling the button
for engines with nothing to manage) was left out of this pass rather than
adding a new capability flag or a hard-coded engine-name check in the GUI
just to solve a cosmetic rough edge -- worth revisiting if a future
engine makes this a recurring pattern rather than a one-off.

**Chatterbox's reference audio clip is not copied into the saved
project, unlike everything else a project holds.** `Project.tts_reference_audio_path`
stores the path as given; `ProjectManager` copies per-section *generated*
audio into the project's own `audio/` folder (so a project directory is
fully self-contained and portable), but doing the same for a
user-supplied reference clip would mean deciding whether to also handle
re-cloning consent/re-use semantics that were out of scope for this
pass -- so it's documented as a known gap (README.md's "Voice cloning
(Chatterbox)" section) rather than silently making projects
non-portable without saying so.

**Kokoro's character-preset voice blending depends on two `kokoro_onnx`
API details that were verified against its source during V3, not
assumed:** `Kokoro.create(voice=...)` accepts either a voice-id string or
a raw `NDArray[np.float32]` style embedding, and `get_voice_style(name)`
is what returns that embedding for a given voice id. Both are real,
public parts of the library's API (not internals reached through
attribute-poking) -- but if a future `kokoro-onnx` release changes this
signature, `_character_voice()` in `kokoro_engine.py` already fails soft
(falls back to the plain voice-id, no blending) rather than crashing
synthesis, precisely because this was new-enough ground to not be fully
certain it will always hold.

**A real screenshot from actual use caught a fifth bug, in the Sections
table itself rather than anything Chatterbox-specific: "Translate All"
finished with no error, but every row's Status stayed "Pending" and the
Translation column stayed blank.** The confusing part, also visible in
that screenshot, was that this wasn't a translation failure at all:
generating audio afterward produced correctly-translated speech, which
only makes sense if the translation had actually landed on the right
`TextSection` object -- and it had.
`MainWindow._find_section()`/`_on_section_translated()` operate on
`self.project.sections` directly (plain Python objects, matched by a
plain `s.index == index` comparison) and were doing their job correctly;
`SectionsSynthesisWorker` reads `section.translated_text` off those same
objects, which is why the audio came out right. The break was entirely
downstream of that, in `SectionsPanel.update_section()` -- the method
responsible for repainting one row after its section changes. It found
the row to repaint by reading a value back off the row's own
`QTableWidgetItem` (`item.data(0)`, role `Qt.DisplayRole`) and comparing
it against the plain Python `int` passed in, rather than just checking
`self._sections` (the same plain Python list `_find_section` already
matches against successfully) directly. That item is built as
`QTableWidgetItem(str(section.index))` -- which sets `DisplayRole` to a
*string* -- immediately followed by `.setData(0, section.index)` to set
the same role to an *int*; both render identically ("0", "1", ...) no
matter which one actually ends up stored, so nothing about the visible
table gives any hint of which representation `.data(0)` was really
handing back moment to moment. Comparing whichever one it was against a
plain Python `int` is exactly the kind of str/int mismatch that fails
consistently, not intermittently -- matching the screenshot's ROWS being
stuck on "Pending" from the very first (synchronous) status update, not
just the later asynchronous translation result. Tellingly, this file's
other two per-row lookups (`_on_cell_clicked`, and the "Regenerate"
button wired up in `_populate_row`) never had this problem, because they
already index into `self._sections` directly instead of reading a Qt
item's stored data back out -- `update_section()` and the manual-edit
handler `_on_item_changed()` were the only two spots still doing it the
fragile way, and both are now fixed to match the pattern already proven
to work elsewhere in the same file. This couldn't be exercised against a
real Qt event loop in this sandbox (no network access to install
PySide6 here, same limitation noted below for every other GUI-adjacent
fix in this project), so it's fixed from the screenshot's exact,
reproducible symptom plus a careful static read, not a passing GUI test.

**Nothing in this sandbox could be installed or run end-to-end** (no
package-index network access in the environment this was built in,
across the V1 build, the V2 review/fix pass, and the V3/V4 passes,
including this pass's persistent-worker/multi-tier rewrite). Every API
call used in the engine adapters (`PiperVoice`/CLI flags including the
`--cuda`-only finding above, `Kokoro.create()`/`get_voice_style()`/
`from_session()`, `argostranslate.translate`/`package` including its
module-level `uninstall()`, `ChatterboxTTS.from_pretrained()`/`generate()`/
`.sr` including the `audio_prompt_path=` cloning parameter and its
internal `hf_hub_download()` calls, `ChatterboxTurboTTS.from_pretrained(
nano=...)`/its internal `snapshot_download()` call, `huggingface_hub.
scan_cache_dir()`, the Hugging Face `rhasspy/piper-voices` catalog JSON
shape, `lingua`, and the `eSpeak-NG.eSpeak-NG`/`Python.Python.3.11`
winget package IDs) was verified against current official docs/source via
live web search/fetch rather than written from memory -- except the
`nano=` kwarg specifically, where two upstream sources (the README and
`example_tts_nano.py`) disagreed with a third (a direct source read of
`tts_turbo.py` on `master`), documented honestly above rather than
picking one silently. The code was syntax-checked and exercised with
targeted unit-level tests -- the chunker's abbreviation handling, the
Kokoro voice/language table, the project-save temp-file cleanup, V3's
character-preset blend math and project persistence round-trip,
`chatterbox_engine.py`'s persistent-worker lifecycle and JSON-lines
request building against a fake `Popen`, and `_chatterbox_worker.py`'s
own pure-Python logic (the CPU `map_location` patch, the perth/
setuptools check, the nano-kwarg fallback, error categorization) against
faked `torch`/`chatterbox`/`perth` modules -- and, for the wire protocol
itself, a REAL subprocess run of the real worker script under this
sandbox's plain Python (which has neither torch nor chatterbox-tts
installed), proving the JSON-lines framing and the OS-level stdout
hijack work end-to-end even though the actual synthesis call inside it
fails for a mundane, expected reason (`ModuleNotFoundError`). None of
this has been executed against real model files inside the actual GUI on
Windows, though -- and, per the numpy conflict discovered above, not
against the real `.venv-chatterbox` install/persistent-worker path
either. Budget time for a first real run to catch anything a static
read-through can't -- the Download Manager's network calls, the
DirectML session path, the espeak-ng/Python 3.11 winget install blocks,
and Chatterbox's separate-environment setup, persistent-worker path, and
model-tier selection are the newest, least-exercised code in this
delivery.

**A small, general UI polish pass, requested directly rather than driven
by a bug report:** four of the five panels' QGroupBox titles ("1-2.
Source Text & Language", "3. Translation Target", "5-7. TTS Engine,
Voice & Speech Settings", "8-9. Audio Preview & Export") carried this
project's own internal spec numbering ("GUI areas 1-2", "areas 3", ...)
straight into the shipped app -- meaningless, and slightly confusing, to
someone using TTS Studio rather than reading the document it was built
from (SectionsPanel's own title, "Sections," never had this problem,
since it didn't map to a single numbered spec area to begin with -- see
translation_panel.py's docstring on why area 4 became this table
instead). The numbers are gone now; the titles read the same otherwise.
Separately, `MainWindow`'s window title had "(V3)" hard-coded in four
places, three of which were already stale after V4 shipped -- replaced
with a single `_APP_TITLE` constant so there's exactly one place to
update (or not: dropping the version number from the title entirely
avoids the staleness problem outright, which is why that's what was done
instead). Also added: light amber/green/red color-coding on the
Sections table's Status column (on top of the text labels already
there), a bold-but-colorless `QGroupBox` title style applied once at the
`QApplication` level in `run.py` rather than duplicated per panel, and
a little more spacing between the five stacked panels. The stylesheet
in `run.py` deliberately sets only font-weight and spacing, nothing
color-related -- an app-wide QSS that hard-codes background/foreground
colors is the classic way to make an app look right on whatever OS theme
it happened to be tested against and wrong on every other one (a
light-mode color fighting a user's dark-mode Windows, or vice versa);
font-weight has no such interaction with the palette. None of this could
be visually verified against a real running window in this sandbox (no
PySide6 install available here -- see the "Nothing in this sandbox could
be installed or run end-to-end" note below), so it's worth a look on an
actual Windows machine before assuming it reads the way intended.

**Chatterbox's native-controls follow-up pass (Expression/CFG/presets/
sound tags) was scoped down from a much larger proposal, and every claim
in that proposal was independently checked against Chatterbox's actual
source before anything was built -- not trusted from a description or a
README skim.** That check also incidentally resolved an old open
question from this document: an earlier pass had noted a discrepancy
about whether Chatterbox's Turbo/Nano path exposed a `nano=` kwarg and a
`NANO_REPO_ID` constant; re-checking upstream source now confirms both
are genuinely present, so that discrepancy is resolved rather than still
open. Three design decisions are worth recording. First, **style
presets are a quick-fill, not stored state**: selecting "Storyteller" or
"Creative" from the preset dropdown just writes numbers into the
Expression/CFG/Temperature/etc. sliders once, the same as if the user
had dragged them there by hand -- no preset *name* is saved anywhere in
`SynthesisSettings` or `Project`, only the resulting numbers are. This
avoids an ambiguous state where a saved project claims to be "Dramatic"
but its sliders have since been hand-edited away from that preset's
values; it also means the preset value tables themselves (in
`tts_panel.py`'s `_ORIGINAL_PRESETS`/`_TURBO_NANO_PRESETS`) are
starting points worth tuning by ear, not verified defaults the way
Chatterbox's own per-field defaults are. Second, **tier-gating is
centralized in one function, not scattered across the GUI**:
`_chatterbox_worker.py`'s `_sampling_kwargs_for_tier()` is the only
place that decides which sampling kwargs reach `model.generate()`,
independent of whatever the request dict contains -- so even a
malformed request, or a value carried over from an old saved project
for a since-changed voice, can't hand Original's `exaggeration`/
`cfg_weight`/`min_p` to Turbo/Nano's `generate()` or a `top_k` to
Original's (which has no such parameter and would raise `TypeError`).
Third, **sound tags were inserted as plain text, with an honest
translation caveat documented directly in `source_panel.py`**: `[laugh]`/
`[chuckle]`/`[cough]` were documented as real Chatterbox Turbo/Nano
tokens in upstream's own README, not invented for this app, and Argos
Translate has no concept of "leave this bracketed span alone," so a tag
typed before translation could come back reworded or dropped --
inserting it after translating (or with matching source/target
languages) avoided the risk. This feature was removed entirely in a
later pass -- see this section's final entry below for that story; the
paragraph above is kept as a record of what was tried and why, not as
documentation of a still-current feature. As with every other GUI change
in this project, none of the new
sliders, preset dropdown, sound-tag buttons (while they existed), or the
collapsible Advanced section could be visually verified against a real
running window in this sandbox. Deliberately **out of
scope for this pass**, per the user's own choice when asked how to scope
it down: a Speed control via ffmpeg's `atempo` filter, a semitone-shift
Pitch control, a "Normalise final audio" checkbox, and the
reference-conditional caching optimization (Chatterbox's own
`generate()` only re-runs `prepare_conditionals()` when
`audio_prompt_path` is passed; this app currently passes it on every
call, redoing that work every section even when the reference clip
hasn't changed) -- all four are real, confirmed-against-source
candidates for a future pass, not abandoned ideas.

**A real user hit two UI bugs in this same native-controls pass, both
fixed directly from a screenshot rather than guessed at.** First, the
Style preset combo box (`tts_panel.py`) rendered its longest entry
clipped -- "Storyteller" showed as "Storytelle" -- because a plain
`QComboBox`'s default size hint doesn't reliably grow to fit its widest
item. The first attempt at a fix,
`setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)`,
turned out to be insufficient and the user caught it: that policy sizes
the box to whatever's *currently loaded* in it, but this combo's
contents are swapped out on every tier switch (Original's five-entry
preset list vs. Turbo/Nano's three-entry one -- see
`_apply_chatterbox_controls()`), so the box stayed sized for whichever
list loaded first (Original's, with "Storyteller") and didn't reliably
widen for the other tier's own labels when switching to it. The real
fix computes the single longest label across *both* tiers' preset
tables once, up front
(`_LONGEST_PRESET_LABEL_LENGTH` in `tts_panel.py`), and uses
`setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy
.AdjustToMinimumContentsLengthWithIcon)` with
`setMinimumContentsLength()` set to that value -- a fixed floor width
guaranteed to fit anything either tier's list can ever contain, rather
than one re-derived from whatever happens to be loaded at the moment.
Second, and more structural: every call to
`MainWindow._set_status()` was writing the identical message to *two*
places on screen at once -- Qt's own bottom-of-window `statusBar()` and
`OutputPanel`'s own status label inside the "Audio Preview & Export" box
-- so "Audio generation complete." (and every other status message)
visibly appeared twice simultaneously, and the two weren't even
perfectly in sync (a handful of call sites, like `load_audio()` and
`_rejoin_and_preview()`'s "No audio generated yet.", only ever updated
the output-panel label directly, never the status bar). Per the user's
own framing -- one readout panel should do all readouts -- the fix
removes the native Qt status bar from the app entirely rather than
picking a way to keep both in sync: `_set_status()` now writes only to
`self.output_panel.status_label`, and the one other direct caller
(`__init__`'s startup "Ready" message) was switched to go through the
same label. This was a plain refactor, not a judgment call about which
of the two displays was more "correct" -- there was never a reason for
this app to have two independent status readouts in the first place,
and consolidating onto the one that was already visible in the main
window layout (rather than the OS-chrome status bar easy to miss at the
very bottom of the window) means every status message the app produces,
audio-related or not, now has exactly one place it appears. As with
every other GUI fix in this project, this could not be visually
re-verified against a real running window in this sandbox -- only
confirmed by reading through every `_set_status`/`output_panel.set_status`
call site to check none of them still assume a second display exists.

**Speed and Pitch for Chatterbox (the second native-controls follow-up
pass) reuse the same architecture pattern as every other capability
flag in this app, rather than inventing a new "DSP pipeline" concept.**
Piper/Kokoro already implement Speed as part of their own model-level
synthesis (Piper's `--length-scale`, Kokoro's `speed` kwarg); the
question for Chatterbox was whether to bolt a *shared, engine-agnostic*
DSP step onto `MainWindow`/`AudioProcessor` that every engine's audio
would flow through, or to let Chatterbox's own `synthesize()` satisfy
the same `Voice.supports_speed`/`supports_pitch` capability flags
Piper/Kokoro already use, just by a different mechanism internally. The
latter won: `chatterbox_engine.py`'s `synthesize()` now runs its own
worker's raw output through `_apply_speed_and_pitch()` (ffmpeg) before
handing back a `SynthesisResult`, exactly the same place `_read_and_
apply_gain()` already handles Volume -- no interface change to
`TTSEngine`, no new shared pipeline, and Piper/Kokoro are completely
unaffected since they never call this function at all. The one genuine
addition to the shared data model is `Voice.speed_range`/`pitch_range`
(see core/models.py) -- since a naive resample/time-stretch DSP
approach sounds acceptable over a much narrower range than a native
model-level implementation, hard-coding "narrower for Chatterbox" into
the GUI by engine name would have broken the capability-flag
philosophy this app has followed since V1; instead, each `Voice`
declares its own safe range, and `TTSPanel._apply_voice_capabilities()`
reads it generically the same way it reads every other flag. Ordering
inside `synthesize()` matters and is called out directly in a code
comment there: Speed/Pitch DSP has to run *before* `_read_and_apply_
gain()`, not after, because time-stretching changes the file's
duration -- computing `duration_seconds` from a gain-adjusted read of
the *pre*-DSP file would report the wrong length. Pitch is genuinely
new territory for this app, not a Chatterbox-catching-up-to-Piper/
Kokoro story: neither of those two has ever supported Pitch, native or
otherwise, so Chatterbox is the first voice in this app able to pitch-
shift at all. **"Normalise final audio"** is a much smaller, standalone
addition -- plain peak normalization (scale so the loudest sample sits
just under full scale), deliberately not loudness/LUFS normalization,
which would be substantially more DSP than "even out sections that
came out at different volumes" needs; it lives in `AudioProcessor`
(engine-agnostic, like `join()`/`export()`) rather than inside any one
engine, since it operates on the *joined* final clip, not any single
section's own audio. Both pieces were verified with real tests against
real ffmpeg (available in this sandbox, unlike a second Python
environment or chatterbox-tts itself) and real WAV files written via
Python's stdlib `wave` module -- see test_chatterbox_speed_pitch_dsp_v4.py's
own docstring for why that test file's fakes are deliberately different
from test_chatterbox_engine_v4.py's -- so unlike most of this project's
GUI-adjacent work, the actual DSP correctness here did NOT have to rely
solely on reading the code carefully; only the GUI sliders/checkbox
built around it are subject to the usual "not visually verified in a
real window" caveat.

**The Turbo/Nano sound-tag insert buttons (`[laugh]`/`[chuckle]`/
`[cough]`) were removed entirely, in the round right after the Speed/
Pitch pass above, on direct real-world evidence rather than a change of
mind about the design.** All three tags were confirmed present in
chatterbox's own README as real, working, Turbo/Nano-specific tokens
before they were added -- that part of the earlier verification was
accurate. What it couldn't confirm, since no PySide6/Chatterbox
install is possible in this sandbox, was whether they actually did what
the README claimed once wired into a real app and run against a real
model. A user who could actually run the app reported that `[laugh]`/
`[chuckle]` produced no laugh/chuckle sound in practice, and asked for
all three buttons to come out rather than leaving the one unreported tag
(`[cough]`) behind alone. That request was honored as given, not
second-guessed -- there was no independent way in this sandbox to
confirm or dispute whether `[cough]` itself worked, so the honest move
was to remove what was asked and say so, not to guess at keeping
something back. The removal took out the whole vertical slice that
existed only to support it: `source_panel.py`'s button row and
`_on_insert_sound_tag()`/`set_sound_tags_visible()` methods, the
`_SOUND_TAGS` constant, `TTSPanel`'s `voice_changed` signal, and
`MainWindow._on_tts_voice_changed()` -- that signal and handler existed
for no other reason than bridging this one feature across panels, so
keeping them after the feature was gone would have been dead code, not
caution. `Voice.supports_sound_tags` was renamed to
`supports_turbo_nano_presets` rather than deleted outright, since it
still does real work: distinguishing the Turbo/Nano tier family from
Original for the Style preset dropdown (see the native-controls pass
above) never had anything to do with sound tags specifically -- it just
happened to be gated by the same nano/turbo-vs-original split, and kept
the old name past the point where that name stopped describing what the
flag actually did. This is the first removal-driven-by-real-usage entry
in this project's history rather than a removal driven by something
caught through static reasoning or a screenshot -- worth remembering as
a reminder that this sandbox's verification (source-diving, compiling,
running the test suite) proves the code does what it's written to do,
not that what it's written to do is what a real user experiences.

**Reference-conditional caching was re-verified against real upstream
source immediately before implementing it, not assumed correct from the
earlier pass's own notes.** The original claim (from the first
native-controls pass) was that `ChatterboxTTS.generate()`/
`ChatterboxTurboTTS.generate()` only call `prepare_conditionals()` when
`audio_prompt_path` is truthy. Both `tts.py` and `tts_turbo.py` were
fetched fresh and reproduced verbatim before writing
`_sync_reference_conditionals()`, confirming the claim exactly:
`if audio_prompt_path: self.prepare_conditionals(...)  else: assert
self.conds is not None`, in both files, word for word. That direct read
is also what surfaced the revert bug described in section H's third
follow-up entry -- it isn't something a test caught first; reading
`generate()`'s actual `else` branch made it obvious that omitting
`audio_prompt_path` can never, on its own, undo a previous
`prepare_conditionals()` call, since there is no other code path that
touches `self.conds` at all. The fix's correctness rests on one
assumption worth stating plainly: that `model.conds` mutates by
*rebinding* (`self.conds = Conditionals(...)` inside
`prepare_conditionals()`) rather than by mutating the existing
`Conditionals`/`T3Cond` objects in place for the reference-clip identity
itself. This is true of both `prepare_conditionals()` implementations as
read directly from source -- the only in-place mutation either
`generate()` does to an existing `self.conds` is `Original`'s own
exaggeration-update block (`self.conds.t3 = T3Cond(...)`, itself a
rebind of `.t3`, not a tensor edit), which doesn't touch speaker
identity and therefore doesn't invalidate stashing a plain reference to
`model.conds` right after load as "the default to revert to." Turbo/
Nano's `generate()` has no equivalent exaggeration-update block at all
(it warns and ignores exaggeration/cfg_weight/min_p unconditionally
instead, matching what `Voice.supports_expression=False` for those
tiers already assumed), so the same reasoning applies there even more
directly. None of this could be verified against a real chatterbox
install in this sandbox (same standing limitation as everywhere else in
this document) -- what raises the confidence here above the project's
usual "read the code carefully" baseline is that the reasoning follows
directly from source reproduced verbatim in this same session, not
recalled from an earlier pass or trusted from a summary.

**A fourth V4 follow-up pass addressed visual clutter -- its first
attempt made a real user's window worse, which is itself worth
documenting honestly.** A real user reported the app as "cluttered and
busy" overall, and, when asked which specifically, flagged both
`TTSPanel` itself (by far the busiest of the five stacked panels) and
the whole window's general density, while explicitly preferring the
least invasive of three offered options: keep every control exactly
where it already is, and make related groups of controls read as
groups, rather than collapsing sections behind toggles or restructuring
into tabs.

That first attempt did exactly that -- `run.py`'s app-wide stylesheet
gained a touch more `QGroupBox` margin/padding, `main_window.py`
widened the spacing between the five stacked panels from 10px to 18px,
and `tts_panel.py` gained three new bold sub-heading labels plus
`addSpacing()` calls between clusters of controls within rows -- and the
same real user reported it back as worse: "tts got bigger, everything
else got harder to see." The reasoning gap, found only after that
report: `MainWindow` stacks its five panels in one fixed-size,
non-scrolling window (see `main_window.py`'s central `QVBoxLayout`), and
only two widgets in that whole window have an *expanding* vertical size
policy and therefore grow to fill whatever room is left over once every
other widget takes its own natural size -- `SourcePanel`'s `QTextEdit`
and `SectionsPanel`'s `QTableWidget`. Every one of `TTSPanel`'s rows,
`QGroupBox` margins included, has a fixed (non-expanding) size policy.
Concretely, that means any extra height added to `TTSPanel` -- or to any
of the other three fixed-size panels, or to the spacing between all
five -- doesn't come from empty space in the window; it comes directly
out of the text box's and the table's shared allotment, shrinking
whichever of the two the layout happens to shrink first. Three new
label rows plus wider inter-panel spacing was enough added height, in
this real user's actual window, to visibly shrink both -- exactly the
"everything else got harder to see" report. This was a genuine analysis
gap in the first attempt, not a typo or an untested edge case: nothing
about "add labels and spacing to one already-visible panel" reads as
risky in isolation, and it wasn't caught beforehand because this
sandbox cannot render the real window to see the space competition play
out -- it only became visible once a real user's window showed it.

The corrected fix: the spacing/margin bump in `run.py` and
`main_window.py` was reverted back to its original values, and the
three sub-heading labels in `tts_panel.py` were removed rather than
kept. In their place, `tts_panel.py`'s Expression/Voice Guidance/Style
preset controls -- previously always visible for any Chatterbox voice --
now sit behind a new `chatterbox_tuning_toggle` (a `QToolButton`,
collapsed by default), the exact same collapsible-container pattern its
existing "Advanced sampling controls" toggle already used, wired
through `_apply_chatterbox_controls()` the same way (the toggle itself
hidden for a voice that doesn't support it, and reset to unchecked when
it stops applying). Unlike the first attempt, this *reduces* `TTSPanel`'s
usual height rather than spending more of the shared budget: for any
Chatterbox voice, the panel now shows one collapsed toggle row instead
of the full Expression/Guidance/Style preset row, by default -- smaller
than even the pre-complaint baseline, not just back to it. The harmless
half of the first attempt (small `addSpacing()` calls *within* rows in
`tts_panel.py`, `source_panel.py`, `translation_panel.py`, and
`output_panel.py` -- horizontal only, so they don't compete with the
text box/table for vertical room) was left in place. `source_panel.py`'s
`text_edit` and `sections_panel.py`'s `table` also each gained a
`setMinimumHeight()` floor (120px / 160px) as a defensive measure, so
neither can be squeezed to a sliver again regardless of what any future
change does elsewhere in the window -- a floor, not a fixed size; both
can still grow larger. None of this could be visually confirmed in this
sandbox either (no real PySide6 render available, same standing
limitation as everywhere else in this document) -- what's different
this time is that the fix is informed by an actual real-window report of
what went wrong, not just code-reading confidence, which is exactly why
the analysis above is written out in this much detail: it's the
reasoning that was missing the first time.

---

## J. Next steps

V3 is implemented in full: the in-app Download Manager (separate
Language and Voice dialogs -- see section E's note on
`gui/resource_manager.py` for why they're not tabs in one dialog --
each supporting both install AND remove now, not install-only), Kokoro
character presets, DirectML wiring for Kokoro, and automatic espeak-ng
installation via the Windows installer. LibreTranslate was also built
as a second translation engine during V3, then removed again by
request -- see section C for the evaluation and section I for the
design lesson from having built it. Argos remains the sole translation
engine going forward.

V4, as described in section H above, adds this app's first voice-cloning
engine: **Chatterbox** (MIT code + MIT weights, installed by default --
see section F for why that changed from its initial opt-in-only
release), plus one new optional `TTSEngine.run_diagnostics()` hook added
to the interface itself (see section H) so the GUI's "Diagnose..."
button works generically instead of hard-coding the Chatterbox name --
every other engine simply inherits the default `None` implementation
and is unaffected. It also ships with a reference-audio picker in the
GUI that only appears for cloning-capable voices (the same
capability-flag pattern the app already uses everywhere else), and,
after the persistent-worker rewrite in this pass, three selectable
model tiers (Nano, Turbo, Original) that appear as ordinary entries in
the existing voice dropdown rather than a new control. A V4 follow-up
pass then added Chatterbox's own native generation-time controls
(Expression/Voice Guidance/Temperature/Top-P/Top-K/Min-P/
Repetition-penalty, gated per tier, plus style presets and Turbo/Nano
sound tags) -- see section H's item 4 and section I for the full detail
and the design decisions behind it. Next up: **Qwen3-TTS** as a second
cloning engine (Apache-2.0, but newer and less battle-tested -- see
section B), and wiring up Chatterbox's own Multilingual V3 (23
languages) once its exact language/variant-selection codes are
confirmed against source rather than guessed (see section I) -- Turbo
and Nano are no longer on this list, since both are now implemented and
selectable. A second V4 follow-up pass then picked up the items
deferred from the first one -- Speed and Pitch (both ffmpeg DSP, see
section H's item 4 and section I) and "Normalise final audio" -- so
those are no longer open either. A third V4 follow-up pass implemented
the **reference-conditional-caching performance optimization**
(Chatterbox's own `generate()` only re-runs `prepare_conditionals()`
when `audio_prompt_path` is passed; this app used to pass it on every
call, redoing that work every section even when the reference clip
hadn't changed -- see section H's item 4 and section I), so that's no
longer open either; that same pass also removed the Turbo/Nano sound-tag
insert buttons entirely after real-world testing showed two of the
three didn't work (see section H's item 4 and section I). A fourth V4
follow-up pass then addressed the app reading as "cluttered and busy"
overall; its first attempt (spacing/grouping only, no collapsing) made
a real user's window worse, not better, and was reverted in favor of
collapsing `tts_panel.py`'s Expression/Voice Guidance/Style preset
controls behind a toggle, off by default -- see section H's item 4 and
section I for the full story, including why the first attempt backfired.
Two smaller items are still worth picking up:
revisiting Piper's CLI for a DirectML flag if `OHF-Voice/piper1-gpl`
ever adds one, and deciding whether Chatterbox's reference-audio clip
should be copied into the project directory for full portability (see
section I's note on why it currently isn't).
