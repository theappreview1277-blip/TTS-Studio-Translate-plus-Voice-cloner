#!/usr/bin/env python3
"""
TTS Studio entry point.

    python run.py
"""
from __future__ import annotations

import logging
import os
import shutil
import sys
from pathlib import Path


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )


def _check_optional_system_deps() -> list[str]:
    """
    Non-fatal startup checks. The app runs without these -- Piper bundles
    its own phonemization, and WAV/FLAC export need neither -- but
    Kokoro's non-English languages need espeak-ng, and MP3/OGG export
    need FFmpeg, so we warn early instead of failing deep inside a
    synthesis/export call with no context.
    """
    warnings = []
    if shutil.which("espeak-ng") is None:
        warnings.append(
            "espeak-ng wasn't found on PATH. Kokoro voices for non-English "
            "languages may not work correctly until it's installed."
        )
    if shutil.which("ffmpeg") is None:
        warnings.append(
            "FFmpeg wasn't found on PATH. Not required for WAV/FLAC export, "
            "but MP3 and OGG export need it."
        )
    return warnings


def main() -> int:
    # Windows shortcuts do not reliably start in the application folder.
    # Make every relative model/settings path resolve beside this file.
    os.chdir(Path(__file__).resolve().parent)
    _configure_logging()
    logger = logging.getLogger("tts_studio")

    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
    except ImportError:
        print(
            "PySide6 isn't installed. Run: pip install -r requirements.txt",
            file=sys.stderr,
        )
        return 1

    app = QApplication(sys.argv)
    app.setApplicationName("TTS Studio")
    # Deliberately minimal and color-free: this only adds a bit of visual
    # hierarchy to each panel's QGroupBox title (bold, with a little
    # breathing room above/below) so the five stacked panels read as
    # distinct sections at a glance. Nothing here sets a background or
    # foreground color for ordinary widgets -- that's the kind of app-wide
    # stylesheet change that looks fine on whatever OS theme it was
    # tested against and wrong on every other one (a light-mode color
    # baked in would fight a user running Windows in dark mode, and vice
    # versa); font-weight and spacing don't have that problem, since they
    # don't interact with the palette at all.
    app.setStyleSheet(
        """
        QGroupBox {
            font-weight: 600;
            margin-top: 14px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 8px;
            padding: 0 4px;
        }
        """
    )
    # A later follow-up tried nudging QGroupBox's own margin/padding up
    # further plus adding little bold sub-heading labels inside TTSPanel,
    # in response to a real user finding the app "cluttered and busy."
    # That made things worse, not better, for a real user, and was
    # reverted back to these original values: MainWindow stacks all five
    # panels in one fixed-size, non-scrolling window, with SourcePanel's
    # text box and SectionsPanel's table the only two widgets set up to
    # *expand* into whatever room is left over. Every pixel of extra
    # height added to a panel that DOESN'T expand (this one included)
    # comes directly out of that shared leftover space -- so adding
    # padding/margin/heading rows to make one panel "read as more
    # organized" made the text box and the sections table visibly
    # smaller at the same time, which is a worse trade than the original
    # clutter. See TTSPanel's own comment (near its new "Chatterbox voice
    # tuning" toggle) for the fix that was tried instead: making a
    # section collapsible by default, which *reduces* the height budget
    # rather than spending more of it.

    from tts_studio.gui.main_window import MainWindow

    window = MainWindow()

    for warning in _check_optional_system_deps():
        logger.warning(warning)

    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
