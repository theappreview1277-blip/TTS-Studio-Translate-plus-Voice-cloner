@echo off
setlocal
cd /d "%~dp0"
title TTS Studio
if not exist ".venv\Scripts\python.exe" (
  echo TTS Studio has not been installed yet.
  echo Double-click "Install TTS Studio.cmd" first.
  pause
  exit /b 1
)

rem Check-only, every launch, no environment changes here: chatterbox-tts's
rem "perth" watermarking dependency silently breaks if 'setuptools' isn't
rem present, or if it's present but too new (setuptools removed the
rem pkg_resources module perth needs outright in v82.0.0 -- see
rem requirements-chatterbox.txt for the full story, confirmed against
rem setuptools's own changelog).
rem
rem An earlier version of this line ran `pip install setuptools` here on
rem every launch. Two problems with that, found from real feedback: (1)
rem installing/modifying packages every time the app opens -- reaching
rem out to the network before the person has even asked to generate
rem anything -- is its own kind of surprising, silent environment change,
rem the same objection that already got a similar runtime `pip install`
rem removed from _chatterbox_worker.py. (2) it didn't even work: an
rem unpinned `pip install setuptools` is a no-op whenever ANY setuptools
rem is already present, even a broken too-new one, so it could report
rem success every single launch while never actually fixing anything.
rem
rem So this only checks now, and does not touch the environment. If
rem something needs installing or re-pinning, that happens in
rem "Install TTS Studio.cmd" (windows_install.ps1), which already pins
rem the exact setuptools version -- itself still just a double-click, no
rem command prompt needed. Every other engine works fine regardless of
rem what this check finds, so it never blocks startup.
if exist ".venv-chatterbox\Scripts\python.exe" (
  ".venv-chatterbox\Scripts\python.exe" -c "import pkg_resources" >nul 2>&1
  if errorlevel 1 (
    echo Note: Chatterbox's voice-cloning setup needs a repair -- run "Install TTS Studio.cmd" again to fix it automatically. Every other voice/engine in TTS Studio is unaffected.
    echo.
  )
)

".venv\Scripts\python.exe" run.py
if errorlevel 1 (
  echo.
  echo TTS Studio stopped because of an error. See the message above.
  pause
)
