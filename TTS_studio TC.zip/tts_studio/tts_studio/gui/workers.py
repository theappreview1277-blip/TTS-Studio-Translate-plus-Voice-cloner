"""
Background workers.

Translation and speech synthesis can each take anywhere from
milliseconds to tens of seconds. Everything here runs on a QThread so
the window never freezes, with progress/results delivered back to the
GUI thread through Qt signals (the only thread-safe way to touch
widgets).

V2 change from V1: workers now operate on a *list of sections* instead
of one opaque blob of text, so "Translate All" / "Generate All Audio"
and a single row's "Regenerate" share the same code path (a list of
length 1 is just a small batch) -- and a failure on one section is
reported and skipped rather than aborting the whole batch, so a typo
in section 7 doesn't stop sections 1-6 and 8-20 from finishing.
"""
from __future__ import annotations

from PySide6.QtCore import QThread, Signal

from tts_studio.audio.audio_processor import AudioProcessor
from tts_studio.core.exceptions import TTSStudioError
from tts_studio.core.interfaces import TranslationEngine, TTSEngine
from tts_studio.core.models import SynthesisSettings, TextSection
from tts_studio.text_processing.chunker import ChunkerOptions, ChunkMode, TextChunker

# Conservative per-synthesize()-call limit, safely under Kokoro's ~510
# -token cap. Sections are usually already this size or smaller (the
# user picked a chunk mode/length), but nothing stops someone from
# choosing PARAGRAPH mode on a huge paragraph -- so synthesis silently
# sub-chunks and rejoins any one section that's still too big, the same
# safety net V1 applied to the whole document.
_SYNTHESIS_SUBCHUNK_LIMIT = 400


class LanguageDetectionWorker(QThread):
    finished_ok = Signal(str, float)  # language_code, confidence
    failed = Signal(str)

    def __init__(self, engine: TranslationEngine, text: str):
        super().__init__()
        self._engine = engine
        self._text = text

    def run(self) -> None:
        try:
            result = self._engine.detect_language(self._text)
            self.finished_ok.emit(result.language_code, result.confidence)
        except TTSStudioError as exc:
            self.failed.emit(exc.full_message)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(f"Unexpected error during language detection: {exc}")


class SectionsTranslationWorker(QThread):
    """Translates each of `sections` in turn, reporting per-section."""

    section_done = Signal(int, str)  # section index, translated text
    section_failed = Signal(int, str)  # section index, user-facing message
    all_done = Signal()
    progress = Signal(int, int, str)  # done, total, status message -- V3, for MainWindow's status bar

    def __init__(self, engine: TranslationEngine, sections: list[TextSection], source_lang: str, target_lang: str):
        super().__init__()
        self._engine = engine
        self._sections = sections
        self._source_lang = source_lang
        self._target_lang = target_lang

    def run(self) -> None:
        total = len(self._sections)
        for position, section in enumerate(self._sections, start=1):
            self.progress.emit(position, total, f"Translating section {position} of {total}...")
            try:
                translated = self._engine.translate(section.source_text, self._source_lang, self._target_lang)
                self.section_done.emit(section.index, translated)
            except TTSStudioError as exc:
                self.section_failed.emit(section.index, exc.full_message)
            except Exception as exc:  # noqa: BLE001
                self.section_failed.emit(section.index, f"Unexpected error: {exc}")
        self.all_done.emit()


class SectionsSynthesisWorker(QThread):
    """Synthesizes each of `sections` in turn, one audio file per section."""

    section_done = Signal(int, object)  # section index, SynthesisResult
    section_failed = Signal(int, str)  # section index, user-facing message
    all_done = Signal()
    progress = Signal(int, int, str)  # done, total, status message -- V3, for MainWindow's status bar

    def __init__(self, engine: TTSEngine, sections: list[TextSection], settings: SynthesisSettings):
        super().__init__()
        self._engine = engine
        self._sections = sections
        self._settings = settings
        self._audio = AudioProcessor()

    def run(self) -> None:
        total = len(self._sections)
        for position, section in enumerate(self._sections, start=1):
            # Ask the engine whether this particular call is expected to
            # be unusually slow for a reason that has nothing to do with
            # this section's text (see TTSEngine.warmup_notice -- added
            # after a real user watched this exact progress message sit
            # frozen for several minutes during Chatterbox's first model
            # load and reasonably assumed the app had hung). Generic
            # across engines: this is a no-op for anything that doesn't
            # override the hook.
            notice = self._engine.warmup_notice(self._settings)
            status = notice or f"Generating audio {position} of {total}..."
            self.progress.emit(position, total, status)
            text = section.translated_text or section.source_text
            if not text or not text.strip():
                self.section_failed.emit(section.index, "Nothing to synthesize for this section.")
                continue
            try:
                result = self._synthesize_safely(text)
                self.section_done.emit(section.index, result)
            except TTSStudioError as exc:
                self.section_failed.emit(section.index, exc.full_message)
            except Exception as exc:  # noqa: BLE001
                self.section_failed.emit(section.index, f"Unexpected error: {exc}")
        self.all_done.emit()

    def _synthesize_safely(self, text: str):
        if len(text) <= _SYNTHESIS_SUBCHUNK_LIMIT:
            return self._engine.synthesize(text, self._settings)

        pieces = TextChunker().chunk(
            text, ChunkerOptions(mode=ChunkMode.AUTOMATIC, max_chunk_chars=_SYNTHESIS_SUBCHUNK_LIMIT)
        )
        clips = []
        piece_paths: list[str] = []
        first_result = None
        for piece in pieces:
            result = self._engine.synthesize(piece.source_text, self._settings)
            first_result = first_result or result
            samples, rate = self._audio.load(result.samples_path)
            clips.append((samples, rate))
            piece_paths.append(str(result.samples_path))
        joined_samples, joined_rate = self._audio.join(clips)

        import os
        import tempfile

        fd, path_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_section_")
        os.close(fd)
        joined_path = self._audio.export_wav(joined_samples, joined_rate, path_str)

        # Each sub-chunk's own temp WAV (from self._engine.synthesize()
        # above) has now been read into `clips` and joined -- nothing
        # references those individual files any more, so clean them up
        # immediately rather than leaving them in the OS temp folder for
        # the rest of the session. (joined_path itself is NOT deleted
        # here: it's the section's actual result and stays referenced by
        # TextSection.audio_path until the section is regenerated, the
        # project is saved, or the app closes -- see MainWindow.)
        for p in piece_paths:
            try:
                os.unlink(p)
            except OSError:
                pass

        from tts_studio.core.models import SynthesisResult

        return SynthesisResult(
            samples_path=joined_path,
            sample_rate=joined_rate,
            duration_seconds=len(joined_samples) / joined_rate,
            engine=first_result.engine,
            voice_id=first_result.voice_id,
        )
