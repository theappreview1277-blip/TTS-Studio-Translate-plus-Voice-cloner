"""TTS Engine, Voice && Speech Settings panel (GUI areas 5-7).

Key design point from the spec: "expose only controls that the
selected engine actually supports" -- e.g. don't show a pitch slider
for a voice that can't pitch-shift. This panel reads capability flags
straight off the selected `Voice` object (see core.models.Voice) and
shows/hides/disables controls accordingly, instead of hard-coding
per-engine behaviour here.

V2 note: this panel no longer has its own "Generate Speech" button.
Since generation now happens per-section (SectionsPanel's "Generate
All Audio" / per-row "Regenerate"), this panel's job is just to hold
the *shared* engine/voice/speed/volume/pitch settings that those
section-level actions read when they run.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from tts_studio.core.models import CHARACTER_PRESETS, SynthesisSettings, Voice

# Chatterbox "style" presets (V4 follow-up) -- quick-fill buttons for the
# Expression/Voice Guidance/Advanced sliders below, not a value stored in
# SynthesisSettings/Project themselves: picking one just sets the
# underlying numeric fields to known-good starting values, the same as a
# user could type in by hand. That keeps "what does this project actually
# use" unambiguous (always just the numbers, never "preset X, possibly
# hand-edited since") and means there's no separate concept to keep in
# sync if the user tweaks a slider afterward -- see tts_panel.py's
# _apply_preset() docstring.
#
# Original's three values (exaggeration, cfg_weight, temperature) and
# Turbo/Nano's three (temperature, top_p, repetition_penalty) come
# directly from the numbers suggested during review; they're explicitly
# starting points to be listened to and tuned, not upstream-verified
# defaults the way SynthesisSettings' own field defaults are.
_ORIGINAL_PRESETS: list[tuple[str, str, float, float, float]] = [
    # (key, label, exaggeration, cfg_weight, temperature)
    ("natural", "Natural", 0.5, 0.5, 0.8),
    ("calm", "Calm", 0.25, 0.5, 0.7),
    ("storyteller", "Storyteller", 0.65, 0.4, 0.8),
    ("dramatic", "Dramatic", 0.8, 0.3, 0.9),
    ("consistent", "Consistent", 0.4, 0.6, 0.6),
]
_TURBO_NANO_PRESETS: list[tuple[str, str, float, float, float]] = [
    # (key, label, temperature, top_p, repetition_penalty)
    ("consistent", "Consistent", 0.6, 0.85, 1.25),
    ("natural", "Natural", 0.8, 0.95, 1.2),
    ("creative", "Creative", 1.0, 0.98, 1.15),
]
# The style-preset combo box is cleared and repopulated with a different
# list every time the selected voice's tier changes (Original's five
# entries vs. Turbo/Nano's three -- see _apply_chatterbox_controls()), so
# a sizing policy that measures only the *currently loaded* items (plain
# QComboBox.AdjustToContents) ends up choosing a width for whichever
# list happened to be loaded first and doesn't reliably widen back out
# for a longer label afterward -- a real user saw this: it looked fixed
# once Original ("Storyteller", this project's longest preset label) was
# selected, but was still clipped after switching to Turbo/Nano's own,
# shorter-but-still-real list. Computing the longest label across BOTH
# tiers' tables up front and using it as a fixed minimum character count
# (see __init__) gives the box one stable width that's guaranteed wide
# enough for anything either list can ever contain, independent of which
# one is loaded at the moment.
_LONGEST_PRESET_LABEL_LENGTH = max(
    len(label) for _key, label, *_values in (_ORIGINAL_PRESETS + _TURBO_NANO_PRESETS)
)

class TTSPanel(QWidget):
    engine_changed = Signal(str)  # engine registry key
    manage_voices_requested = Signal()  # V3: opens the Resource Manager on this engine's tab
    diagnose_requested = Signal()  # V4: runs the selected engine's run_diagnostics(), if it has one
    # A V4 follow-up briefly added a voice_changed signal here (fired
    # whenever the *selected voice* changed, not just the engine) purely
    # to bridge into SourcePanel's Turbo/Nano sound-tag insert buttons via
    # MainWindow._on_tts_voice_changed(). Both the buttons and this signal
    # were removed together once the sound-tags feature itself was pulled
    # (see chatterbox_engine.py's module docstring for why) -- there was
    # no other reason for MainWindow to react to a voice change separately
    # from an engine change, so keeping a single-purpose signal around
    # with nothing left to bridge would just be dead code.

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._voices: list[Voice] = []
        self._reference_audio_path: Optional[Path] = None
        self._updating_presets = False  # guards _on_style_preset_selected while repopulating the combo
        self._loaded_chatterbox_tier: Optional[str] = None  # last tier the Advanced/Expression fields were reset for

        # See source_panel.py's comment on its own QGroupBox for why this
        # no longer has a "5-7." prefix.
        group = QGroupBox("TTS Engine, Voice && Speech Settings")
        layout = QVBoxLayout(group)
        # This one box holds by far the most controls of the five panels
        # stacked in MainWindow -- engine/voice, speed/volume/pitch/
        # character, reference-audio cloning, and Chatterbox's own
        # expression/guidance/style/advanced-sampling controls, all
        # variously shown or hidden by capability. A real user found the
        # whole app "cluttered and busy," and a first attempt at fixing
        # this box specifically made it worse: extra layout spacing and
        # three new bold sub-heading labels read as more organized in
        # isolation, but MainWindow stacks all five panels in one
        # fixed-size, non-scrolling window (see main_window.py), and this
        # box doesn't expand to fill leftover space the way SourcePanel's
        # text box and SectionsPanel's table do -- so every pixel spent
        # making this box "look" more organized came directly out of
        # those two, shrinking them. What actually reduces clutter here
        # without spending more height is the "Chatterbox voice tuning"
        # toggle below (added in that same follow-up): Expression/Voice
        # Guidance/Style preset now default to collapsed, the same
        # progressive-disclosure pattern the "Advanced sampling controls"
        # toggle already used further down -- fewer controls visible by
        # default is what actually reads as "less busy," not more
        # spacing around the same controls.

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Engine:"))
        self.engine_combo = QComboBox()
        self.engine_combo.currentIndexChanged.connect(
            lambda _i: self.engine_changed.emit(self.engine_combo.currentData())
        )
        row1.addWidget(self.engine_combo)

        row1.addWidget(QLabel("Voice:"))
        self.voice_combo = QComboBox()
        self.voice_combo.currentIndexChanged.connect(self._on_voice_changed)
        row1.addWidget(self.voice_combo)
        row1.addSpacing(16)  # separates the Engine/Voice pickers from the action buttons that follow

        self.manage_button = QPushButton("Download Voices...")
        self.manage_button.setToolTip("Browse and install more Piper voices, or the Kokoro voice pack")
        self.manage_button.clicked.connect(self.manage_voices_requested)
        row1.addWidget(self.manage_button)

        # V4: generic "run this engine's deeper self-check" button --
        # not Chatterbox-specific in the GUI itself (see
        # TTSEngine.run_diagnostics()'s docstring); shown for every
        # engine but only meaningfully does something for one that
        # implements it, same as every other capability-flag control
        # here.
        self.diagnose_button = QPushButton("Diagnose...")
        self.diagnose_button.setToolTip(
            "Run a deeper check of the selected engine (model load + a short test clip), "
            "useful for troubleshooting without needing a command prompt"
        )
        self.diagnose_button.clicked.connect(self.diagnose_requested)
        row1.addWidget(self.diagnose_button)
        row1.addStretch(1)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Speed:"))
        self.speed_spin = QDoubleSpinBox()
        # Range set here is just the construction-time default -- see
        # _apply_voice_capabilities() below, which re-applies
        # voice.speed_range every time the selected voice changes (it's
        # narrower for a DSP-based implementation like Chatterbox's).
        self.speed_spin.setRange(0.5, 2.0)
        self.speed_spin.setSingleStep(0.05)
        self.speed_spin.setValue(1.0)
        row2.addWidget(self.speed_spin)
        row2.addSpacing(16)

        self.volume_label = QLabel("Volume:")
        row2.addWidget(self.volume_label)
        self.volume_spin = QDoubleSpinBox()
        self.volume_spin.setRange(0.0, 2.0)
        self.volume_spin.setSingleStep(0.05)
        self.volume_spin.setValue(1.0)
        row2.addWidget(self.volume_spin)
        row2.addSpacing(16)

        self.pitch_label = QLabel("Pitch:")
        row2.addWidget(self.pitch_label)
        self.pitch_spin = QDoubleSpinBox()
        # Same story as speed_spin above -- this is just the
        # construction-time default; voice.pitch_range overrides it per
        # voice once a Pitch-capable voice is actually selected.
        self.pitch_spin.setRange(-12.0, 12.0)
        self.pitch_spin.setSingleStep(1.0)
        self.pitch_spin.setValue(0.0)
        row2.addWidget(self.pitch_spin)
        row2.addSpacing(16)

        self.character_label = QLabel("Character:")
        row2.addWidget(self.character_label)
        self.character_combo = QComboBox()
        for key, label in CHARACTER_PRESETS:
            self.character_combo.addItem(label, userData=key)
        row2.addWidget(self.character_combo)
        row2.addStretch(1)
        layout.addLayout(row2)

        # V4: reference-audio picker for cloning-capable voices (currently
        # just Chatterbox). Hidden for every voice that doesn't set
        # supports_cloning=True, same capability-flag pattern as the
        # pitch/character controls above.
        row3 = QHBoxLayout()
        self.reference_audio_label = QLabel("Reference audio:")
        row3.addWidget(self.reference_audio_label)
        self.reference_audio_path_label = QLabel("(none \N{EN DASH} uses the engine's built-in voice)")
        row3.addWidget(self.reference_audio_path_label, 1)
        self.reference_audio_button = QPushButton("Choose Clip...")
        self.reference_audio_button.setToolTip(
            "Pick a short (~10s) clean speech clip; synthesis will clone that speaker's voice"
        )
        self.reference_audio_button.clicked.connect(self._on_choose_reference_audio)
        row3.addWidget(self.reference_audio_button)
        self.reference_audio_clear_button = QPushButton("Clear")
        self.reference_audio_clear_button.clicked.connect(self._on_clear_reference_audio)
        row3.addWidget(self.reference_audio_clear_button)
        layout.addLayout(row3)

        # V4 follow-up: Chatterbox's native "Expression"/"Voice Guidance"
        # controls (Original only -- see Voice.supports_expression) plus a
        # style-preset quick-fill, shown for any Chatterbox tier (Original
        # and Turbo/Nano each get their own preset list -- see
        # _apply_preset()). Hidden entirely for every non-Chatterbox voice,
        # same capability-flag pattern as everything else in this panel.
        #
        # Collapsed by default -- the fix for this panel reading as
        # "cluttered and busy" (see this method's opening comment).
        # Same collapsible-QToolButton pattern as "Advanced sampling
        # controls" below, and for the same underlying reason: most
        # people get good results from a tier's own defaults without
        # touching Expression/Voice Guidance/Style preset, so hiding them
        # behind one click actually shrinks this panel's usual height
        # instead of just rearranging the same amount of visible content.
        # The toggle button itself is shown/hidden by supports_style in
        # _apply_chatterbox_controls(), exactly like advanced_toggle is
        # tied to supports_advanced further down.
        tuning_header = QHBoxLayout()
        self.chatterbox_tuning_toggle = QToolButton()
        self.chatterbox_tuning_toggle.setText("Chatterbox voice tuning")
        self.chatterbox_tuning_toggle.setCheckable(True)
        self.chatterbox_tuning_toggle.setChecked(False)
        self.chatterbox_tuning_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.chatterbox_tuning_toggle.setArrowType(Qt.ArrowType.RightArrow)
        self.chatterbox_tuning_toggle.toggled.connect(self._on_chatterbox_tuning_toggled)
        tuning_header.addWidget(self.chatterbox_tuning_toggle)
        tuning_header.addStretch(1)
        layout.addLayout(tuning_header)

        self.chatterbox_tuning_container = QWidget()
        row4 = QHBoxLayout(self.chatterbox_tuning_container)
        row4.setContentsMargins(0, 0, 0, 0)
        self.expression_label = QLabel("Expression:")
        row4.addWidget(self.expression_label)
        self.expression_spin = QDoubleSpinBox()
        self.expression_spin.setRange(0.0, 1.0)
        self.expression_spin.setSingleStep(0.05)
        self.expression_spin.setValue(0.5)
        self.expression_spin.setToolTip(
            "Emotion, emphasis, and expressiveness (chatterbox-tts's 'exaggeration'). "
            "Higher also tends to speed up delivery."
        )
        row4.addWidget(self.expression_spin)

        self.guidance_label = QLabel("Voice Guidance:")
        row4.addWidget(self.guidance_label)
        self.guidance_spin = QDoubleSpinBox()
        self.guidance_spin.setRange(0.0, 1.0)
        self.guidance_spin.setSingleStep(0.05)
        self.guidance_spin.setValue(0.5)
        self.guidance_spin.setToolTip(
            "How closely delivery sticks to the reference voice/style (chatterbox-tts's "
            "'cfg_weight'). Lower values pace more deliberately -- upstream recommends "
            "lowering this for dramatic speech or a fast-talking reference clip."
        )
        row4.addWidget(self.guidance_spin)
        row4.addSpacing(16)

        self.style_preset_label = QLabel("Style preset:")
        row4.addWidget(self.style_preset_label)
        self.style_preset_combo = QComboBox()
        # A real user hit this, twice: QComboBox's default size hint
        # doesn't reliably grow to fit its longest item, so "Storyteller"
        # rendered clipped to "Storytelle" with no way to see the rest
        # short of opening the dropdown. The first fix
        # (QComboBox.AdjustToContents) measures only whatever's currently
        # loaded in the box, which isn't good enough here specifically
        # because this combo's contents change out from under it --
        # Original's five-entry list vs. Turbo/Nano's three-entry one,
        # repopulated on every tier switch (see
        # _apply_chatterbox_controls()) -- so it stayed sized for
        # whichever list loaded first and didn't reliably widen for the
        # other tier's labels afterward. Using
        # AdjustToMinimumContentsLengthWithIcon with a fixed
        # setMinimumContentsLength(), computed once from the single
        # longest label across *both* tiers' tables
        # (_LONGEST_PRESET_LABEL_LENGTH, above), gives the box one stable
        # width guaranteed to fit anything either tier's list can ever
        # contain, rather than re-deriving a width from whatever happens
        # to be loaded at the moment.
        self.style_preset_combo.setSizeAdjustPolicy(
            QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon
        )
        self.style_preset_combo.setMinimumContentsLength(_LONGEST_PRESET_LABEL_LENGTH)
        self.style_preset_combo.setToolTip(
            "Fills in the sliders below with a starting point -- pick one, then adjust "
            "further if you like. Not saved as a named preset: only the resulting values are."
        )
        self.style_preset_combo.currentIndexChanged.connect(self._on_style_preset_selected)
        row4.addWidget(self.style_preset_combo)
        row4.addStretch(1)
        self.chatterbox_tuning_container.setVisible(False)
        layout.addWidget(self.chatterbox_tuning_container)

        # V4 follow-up: collapsed by default -- token-sampling parameters
        # aren't something most users need to see, let alone understand,
        # to get good results (that's what the sliders/presets above and
        # the tier's own upstream defaults are for). A QToolButton with an
        # arrow, toggling a container's visibility, is the standard cheap
        # way to get a collapsible section out of stock Qt widgets without
        # pulling in a third-party one.
        advanced_header = QHBoxLayout()
        self.advanced_toggle = QToolButton()
        self.advanced_toggle.setText("Advanced sampling controls")
        self.advanced_toggle.setCheckable(True)
        self.advanced_toggle.setChecked(False)
        self.advanced_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.advanced_toggle.setArrowType(Qt.ArrowType.RightArrow)
        self.advanced_toggle.toggled.connect(self._on_advanced_toggled)
        advanced_header.addWidget(self.advanced_toggle)
        advanced_header.addStretch(1)
        layout.addLayout(advanced_header)

        self.advanced_container = QWidget()
        advanced_layout = QHBoxLayout(self.advanced_container)
        advanced_layout.setContentsMargins(0, 0, 0, 0)

        self.temperature_label = QLabel("Temperature:")
        advanced_layout.addWidget(self.temperature_label)
        self.temperature_spin = QDoubleSpinBox()
        self.temperature_spin.setRange(0.05, 2.0)
        self.temperature_spin.setSingleStep(0.05)
        self.temperature_spin.setValue(0.8)
        self.temperature_spin.setToolTip("Lower is more predictable; higher creates more variation.")
        advanced_layout.addWidget(self.temperature_spin)
        advanced_layout.addSpacing(12)

        self.top_p_label = QLabel("Top-P:")
        advanced_layout.addWidget(self.top_p_label)
        self.top_p_spin = QDoubleSpinBox()
        self.top_p_spin.setRange(0.0, 1.0)
        self.top_p_spin.setSingleStep(0.01)
        self.top_p_spin.setValue(1.0)
        self.top_p_spin.setToolTip("Controls generation variety.")
        advanced_layout.addWidget(self.top_p_spin)
        advanced_layout.addSpacing(12)

        self.top_k_label = QLabel("Top-K:")
        advanced_layout.addWidget(self.top_k_label)
        self.top_k_spin = QSpinBox()
        self.top_k_spin.setRange(1, 10000)
        self.top_k_spin.setValue(1000)
        self.top_k_spin.setToolTip("Turbo/Nano only. Limits sampling to the K most likely tokens.")
        advanced_layout.addWidget(self.top_k_spin)
        advanced_layout.addSpacing(12)

        self.min_p_label = QLabel("Min-P:")
        advanced_layout.addWidget(self.min_p_label)
        self.min_p_spin = QDoubleSpinBox()
        self.min_p_spin.setRange(0.0, 1.0)
        self.min_p_spin.setSingleStep(0.01)
        self.min_p_spin.setValue(0.05)
        self.min_p_spin.setToolTip("Original only. Filters unlikely speech tokens.")
        advanced_layout.addWidget(self.min_p_spin)
        advanced_layout.addSpacing(12)

        self.repetition_penalty_label = QLabel("Repetition penalty:")
        advanced_layout.addWidget(self.repetition_penalty_label)
        self.repetition_penalty_spin = QDoubleSpinBox()
        self.repetition_penalty_spin.setRange(1.0, 2.0)
        self.repetition_penalty_spin.setSingleStep(0.05)
        self.repetition_penalty_spin.setValue(1.2)
        self.repetition_penalty_spin.setToolTip("Reduces repeated words, sounds, and looping.")
        advanced_layout.addWidget(self.repetition_penalty_spin)
        advanced_layout.addStretch(1)

        self.advanced_container.setVisible(False)
        layout.addWidget(self.advanced_container)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(group)

        self._apply_voice_capabilities(None)

    # -- population ------------------------------------------------------
    def set_engines(self, engines: list[tuple[str, str]]) -> None:
        """engines: list of (registry_key, display_name)."""
        self.engine_combo.blockSignals(True)
        self.engine_combo.clear()
        for key, label in engines:
            self.engine_combo.addItem(label, userData=key)
        self.engine_combo.blockSignals(False)

    def set_voices(self, voices: list[Voice]) -> None:
        self._voices = voices
        self.voice_combo.blockSignals(True)
        self.voice_combo.clear()
        for voice in voices:
            self.voice_combo.addItem(voice.label(), userData=voice.id)
        self.voice_combo.blockSignals(False)
        self._on_voice_changed()

    def _on_voice_changed(self, *_args) -> None:
        self._apply_voice_capabilities(self.get_selected_voice())

    def _apply_voice_capabilities(self, voice: Optional[Voice]) -> None:
        self.speed_spin.setEnabled(voice is None or voice.supports_speed)
        # V4 follow-up #2: Speed/Pitch's valid range isn't fixed any more
        # -- see Voice.speed_range/pitch_range's comment in core/models.py
        # for why a DSP-based implementation (Chatterbox) needs a
        # narrower range than a native one (Piper/Kokoro) to stay
        # listenable. setRange() clamps the current value into the new
        # range automatically if it no longer fits, same as switching to
        # a voice with a narrower Advanced-sampling range already does
        # for those fields.
        speed_range = voice.speed_range if voice is not None else (0.5, 2.0)
        self.speed_spin.setRange(*speed_range)
        supports_volume = voice is None or voice.supports_volume
        self.volume_spin.setVisible(supports_volume)
        self.volume_label.setVisible(supports_volume)
        supports_pitch = voice is not None and voice.supports_pitch
        self.pitch_spin.setVisible(supports_pitch)
        self.pitch_label.setVisible(supports_pitch)
        if supports_pitch:
            self.pitch_spin.setRange(*voice.pitch_range)
        supports_character = voice is not None and voice.supports_character_presets
        self.character_combo.setVisible(supports_character)
        self.character_label.setVisible(supports_character)
        if not supports_character:
            self.set_character("neutral")
        supports_cloning = voice is not None and voice.supports_cloning
        self.reference_audio_label.setVisible(supports_cloning)
        self.reference_audio_path_label.setVisible(supports_cloning)
        self.reference_audio_button.setVisible(supports_cloning)
        self.reference_audio_clear_button.setVisible(supports_cloning)
        self._apply_chatterbox_controls(voice)

    def _apply_chatterbox_controls(self, voice: Optional[Voice]) -> None:
        """Shows/hides/resets Expression, Voice Guidance, the style
        preset combo, and every Advanced field, and repopulates the
        preset combo with whichever list matches the newly-selected
        voice's tier. Split out from _apply_voice_capabilities() above
        just to keep that method from growing much longer, not because
        this logic is reused anywhere else."""
        supports_expression = voice is not None and voice.supports_expression
        self.expression_label.setVisible(supports_expression)
        self.expression_spin.setVisible(supports_expression)
        self.guidance_label.setVisible(supports_expression)
        self.guidance_spin.setVisible(supports_expression)

        supports_style = voice is not None and (voice.supports_expression or voice.supports_turbo_nano_presets)
        self.style_preset_label.setVisible(supports_style)
        self.style_preset_combo.setVisible(supports_style)
        # supports_style is already true whenever supports_expression is
        # (see the OR above), so it alone is enough to decide whether
        # *anything* inside the tuning container (Expression/Guidance
        # and/or Style preset) is worth showing -- and therefore whether
        # the toggle that reveals it should even appear. Collapsing the
        # toggle back to unchecked for a voice that doesn't support it
        # mirrors advanced_toggle's own reset just below, for the same
        # reason: don't leave a container silently expanded behind a
        # toggle the user can no longer see or use.
        self.chatterbox_tuning_toggle.setVisible(supports_style)
        if not supports_style:
            self.chatterbox_tuning_toggle.setChecked(False)
        self.chatterbox_tuning_container.setVisible(supports_style and self.chatterbox_tuning_toggle.isChecked())

        supports_advanced = voice is not None and voice.supports_advanced_sampling
        self.advanced_toggle.setVisible(supports_advanced)
        if not supports_advanced:
            self.advanced_toggle.setChecked(False)
        self.advanced_container.setVisible(supports_advanced and self.advanced_toggle.isChecked())

        supports_min_p = voice is not None and voice.supports_min_p
        self.min_p_label.setVisible(supports_min_p)
        self.min_p_spin.setVisible(supports_min_p)
        supports_top_k = voice is not None and voice.supports_top_k
        self.top_k_label.setVisible(supports_top_k)
        self.top_k_spin.setVisible(supports_top_k)

        # Repopulating the preset combo below fires currentIndexChanged,
        # which would otherwise immediately re-apply whatever preset
        # happens to land at index 0 and stomp on values a loaded
        # project (or the user) already set -- _updating_presets guards
        # _on_style_preset_selected() the same way _updating_table guards
        # SectionsPanel's own itemChanged handler.
        self._updating_presets = True
        self.style_preset_combo.clear()
        if voice is not None and voice.supports_expression:
            for key, label, *_values in _ORIGINAL_PRESETS:
                self.style_preset_combo.addItem(label, userData=key)
        elif voice is not None and voice.supports_turbo_nano_presets:
            for key, label, *_values in _TURBO_NANO_PRESETS:
                self.style_preset_combo.addItem(label, userData=key)
        self._updating_presets = False

        # Reset every advanced/expression field to the newly-selected
        # tier's own upstream default whenever the tier actually changes
        # underneath -- not on every call (which would stomp on a value
        # the user just typed, since this runs on every voice_combo
        # signal, including ones that don't change tier), and not at all
        # for a non-Chatterbox voice, since those fields are simply
        # hidden and never read for one. `voice.id` doubles as the tier
        # name for Chatterbox ("nano"/"turbo"/"original" -- see
        # chatterbox_engine.py's _VOICE_TIERS).
        new_tier = voice.id if (voice is not None and voice.engine == "chatterbox") else None
        if new_tier is not None and new_tier != self._loaded_chatterbox_tier:
            self.expression_spin.setValue(0.5)
            self.guidance_spin.setValue(0.5)
            self.temperature_spin.setValue(0.8)
            self.repetition_penalty_spin.setValue(1.2)
            self.min_p_spin.setValue(0.05)
            # Turbo/Nano's own upstream default for top_p is 0.95, not
            # Original's 1.0 -- see SynthesisSettings.top_p's comment in
            # core/models.py for why this can't just be one shared
            # constant.
            self.top_p_spin.setValue(0.95 if new_tier in ("nano", "turbo") else 1.0)
            self.top_k_spin.setValue(1000)
        self._loaded_chatterbox_tier = new_tier

    def _on_style_preset_selected(self, _index: int) -> None:
        if self._updating_presets:
            return
        key = self.style_preset_combo.currentData()
        if key is None:
            return
        voice = self.get_selected_voice()
        table = _ORIGINAL_PRESETS if (voice is not None and voice.supports_expression) else _TURBO_NANO_PRESETS
        for preset_key, _label, *values in table:
            if preset_key != key:
                continue
            if table is _ORIGINAL_PRESETS:
                exaggeration, cfg_weight, temperature = values
                self.expression_spin.setValue(exaggeration)
                self.guidance_spin.setValue(cfg_weight)
                self.temperature_spin.setValue(temperature)
            else:
                temperature, top_p, repetition_penalty = values
                self.temperature_spin.setValue(temperature)
                self.top_p_spin.setValue(top_p)
                self.repetition_penalty_spin.setValue(repetition_penalty)
            return

    def _on_advanced_toggled(self, checked: bool) -> None:
        self.advanced_toggle.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
        self.advanced_container.setVisible(checked)

    def _on_chatterbox_tuning_toggled(self, checked: bool) -> None:
        self.chatterbox_tuning_toggle.setArrowType(Qt.ArrowType.DownArrow if checked else Qt.ArrowType.RightArrow)
        self.chatterbox_tuning_container.setVisible(checked)

    # -- public API used by MainWindow --------------------------------
    def get_selected_engine(self) -> Optional[str]:
        return self.engine_combo.currentData()

    def set_selected_engine(self, key: str) -> None:
        for i in range(self.engine_combo.count()):
            if self.engine_combo.itemData(i) == key:
                self.engine_combo.setCurrentIndex(i)
                return

    def get_selected_voice(self) -> Optional[Voice]:
        voice_id = self.voice_combo.currentData()
        return next((v for v in self._voices if v.id == voice_id), None)

    def set_selected_voice(self, voice_id: str) -> None:
        for i in range(self.voice_combo.count()):
            if self.voice_combo.itemData(i) == voice_id:
                self.voice_combo.setCurrentIndex(i)
                return

    def set_speed(self, value: float) -> None:
        self.speed_spin.setValue(value)

    def set_volume(self, value: float) -> None:
        self.volume_spin.setValue(value)

    def set_pitch(self, value: float) -> None:
        self.pitch_spin.setValue(value)

    def set_character(self, preset: str) -> None:
        for i in range(self.character_combo.count()):
            if self.character_combo.itemData(i) == preset:
                self.character_combo.setCurrentIndex(i)
                return
        self.character_combo.setCurrentIndex(0)  # "neutral" is always first

    # -- V4 follow-up: Chatterbox native controls, for project restore --
    def set_exaggeration(self, value: float) -> None:
        self.expression_spin.setValue(value)

    def set_cfg_weight(self, value: float) -> None:
        self.guidance_spin.setValue(value)

    def set_temperature(self, value: float) -> None:
        self.temperature_spin.setValue(value)

    def set_repetition_penalty(self, value: float) -> None:
        self.repetition_penalty_spin.setValue(value)

    def set_min_p(self, value: float) -> None:
        self.min_p_spin.setValue(value)

    def set_top_p(self, value: float) -> None:
        self.top_p_spin.setValue(value)

    def set_top_k(self, value: int) -> None:
        self.top_k_spin.setValue(value)

    # -- V4: reference-audio (voice cloning) --------------------------
    def _on_choose_reference_audio(self) -> None:
        path, _filter = QFileDialog.getOpenFileName(
            self,
            "Choose a reference voice clip",
            "",
            "Audio files (*.wav *.mp3 *.flac *.ogg *.m4a);;All files (*)",
        )
        if path:
            self.set_reference_audio_path(path)

    def _on_clear_reference_audio(self) -> None:
        self.set_reference_audio_path(None)

    def get_reference_audio_path(self) -> Optional[Path]:
        return self._reference_audio_path

    def set_reference_audio_path(self, path) -> None:
        self._reference_audio_path = Path(path) if path else None
        if self._reference_audio_path:
            self.reference_audio_path_label.setText(self._reference_audio_path.name)
            self.reference_audio_path_label.setToolTip(str(self._reference_audio_path))
        else:
            self.reference_audio_path_label.setText("(none \N{EN DASH} uses the engine's built-in voice)")
            self.reference_audio_path_label.setToolTip("")

    def get_synthesis_settings(self) -> Optional[SynthesisSettings]:
        voice = self.get_selected_voice()
        if voice is None:
            return None
        return SynthesisSettings(
            voice=voice,
            speed=self.speed_spin.value(),
            pitch_semitones=self.pitch_spin.value() if voice.supports_pitch else 0.0,
            volume=self.volume_spin.value() if voice.supports_volume else 1.0,
            character_preset=self.character_combo.currentData() if voice.supports_character_presets else "neutral",
            reference_audio_path=self._reference_audio_path if voice.supports_cloning else None,
            # V4 follow-up: same "gate by capability, fall back to the
            # neutral upstream default otherwise" pattern as pitch/
            # character_preset above -- see SynthesisSettings' own field
            # comments in core/models.py for why each default is what it is.
            exaggeration=self.expression_spin.value() if voice.supports_expression else 0.5,
            cfg_weight=self.guidance_spin.value() if voice.supports_expression else 0.5,
            temperature=self.temperature_spin.value() if voice.supports_advanced_sampling else 0.8,
            repetition_penalty=self.repetition_penalty_spin.value() if voice.supports_advanced_sampling else 1.2,
            min_p=self.min_p_spin.value() if voice.supports_min_p else 0.05,
            top_p=self.top_p_spin.value() if voice.supports_advanced_sampling else 1.0,
            top_k=self.top_k_spin.value() if voice.supports_top_k else 1000,
        )

    def set_busy(self, busy: bool) -> None:
        """Lock engine/voice/settings while a batch generation run is in progress."""
        self.engine_combo.setEnabled(not busy)
        self.voice_combo.setEnabled(not busy)
        self.manage_button.setEnabled(not busy)
        self.diagnose_button.setEnabled(not busy)
        self.speed_spin.setEnabled(not busy and (self.get_selected_voice() is None or self.get_selected_voice().supports_speed))
        self.volume_spin.setEnabled(not busy)
        self.pitch_spin.setEnabled(not busy)
        self.character_combo.setEnabled(not busy)
        self.reference_audio_button.setEnabled(not busy)
        self.reference_audio_clear_button.setEnabled(not busy)
        self.expression_spin.setEnabled(not busy)
        self.guidance_spin.setEnabled(not busy)
        self.style_preset_combo.setEnabled(not busy)
        self.chatterbox_tuning_toggle.setEnabled(not busy)
        self.advanced_toggle.setEnabled(not busy)
        self.temperature_spin.setEnabled(not busy)
        self.top_p_spin.setEnabled(not busy)
        self.top_k_spin.setEnabled(not busy)
        self.min_p_spin.setEnabled(not busy)
        self.repetition_penalty_spin.setEnabled(not busy)
