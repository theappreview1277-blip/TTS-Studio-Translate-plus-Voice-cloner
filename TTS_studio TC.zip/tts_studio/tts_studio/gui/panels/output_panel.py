"""Audio Preview && Export panel (GUI areas 8-9). V2 adds MP3/FLAC/OGG."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import QUrl, Signal
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

EXPORT_FORMATS = [("wav", "WAV"), ("mp3", "MP3"), ("flac", "FLAC"), ("ogg", "OGG")]


class OutputPanel(QWidget):
    export_requested = Signal()
    # V4 follow-up #2: fires when the checkbox is toggled so MainWindow
    # can re-run _rejoin_and_preview() immediately -- toggling it should
    # feel like an instant preview change, not something that only takes
    # effect after the next "Generate All Audio" run.
    normalize_changed = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._current_path: Optional[Path] = None

        self._player = QMediaPlayer(self)
        self._audio_output = QAudioOutput(self)
        self._player.setAudioOutput(self._audio_output)
        self._player.playbackStateChanged.connect(self._on_playback_state_changed)

        # See source_panel.py's comment on its own QGroupBox for why this
        # no longer has an "8-9." prefix.
        group = QGroupBox("Audio Preview && Export")
        layout = QVBoxLayout(group)

        row = QHBoxLayout()
        self.play_button = QPushButton("Play")
        self.play_button.setEnabled(False)
        self.play_button.clicked.connect(self._toggle_playback)
        row.addWidget(self.play_button)
        row.addSpacing(16)

        row.addWidget(QLabel("Format:"))
        self.format_combo = QComboBox()
        for value, label in EXPORT_FORMATS:
            self.format_combo.addItem(label, userData=value)
        row.addWidget(self.format_combo)

        self.export_button = QPushButton("Export...")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.export_requested)
        row.addWidget(self.export_button)
        row.addSpacing(16)

        # V4 follow-up #2: peak-normalizes the joined preview/export audio
        # (see AudioProcessor.normalize_peak()) rather than requiring a
        # separate pass in another program to even out sections that came
        # out at noticeably different volumes -- easy to hit with a
        # cloned voice whose reference clip was recorded quieter than
        # Chatterbox's own built-in voice, for instance. Read directly by
        # MainWindow._rejoin_and_preview() whenever it re-joins the
        # sections, not wired through SynthesisSettings -- it's a
        # property of the *finished, joined* clip, not something any one
        # section's synthesize() call needs to know about.
        self.normalize_checkbox = QCheckBox("Normalise final audio")
        self.normalize_checkbox.setToolTip(
            "Scales the joined audio so its loudest moment sits just under full volume. "
            "Useful if sections ended up at noticeably different volumes."
        )
        self.normalize_checkbox.toggled.connect(lambda _checked: self.normalize_changed.emit())
        row.addWidget(self.normalize_checkbox)
        row.addSpacing(16)

        # A real bug, hit by a real user: a QLabel with no word-wrap
        # reports a minimumSizeHint() wide enough to fit its ENTIRE text
        # on one line, and that propagates up through this row's layout
        # to the main window itself -- so one sufficiently long status
        # message (Chatterbox's new "loading the model for the first
        # time..." warmup notice, in this case; see chatterbox_engine.py)
        # was enough to force the whole app window wider than the
        # screen. `QSizePolicy.Ignored` tells the layout not to use this
        # label's natural (text-driven) size when computing how wide its
        # row -- and everything containing it -- needs to be; the label
        # still gets real estate via the stretch factor below, it just
        # can't dictate a minimum from its own text any more. The full
        # text is still set on the label (Qt clips visually rather than
        # wrapping or resizing around it) and kept in the tooltip so
        # nothing is silently lost if it doesn't fully fit.
        self.status_label = QLabel("No audio generated yet.")
        self.status_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        row.addWidget(self.status_label, 1)
        layout.addLayout(row)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(group)

    def _toggle_playback(self) -> None:
        if self._player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self._player.pause()
        else:
            self._player.play()

    def _on_playback_state_changed(self, state) -> None:
        playing = state == QMediaPlayer.PlaybackState.PlayingState
        self.play_button.setText("Pause" if playing else "Play")

    # -- public API used by MainWindow --------------------------------
    def load_audio(self, path: Path) -> None:
        self._current_path = Path(path)
        self._player.setSource(QUrl.fromLocalFile(str(self._current_path)))
        self.play_button.setEnabled(True)
        self.export_button.setEnabled(True)
        self.status_label.setText(f"Ready: {self._current_path.name}")

    def get_current_path(self) -> Optional[Path]:
        return self._current_path

    def get_export_format(self) -> str:
        return self.format_combo.currentData()

    def set_export_format(self, fmt: str) -> None:
        for i in range(self.format_combo.count()):
            if self.format_combo.itemData(i) == fmt:
                self.format_combo.setCurrentIndex(i)
                return

    def get_normalize_output(self) -> bool:
        return self.normalize_checkbox.isChecked()

    def set_normalize_output(self, value: bool) -> None:
        # blockSignals: restoring a saved project's checkbox state
        # shouldn't fire normalize_changed and trigger a redundant
        # re-join before MainWindow has finished loading the rest of the
        # project (it calls _rejoin_and_preview() itself once, at the end
        # of _on_open_project()).
        self.normalize_checkbox.blockSignals(True)
        self.normalize_checkbox.setChecked(value)
        self.normalize_checkbox.blockSignals(False)

    def set_status(self, text: str) -> None:
        self.status_label.setText(text)
        # Belt-and-suspenders alongside the Ignored size policy set on
        # this label above: if a long message ever gets visually clipped
        # instead of fully shown, the full text is still reachable on
        # hover rather than silently lost.
        self.status_label.setToolTip(text)
