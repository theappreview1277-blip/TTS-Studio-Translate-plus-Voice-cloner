"""
Translation panel (GUI area 3: target language selection).

V1 had this panel also own a single big "Translated Text" editable box
and its own Translate button (GUI area 4). V2 replaces that box with
SectionsPanel, where every section's translation is independently
editable and independently regenerable -- that's a strictly more
capable version of "editable translated text," not a removed feature.
This panel now only picks the target language; SectionsPanel's
"Translate All" (or a per-row Regenerate) is what actually triggers
translation, using whatever language is selected here.

Argos Translate is the only translation engine (a second, optional
LibreTranslate HTTP-client engine existed briefly in V3 and was removed
by request -- see ARCHITECTURE.md section C/J -- so there's deliberately
no engine picker here; MainWindow always talks to Argos directly).
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QComboBox, QGroupBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from tts_studio.gui.panels.source_panel import COMMON_LANGUAGES

# Target language never offers "auto".
TARGET_LANGUAGES = [pair for pair in COMMON_LANGUAGES if pair[0] != "auto"]


class TranslationPanel(QWidget):
    manage_languages_requested = Signal()  # V3: opens the Download Languages dialog

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)

        # See source_panel.py's comment on its own QGroupBox for why this
        # no longer has a "3." prefix.
        group = QGroupBox("Translation Target")
        layout = QHBoxLayout(group)
        layout.addWidget(QLabel("Target language:"))
        self.target_lang_combo = QComboBox()
        for code, label in TARGET_LANGUAGES:
            self.target_lang_combo.addItem(label, userData=code)
        layout.addWidget(self.target_lang_combo)
        layout.addSpacing(16)

        self.manage_button = QPushButton("Download Languages...")
        self.manage_button.setToolTip("Install more offline Argos Translate language packages")
        self.manage_button.clicked.connect(self.manage_languages_requested)
        layout.addWidget(self.manage_button)
        layout.addStretch(1)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(group)

    # -- public API -------------------------------------------------------
    def get_target_language(self) -> str:
        return self.target_lang_combo.currentData()

    def set_target_language(self, code: str) -> None:
        for i in range(self.target_lang_combo.count()):
            if self.target_lang_combo.itemData(i) == code:
                self.target_lang_combo.setCurrentIndex(i)
                return

    def add_language(self, code: str, name: str) -> None:
        """Called after installing an Argos package for a language that
        wasn't in the static COMMON_LANGUAGES starter list, so it shows
        up as a real target option immediately (no restart)."""
        if not code:
            return
        if any(self.target_lang_combo.itemData(i) == code for i in range(self.target_lang_combo.count())):
            return
        self.target_lang_combo.addItem(name, userData=code)
