"""Source Text + Language Detection panel (GUI areas 1-2).

V2 adds document import (.docx/.pdf, in addition to V1's .txt/.md) and
the chunk-mode controls ("sentence / paragraph / automatic / custom")
that turn the source text into the sections shown in SectionsPanel.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from tts_studio.core.exceptions import DocumentImportError
from tts_studio.text_processing.chunker import ChunkMode
from tts_studio.text_processing.document_import import FILE_DIALOG_FILTER, import_document

# A practical starter set; grows as Argos language packages are installed.
# ("auto", "Auto-detect") is only meaningful as the *source* language.
COMMON_LANGUAGES = [
    ("auto", "Auto-detect"),
    ("en", "English"), ("es", "Spanish"), ("fr", "French"), ("de", "German"),
    ("it", "Italian"), ("pt", "Portuguese"), ("ru", "Russian"), ("zh", "Chinese"),
    ("ja", "Japanese"), ("ko", "Korean"), ("ar", "Arabic"), ("hi", "Hindi"),
    ("nl", "Dutch"), ("pl", "Polish"), ("tr", "Turkish"),
]

CHUNK_MODES = [
    (ChunkMode.AUTOMATIC, "Automatic"),
    (ChunkMode.SENTENCE, "Sentence"),
    (ChunkMode.PARAGRAPH, "Paragraph"),
    (ChunkMode.CUSTOM, "Custom length"),
]

class SourcePanel(QWidget):
    import_requested = Signal()
    import_failed = Signal(str)
    detect_language_requested = Signal()
    text_changed = Signal()
    split_requested = Signal()

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)

        # No "1-2." prefix on this title (or the numbered prefixes the
        # other panels used to have) -- those were this project's own
        # internal spec numbering ("GUI areas 1-2", "areas 3", ...)
        # leaking straight into a shipped group box title, meaningless to
        # someone using the app rather than reading the spec it was built
        # from.
        group = QGroupBox("Source Text && Language")
        layout = QVBoxLayout(group)

        # A V4 follow-up briefly added a row of Turbo/Nano-only inline
        # sound-tag insert buttons here ([laugh]/[cough]/[chuckle],
        # confirmed against chatterbox's own README) -- removed after a
        # real user found [laugh]/[chuckle] didn't actually work in
        # practice and asked for all three to come out. See
        # chatterbox_engine.py's module docstring for the full story, and
        # ARCHITECTURE.md section I for the design-decision writeup.

        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText("Paste or type text here, or import a document...")
        self.text_edit.textChanged.connect(self.text_changed)
        # Defensive floor, added alongside the "cluttered and busy" fix
        # elsewhere in the GUI: this box has an Expanding vertical size
        # policy by default and shares leftover window height with
        # SectionsPanel's table (see main_window.py's central layout --
        # neither this app nor Qt scrolls the five stacked panels, so
        # they compete for whatever room the window actually has). A
        # minimum stops it being squeezed down to a sliver of its
        # placeholder text if something elsewhere in the window ever
        # grows again -- it can still grow larger, this only sets a
        # floor, not a ceiling.
        self.text_edit.setMinimumHeight(120)
        layout.addWidget(self.text_edit)

        row1 = QHBoxLayout()
        self.import_button = QPushButton("Import Document...")
        self.import_button.setToolTip("Open a .txt, .md, .docx, or .pdf file")
        self.import_button.clicked.connect(self._on_import_clicked)
        row1.addWidget(self.import_button)
        row1.addSpacing(16)  # separates "import a file" from the language controls that follow

        row1.addWidget(QLabel("Source language:"))
        self.source_lang_combo = QComboBox()
        for code, label in COMMON_LANGUAGES:
            self.source_lang_combo.addItem(label, userData=code)
        row1.addWidget(self.source_lang_combo)
        row1.addSpacing(16)

        self.detect_button = QPushButton("Detect")
        self.detect_button.clicked.connect(self.detect_language_requested)
        row1.addWidget(self.detect_button)

        self.detected_label = QLabel("")
        row1.addWidget(self.detected_label)
        row1.addStretch(1)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Chunk mode:"))
        self.chunk_mode_combo = QComboBox()
        for mode, label in CHUNK_MODES:
            self.chunk_mode_combo.addItem(label, userData=mode.value)
        self.chunk_mode_combo.currentIndexChanged.connect(self._on_chunk_mode_changed)
        row2.addWidget(self.chunk_mode_combo)
        row2.addSpacing(16)

        self.max_chars_label = QLabel("Max chunk length (characters):")
        row2.addWidget(self.max_chars_label)
        self.max_chars_spin = QSpinBox()
        self.max_chars_spin.setRange(50, 5000)
        self.max_chars_spin.setSingleStep(50)
        self.max_chars_spin.setValue(500)
        row2.addWidget(self.max_chars_spin)
        row2.addSpacing(16)

        self.split_button = QPushButton("Split into Sections")
        self.split_button.clicked.connect(self.split_requested)
        row2.addWidget(self.split_button)
        row2.addStretch(1)
        layout.addLayout(row2)
        self._on_chunk_mode_changed()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(group)

    def _on_chunk_mode_changed(self, *_args) -> None:
        mode = self.chunk_mode_combo.currentData()
        # Max length only applies to AUTOMATIC (as a soft target) and
        # CUSTOM (as the hard split length); SENTENCE/PARAGRAPH ignore it.
        relevant = mode in (ChunkMode.AUTOMATIC.value, ChunkMode.CUSTOM.value)
        self.max_chars_spin.setEnabled(relevant)
        self.max_chars_label.setEnabled(relevant)

    def _on_import_clicked(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import document", "", FILE_DIALOG_FILTER)
        if not path:
            return
        try:
            text = import_document(Path(path))
        except DocumentImportError as exc:
            self.import_failed.emit(exc.full_message)
            return
        self.text_edit.setPlainText(text)
        self.import_requested.emit()

    # -- public API used by MainWindow --------------------------------
    def get_text(self) -> str:
        return self.text_edit.toPlainText()

    def set_text(self, text: str) -> None:
        self.text_edit.setPlainText(text)

    def get_selected_source_language(self) -> Optional[str]:
        """None means 'auto-detect'."""
        code = self.source_lang_combo.currentData()
        return None if code == "auto" else code

    def set_source_language(self, code: Optional[str]) -> None:
        target = code or "auto"
        for i in range(self.source_lang_combo.count()):
            if self.source_lang_combo.itemData(i) == target:
                self.source_lang_combo.setCurrentIndex(i)
                return

    def set_detected_language(self, code: str, confidence: float) -> None:
        self.detected_label.setText(f"Detected: {code} ({confidence:.0%} confidence)")
        # A detected language outside the static starter list (e.g. one
        # only known because an Argos package for it was just installed)
        # still needs to be selectable, not just displayed in the label.
        self.add_language(code, code.upper())
        self.set_source_language(code)

    def add_language(self, code: str, name: str) -> None:
        """V3: called after installing an Argos package, or after a
        detection result, for a language not in the static
        COMMON_LANGUAGES starter list."""
        if not code or code == "auto":
            return
        if any(self.source_lang_combo.itemData(i) == code for i in range(self.source_lang_combo.count())):
            return
        self.source_lang_combo.addItem(name, userData=code)

    def get_chunk_mode(self) -> str:
        return self.chunk_mode_combo.currentData()

    def set_chunk_mode(self, mode: str) -> None:
        for i in range(self.chunk_mode_combo.count()):
            if self.chunk_mode_combo.itemData(i) == mode:
                self.chunk_mode_combo.setCurrentIndex(i)
                return

    def get_max_chunk_chars(self) -> int:
        return self.max_chars_spin.value()

    def set_max_chunk_chars(self, value: int) -> None:
        self.max_chars_spin.setValue(value)
