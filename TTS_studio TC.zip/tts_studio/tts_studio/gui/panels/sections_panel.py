"""
Sections panel: the V2 realization of "chunking" as a user-facing
feature (mode picker lives in SourcePanel; this table is where the
resulting sections live), plus "translation editing" per-section and
"regenerate only selected sections" from the original core objectives.

Design choice worth calling out: V1 had one big "Translated Text" box
and one "Generate Speech" button that worked on the whole text at
once (chunking happened silently underneath). V2 replaces that with
this table -- each row is independently editable and independently
regenerable. A short document still just shows one row, so nothing
gets more complicated for a simple use case; it only pays off once a
document is long enough to want per-section control.
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from tts_studio.core.models import TextSection

_STATUS_LABELS = {
    "pending": "Pending",
    "translating": "Translating...",
    "translated": "Translated",
    "synthesizing": "Generating...",
    "synthesized": "\u2713 Done",
    "error": "\u26a0 Error",
}

# Color-coding the Status column, on top of the text labels above, so
# "what's happening right now" reads at a glance across a long sections
# table instead of requiring reading every row's text -- picked to stay
# legible on both light and dark backgrounds (a plain named color like
# Qt's "green"/"red" skews too dark against a dark theme, which this app
# runs under by default on Windows 11). "pending" and "translated"
# intentionally have no entry here -- "pending" is the neutral starting
# state and needs no color, and "translated" reuses the same in-between
# treatment as "no color" so the one color that means "finished" (green)
# stays reserved for "synthesized," not diluted by an earlier partial
# success.
_STATUS_COLORS = {
    "translating": QColor("#e8a33d"),  # amber -- in progress
    "synthesizing": QColor("#e8a33d"),  # amber -- in progress
    "synthesized": QColor("#3fb950"),  # green -- fully done
    "error": QColor("#f0554c"),  # red -- needs attention
}

COL_INDEX, COL_SOURCE, COL_TRANSLATION, COL_STATUS, COL_ACTIONS = range(5)


class SectionsPanel(QWidget):
    translate_all_requested = Signal()
    generate_all_requested = Signal()
    regenerate_section_requested = Signal(int)  # section index: re-translate, then re-synthesize
    section_translation_edited = Signal(int, str)  # index, new text

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._sections: list[TextSection] = []
        self._updating_table = False

        group = QGroupBox("Sections")
        layout = QVBoxLayout(group)

        toolbar = QHBoxLayout()
        self.summary_label = QLabel("No sections yet -- split your text first.")
        toolbar.addWidget(self.summary_label)
        toolbar.addStretch(1)
        self.translate_all_button = QPushButton("Translate All")
        self.translate_all_button.clicked.connect(self.translate_all_requested)
        toolbar.addWidget(self.translate_all_button)
        self.generate_all_button = QPushButton("Generate All Audio")
        self.generate_all_button.clicked.connect(self.generate_all_requested)
        toolbar.addWidget(self.generate_all_button)
        layout.addLayout(toolbar)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["#", "Source", "Translation (editable)", "Status", ""])
        self.table.horizontalHeader().setSectionResizeMode(COL_SOURCE, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(COL_TRANSLATION, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(COL_INDEX, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(COL_STATUS, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(COL_ACTIONS, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.itemChanged.connect(self._on_item_changed)
        # A hover tooltip is easy to miss (or not know to look for) --
        # clicking the "⚠ Error" status directly pops the same text up
        # in a dialog, which is the version of this someone actually
        # notices. The tooltip stays too (setToolTip below), it's just no
        # longer the *only* way to read a failure's real cause.
        self.table.cellClicked.connect(self._on_cell_clicked)
        # Same defensive floor as SourcePanel's text_edit, added for the
        # same reason -- this table shares leftover window height with
        # that text box in one fixed-size, non-scrolling window (see
        # main_window.py), so without a minimum it's the one that would
        # quietly shrink to near-uselessness if anything else in the
        # window grows. Doesn't cap how big it can get, just how small.
        self.table.setMinimumHeight(160)
        layout.addWidget(self.table)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(group)

    # -- population ------------------------------------------------------
    def set_sections(self, sections: list[TextSection]) -> None:
        self._sections = sections
        self._updating_table = True
        self.table.setRowCount(len(sections))
        for row, section in enumerate(sections):
            self._populate_row(row, section)
        self._updating_table = False
        self._update_summary()

    def update_section(self, index: int, section: TextSection) -> None:
        """Refresh one row (e.g. after translation/synthesis finishes).

        Finds the row by scanning `self._sections` (plain Python objects)
        for a matching `.index`, NOT by reading it back off the table's
        `QTableWidgetItem` -- that's what this used to do (`item =
        self.table.item(row, COL_INDEX); if item.data(0) == index`), and
        it's a real bug a screenshot from actual use caught: after
        "Translate All" finished with no error, every row's Status stayed
        "Pending" and the Translation column stayed empty, even though
        the translation had genuinely worked (`MainWindow._find_section`
        already found the right `TextSection` in `self.project.sections`
        by that point and set its `.translated_text` correctly -- borne
        out by the audio, generated afterward from that same object,
        coming out correctly translated). So the data layer was right and
        only the table's own refresh was silently never happening. The
        `COL_INDEX` item is built as `QTableWidgetItem(str(section.index))`
        (which sets `Qt.DisplayRole` to that *string*) and then
        `.setData(0, section.index)` right after (which sets the same
        role to the *int*) -- both render identically ("0", "1", ...) so
        there's no visual sign of which one actually stuck, but comparing
        whatever `.data(0)` hands back against the plain Python `int`
        `index` argument here is exactly the kind of str/int mismatch
        that fails every single time, silently, rather than occasionally.
        This project's own two OTHER per-row lookups
        (`_on_cell_clicked`, and the button built in `_populate_row` for
        "Regenerate") never had this problem because they already look
        the row up positionally against `self._sections`/a captured
        `section.index`, not through a Qt item's stored data -- this
        method and `_on_item_changed` below were the only two places
        still doing it the fragile way, so both are fixed here the same
        way. (Untestable against a real Qt event loop in this sandbox --
        no network access to install PySide6 here -- so this is fixed
        from the reported screenshot's exact symptom plus static reading,
        not a passing GUI test; every other engine/worker fix in this
        project carries the same caveat, see ARCHITECTURE.md section I.)
        """
        for row, existing in enumerate(self._sections):
            if existing.index == index:
                self._sections[row] = section
                self._updating_table = True
                self._populate_row(row, section)
                self._updating_table = False
                break
        self._update_summary()

    def _populate_row(self, row: int, section: TextSection) -> None:
        # Just for display -- nothing looks this item's data back up any
        # more (see update_section's docstring above for why that used to
        # happen here, and why it was fragile enough to be worth removing
        # rather than fixing in place). Every row-to-section lookup in
        # this class now goes through `self._sections[row]` instead.
        index_item = QTableWidgetItem(str(section.index))
        index_item.setFlags(index_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.table.setItem(row, COL_INDEX, index_item)

        source_preview = section.source_text
        if section.is_heading:
            source_preview = f"[Heading] {source_preview}"
        source_item = QTableWidgetItem(source_preview)
        source_item.setFlags(source_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.table.setItem(row, COL_SOURCE, source_item)

        translation_item = QTableWidgetItem(section.translated_text or "")
        self.table.setItem(row, COL_TRANSLATION, translation_item)

        status_item = QTableWidgetItem(_STATUS_LABELS.get(section.status, section.status))
        status_item.setFlags(status_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        color = _STATUS_COLORS.get(section.status)
        if color is not None:
            status_item.setForeground(color)
        if section.status == "error" and section.error_message:
            status_item.setToolTip(section.error_message)
            status_item.setText(_STATUS_LABELS["error"] + " (click for details)")
        self.table.setItem(row, COL_STATUS, status_item)

        actions = QWidget()
        actions_layout = QHBoxLayout(actions)
        actions_layout.setContentsMargins(2, 0, 2, 0)
        regen_button = QPushButton("Regenerate")
        regen_button.setToolTip("Re-run translation + speech generation for this section only")
        regen_button.clicked.connect(lambda _checked=False, i=section.index: self._on_regenerate_clicked(i))
        actions_layout.addWidget(regen_button)
        self.table.setCellWidget(row, COL_ACTIONS, actions)

    def _on_regenerate_clicked(self, index: int) -> None:
        self.regenerate_section_requested.emit(index)

    def _on_cell_clicked(self, row: int, column: int) -> None:
        if column != COL_STATUS or row >= len(self._sections):
            return
        section = self._sections[row]
        if section.status == "error" and section.error_message:
            QMessageBox.warning(
                self,
                f"Section {section.index}: what went wrong",
                section.error_message,
            )

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        if self._updating_table or item.column() != COL_TRANSLATION:
            return
        row = item.row()
        # Same fix as update_section() above, and for the same reason:
        # this used to read the row's section index back off the
        # COL_INDEX QTableWidgetItem's stored data (`.data(0)`) rather
        # than off `self._sections[row]` directly. `section_translation_
        # edited` is a `Signal(int, str)`, so Qt's own signal marshaling
        # can silently coerce a wrong type here in a way a plain Python
        # `==` comparison (in update_section) never would -- which is
        # likely why a hand-edited translation cell was never reported as
        # broken even while update_section's row refresh clearly was:
        # the two lookups fail differently, not necessarily both loudly.
        # Reading the index straight off `self._sections` sidesteps the
        # question entirely, matching every other per-row lookup in this
        # file (_on_cell_clicked, the Regenerate button in _populate_row).
        if row >= len(self._sections):
            return
        self.section_translation_edited.emit(self._sections[row].index, item.text())

    def _update_summary(self) -> None:
        total = len(self._sections)
        done = sum(1 for s in self._sections if s.status == "synthesized")
        errors = sum(1 for s in self._sections if s.status == "error")
        text = f"{total} section{'s' if total != 1 else ''}, {done} generated"
        if errors:
            text += f", {errors} with errors"
        self.summary_label.setText(text if total else "No sections yet -- split your text first.")

    def get_sections(self) -> list[TextSection]:
        return list(self._sections)

    def set_busy(self, busy: bool) -> None:
        self.translate_all_button.setEnabled(not busy)
        self.generate_all_button.setEnabled(not busy)
        self.table.setEnabled(not busy)

