"""
V3: in-app downloader for translation packages, Piper voices, and the
Kokoro voice pack.

Before V3 these were all manual steps in README.md (argospm/curl/
`python -m piper.download_voices`). These dialogs wrap the engine-adapter
methods added in engines/translation/argos_engine.py,
engines/tts/piper_engine.py, and engines/tts/kokoro_engine.py, running
each download on a background QThread so the dialog (and the rest of the
app) never freezes mid-download. Nothing here talks to a specific
engine's underlying package directly -- it only calls the adapter
methods already exposed through the TranslationEngine/TTSEngine
interfaces' concrete instances, so these dialogs would work unchanged
against any future engine that grows the same handful of methods.

Two separate dialogs on purpose, not one dialog with three tabs: an
earlier version of this file put Translation Languages, Piper Voices,
and Kokoro Voice Pack in one QTabWidget and just jumped to a different
starting tab depending on which button opened it -- but every tab was
still one click away regardless of entry point, so "Download
Languages..." (next to the target-language picker) showed voice-download
controls too, duplicating what "Download Voices..." (next to the voice
picker) already offers. LanguageManagerDialog and VoiceManagerDialog
below are fully separate: the languages button can only ever reach
language packages, and the voice button can only ever reach voices.
"""
from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QThread, Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from tts_studio.core.exceptions import TTSStudioError


class ResourceWorker(QThread):
    """Runs one blocking call (a download, an index refresh, ...) off the
    GUI thread. `action` takes no arguments -- callers wrap whatever they
    need in a lambda/closure."""

    succeeded = Signal(object)
    failed = Signal(str)

    def __init__(self, action: Callable[[], object]):
        super().__init__()
        self._action = action

    def run(self) -> None:
        try:
            self.succeeded.emit(self._action())
        except TTSStudioError as exc:
            self.failed.emit(exc.full_message)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(str(exc))


class _DownloadDialogBase(QDialog):
    """Shared plumbing for a dialog that runs at most one background
    download at a time and refuses to close mid-download. Subclasses
    build their own widgets and pass the ones that should lock during a
    download to `_set_busy`."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker: Optional[ResourceWorker] = None
        self._busy_widgets: list[QWidget] = []
        self.status_label = QLabel("Choose what you want to download.")
        self.status_label.setWordWrap(True)

    def _set_busy(self, busy: bool, message: str) -> None:
        for widget in self._busy_widgets:
            widget.setEnabled(not busy)
        self.status_label.setText(message)

    def _run(self, action: Callable[[], object], message: str, on_success: Callable[[object], None]) -> None:
        if self._worker is not None and self._worker.isRunning():
            return
        self._set_busy(True, message)
        worker = ResourceWorker(action)
        worker.succeeded.connect(on_success)
        worker.failed.connect(self._on_failed)
        worker.finished.connect(lambda: self._set_busy(False, self.status_label.text()))
        self._worker = worker
        worker.start()

    def _on_failed(self, message: str) -> None:
        self.status_label.setText(f"Download failed: {message}")

    # -- close handling: never drop a download mid-flight -------------------
    def reject(self) -> None:
        if self._worker is not None and self._worker.isRunning():
            self.status_label.setText("Please wait for the current download to finish before closing.")
            return
        super().reject()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        if self._worker is not None and self._worker.isRunning():
            self.status_label.setText("Please wait for the current download to finish before closing.")
            event.ignore()
            return
        super().closeEvent(event)


class LanguageManagerDialog(_DownloadDialogBase):
    """Argos translation-language packages only -- opened from
    TranslationPanel's "Download Languages..." button, or offered
    automatically when Translate All hits a pair that isn't installed."""

    resources_changed = Signal()  # a package was installed -- caller should refresh language lists
    languages_discovered = Signal(object)  # dict[code, name] seen in the Argos catalog, for combo boxes
    language_installed = Signal(str, str)  # source_code, target_code -- select this pair afterward

    def __init__(self, translation_engine, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Download Translation Languages")
        self.resize(560, 380)
        self._translation_engine = translation_engine
        self._packages: list[dict[str, str]] = []

        outer = QVBoxLayout(self)
        info = QLabel(
            "Translation works offline once a package is installed. Packages are "
            "directional: English → Spanish and Spanish → English are separate downloads."
        )
        info.setWordWrap(True)
        outer.addWidget(info)

        form = QFormLayout()
        self.language_pair_combo = QComboBox()
        self.language_pair_combo.setMinimumWidth(430)
        form.addRow("Package:", self.language_pair_combo)
        outer.addLayout(form)

        row = QHBoxLayout()
        self.refresh_languages_button = QPushButton("Refresh List")
        self.refresh_languages_button.clicked.connect(self.refresh_languages)
        row.addWidget(self.refresh_languages_button)
        self.install_language_button = QPushButton("Download and Install")
        self.install_language_button.clicked.connect(self.install_language)
        row.addWidget(self.install_language_button)
        row.addStretch(1)
        outer.addLayout(row)

        outer.addWidget(QLabel("Installed packages:"))
        self.installed_languages_list = QListWidget()
        outer.addWidget(self.installed_languages_list)
        remove_row = QHBoxLayout()
        self.remove_language_button = QPushButton("Remove Selected")
        self.remove_language_button.clicked.connect(self.remove_selected_language)
        remove_row.addWidget(self.remove_language_button)
        remove_row.addStretch(1)
        outer.addLayout(remove_row)

        outer.addWidget(self.status_label)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

        self._busy_widgets = [
            self.refresh_languages_button, self.install_language_button, self.language_pair_combo,
            self.remove_language_button, self.installed_languages_list,
        ]
        self.refresh_languages()
        self._refresh_installed_list()

    def refresh_languages(self) -> None:
        self._run(
            lambda: self._translation_engine.available_packages(refresh=True),
            "Loading translation language list...",
            self._languages_loaded,
        )

    def _languages_loaded(self, packages: object) -> None:
        self._packages = list(packages)
        installed = {
            (p["from_code"], p["to_code"])
            for p in self._translation_engine.installed_packages()
        }
        self.language_pair_combo.clear()
        discovered: dict[str, str] = {}
        for package in self._packages:
            pair = (package["from_code"], package["to_code"])
            discovered[package["from_code"]] = package["from_name"]
            discovered[package["to_code"]] = package["to_name"]
            suffix = "  (installed)" if pair in installed else ""
            label = (
                f'{package["from_name"]} ({package["from_code"]}) → '
                f'{package["to_name"]} ({package["to_code"]}){suffix}'
            )
            self.language_pair_combo.addItem(label, userData=pair)
        self.languages_discovered.emit(discovered)
        self.status_label.setText(f"Found {len(self._packages)} translation packages.")

    def install_language(self) -> None:
        pair = self.language_pair_combo.currentData()
        if not pair:
            return
        source, target = pair
        self._run(
            lambda: self._translation_engine.install_package(source, target),
            f"Downloading and installing {source} → {target}...",
            lambda _result: self._language_installed(source, target),
        )

    def _language_installed(self, source: str, target: str) -> None:
        self.status_label.setText(f"Installed {source} → {target}. Translation is ready.")
        self.language_installed.emit(source, target)
        self.resources_changed.emit()
        self._languages_loaded(self._packages)
        self._refresh_installed_list()

    def _refresh_installed_list(self) -> None:
        self.installed_languages_list.clear()
        for package in self._translation_engine.installed_packages():
            pair = (package["from_code"], package["to_code"])
            label = f'{package["from_name"]} ({package["from_code"]}) → {package["to_name"]} ({package["to_code"]})'
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, pair)
            self.installed_languages_list.addItem(item)

    def remove_selected_language(self) -> None:
        item = self.installed_languages_list.currentItem()
        if item is None:
            self.status_label.setText("Select an installed package to remove first.")
            return
        source, target = item.data(Qt.ItemDataRole.UserRole)
        self._run(
            lambda: self._translation_engine.uninstall_package(source, target),
            f"Removing {source} → {target}...",
            lambda _result: self._language_removed(source, target),
        )

    def _language_removed(self, source: str, target: str) -> None:
        self.status_label.setText(f"Removed {source} → {target}.")
        self.resources_changed.emit()
        self._languages_loaded(self._packages)
        self._refresh_installed_list()


class VoiceManagerDialog(_DownloadDialogBase):
    """Piper voices and the Kokoro voice pack only -- opened from
    TTSPanel's "Download Voices..." button. No translation-language
    content lives here; that's LanguageManagerDialog's job."""

    resources_changed = Signal()  # something installed -- caller should refresh the voice list

    def __init__(self, piper_engine, kokoro_engine, start_tab: int = 0, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Download Voices")
        self.resize(620, 460)
        self._piper_engine = piper_engine
        self._kokoro_engine = kokoro_engine

        outer = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_piper_tab(), "Piper Voices")
        self.tabs.addTab(self._build_kokoro_tab(), "Kokoro Voice Pack")
        self.tabs.setCurrentIndex(start_tab)
        outer.addWidget(self.tabs)

        outer.addWidget(self.status_label)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

        self._busy_widgets = [
            self.refresh_piper_button, self.install_piper_button, self.piper_voice_combo,
            self.installed_piper_list, self.remove_piper_button,
            self.install_kokoro_button, self.remove_kokoro_button,
        ]

        # Only load the tab that's actually visible at open time; the
        # other one loads on first click so opening this dialog never
        # blocks on a network round-trip it doesn't need yet.
        self._piper_loaded_once = False
        self.tabs.currentChanged.connect(self._load_current_tab)
        self._load_current_tab(start_tab)

    def _build_piper_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        info = QLabel("Download extra offline Piper voices. Installed voices appear in the main voice list.")
        info.setWordWrap(True)
        layout.addWidget(info)
        form = QFormLayout()
        self.piper_voice_combo = QComboBox()
        self.piper_voice_combo.setEditable(True)
        self.piper_voice_combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.piper_voice_combo.setMinimumWidth(430)
        form.addRow("Voice:", self.piper_voice_combo)
        layout.addLayout(form)
        row = QHBoxLayout()
        self.refresh_piper_button = QPushButton("Refresh List")
        self.refresh_piper_button.clicked.connect(self.refresh_piper_voices)
        row.addWidget(self.refresh_piper_button)
        self.install_piper_button = QPushButton("Download Voice")
        self.install_piper_button.clicked.connect(self.install_piper_voice)
        row.addWidget(self.install_piper_button)
        row.addStretch(1)
        layout.addLayout(row)

        layout.addWidget(QLabel("Installed Piper voices:"))
        self.installed_piper_list = QListWidget()
        layout.addWidget(self.installed_piper_list)
        remove_row = QHBoxLayout()
        self.remove_piper_button = QPushButton("Remove Selected")
        self.remove_piper_button.clicked.connect(self.remove_selected_piper_voice)
        remove_row.addWidget(self.remove_piper_button)
        remove_row.addStretch(1)
        layout.addLayout(remove_row)
        return tab

    def _build_kokoro_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        info = QLabel(
            "Kokoro's 54 voices ship together in one official pack (model + voice styles). "
            "Download or repair the pack below; the voices then appear in the main voice list."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        self.kokoro_status_label = QLabel(f"Voice pack: {self._kokoro_engine.voice_pack_status()}")
        layout.addWidget(self.kokoro_status_label)
        self.kokoro_voice_list = QListWidget()
        self.kokoro_voice_list.addItems(self._kokoro_engine.bundled_voice_ids())
        layout.addWidget(self.kokoro_voice_list)
        row = QHBoxLayout()
        self.install_kokoro_button = QPushButton("Download / Repair Kokoro Voice Pack")
        self.install_kokoro_button.clicked.connect(self.install_kokoro_pack)
        row.addWidget(self.install_kokoro_button)
        self.remove_kokoro_button = QPushButton("Remove Voice Pack")
        self.remove_kokoro_button.clicked.connect(self.remove_kokoro_pack)
        row.addWidget(self.remove_kokoro_button)
        row.addStretch(1)
        layout.addLayout(row)
        return tab

    def _load_current_tab(self, tab: int) -> None:
        if tab == 0:
            self._refresh_installed_piper_list()
            if not self._piper_loaded_once:
                self.refresh_piper_voices()
        elif tab == 1:
            self._refresh_kokoro_display()

    # -- Piper voices --------------------------------------------------------
    def refresh_piper_voices(self) -> None:
        self._run(
            self._piper_engine.downloadable_voice_ids,
            "Loading Piper voice catalog...",
            self._piper_voices_loaded,
        )

    def _piper_voices_loaded(self, voices: object) -> None:
        self._piper_loaded_once = True
        installed = {voice.id for voice in self._piper_engine.available_voices()}
        self.piper_voice_combo.clear()
        for voice_id in list(voices):
            suffix = "  (installed)" if voice_id in installed else ""
            self.piper_voice_combo.addItem(f"{voice_id}{suffix}", userData=voice_id)
        self.status_label.setText(f"Found {self.piper_voice_combo.count()} Piper voices.")

    def install_piper_voice(self) -> None:
        voice_id = self.piper_voice_combo.currentData() or self.piper_voice_combo.currentText().split()[0]
        if not voice_id:
            return
        self._run(
            lambda: self._piper_engine.download_voice(voice_id),
            f"Downloading {voice_id}...",
            lambda _result: self._piper_voice_installed(voice_id),
        )

    def _piper_voice_installed(self, voice_id: str) -> None:
        self.status_label.setText(f"Installed {voice_id}. It's now available in the voice list.")
        self.resources_changed.emit()
        self._piper_loaded_once = False
        self._refresh_installed_piper_list()

    def _refresh_installed_piper_list(self) -> None:
        self.installed_piper_list.clear()
        for voice in self._piper_engine.available_voices():
            item = QListWidgetItem(f"{voice.id}  ({voice.language})")
            item.setData(Qt.ItemDataRole.UserRole, voice.id)
            self.installed_piper_list.addItem(item)

    def remove_selected_piper_voice(self) -> None:
        item = self.installed_piper_list.currentItem()
        if item is None:
            self.status_label.setText("Select an installed voice to remove first.")
            return
        voice_id = item.data(Qt.ItemDataRole.UserRole)
        self._run(
            lambda: self._piper_engine.remove_voice(voice_id),
            f"Removing {voice_id}...",
            lambda _result: self._piper_voice_removed(voice_id),
        )

    def _piper_voice_removed(self, voice_id: str) -> None:
        self.status_label.setText(f"Removed {voice_id}.")
        self.resources_changed.emit()
        self._refresh_installed_piper_list()
        self._piper_loaded_once = False

    # -- Kokoro voice pack -----------------------------------------------
    def install_kokoro_pack(self) -> None:
        self._run(
            self._kokoro_engine.download_voice_pack,
            "Downloading the Kokoro voice pack (model + voice styles, ~80MB)...",
            lambda _result: self._kokoro_installed(),
        )

    def _kokoro_installed(self) -> None:
        self._refresh_kokoro_display()
        self.status_label.setText("The Kokoro voice pack is installed and the voice list has been refreshed.")
        self.resources_changed.emit()

    def remove_kokoro_pack(self) -> None:
        self._run(
            self._kokoro_engine.remove_voice_pack,
            "Removing the Kokoro voice pack...",
            lambda _result: self._kokoro_removed(),
        )

    def _kokoro_removed(self) -> None:
        self._refresh_kokoro_display()
        self.status_label.setText("The Kokoro voice pack was removed.")
        self.resources_changed.emit()

    def _refresh_kokoro_display(self) -> None:
        voice_ids = self._kokoro_engine.bundled_voice_ids()
        self.kokoro_voice_list.clear()
        self.kokoro_voice_list.addItems(voice_ids)
        self.kokoro_status_label.setText(f"Voice pack: {self._kokoro_engine.voice_pack_status()}")
