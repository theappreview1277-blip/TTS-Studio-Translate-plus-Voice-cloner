"""
Main window.

This is the only place that talks to both the panels *and* the engine
registry -- panels never import an engine directly, and engines never
import Qt. That boundary is what lets engines change (or multiply)
without the GUI code changing.

V2 restructuring from V1: the GUI now works on a list of sections
(SectionsPanel) instead of one whole-document Translate/Generate
button pair. SourcePanel's "Split into Sections" is the bridge between
the two: it runs TextChunker with the user's chosen mode/length and
hands the resulting TextSection list to SectionsPanel. Everything
downstream (translation, synthesis, joining, export, project
save/load) operates on that list.
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Optional

from PySide6.QtWidgets import QDialog, QFileDialog, QMainWindow, QMessageBox, QVBoxLayout, QWidget

from tts_studio.audio.audio_processor import AudioProcessor
from tts_studio.core.engine_registry import EngineRegistry, default_registry
from tts_studio.core.exceptions import TTSStudioError
from tts_studio.core.models import Project, TextSection
from tts_studio.gui.panels.output_panel import OutputPanel
from tts_studio.gui.panels.sections_panel import SectionsPanel
from tts_studio.gui.panels.source_panel import SourcePanel
from tts_studio.gui.panels.translation_panel import TranslationPanel
from tts_studio.gui.panels.tts_panel import TTSPanel
from tts_studio.gui.resource_manager import LanguageManagerDialog, ResourceWorker, VoiceManagerDialog
from tts_studio.gui.workers import LanguageDetectionWorker, SectionsSynthesisWorker, SectionsTranslationWorker
from tts_studio.project.project_manager import ProjectManager, is_scratch_temp_file
from tts_studio.settings.app_settings import AppSettings
from tts_studio.text_processing.chunker import ChunkerOptions, ChunkMode, TextChunker

logger = logging.getLogger(__name__)

# Single source of truth for the window title, deliberately with no
# version number baked in. An earlier version of this file had
# "TTS Studio (V3)" hard-coded in four separate places -- three of which
# were left stale after V4 added Chatterbox, still showing "(V3)" long
# after the app had moved on. A version number in a window title goes
# stale the moment the next version ships and someone forgets one of the
# copies (exactly what happened here); dropping it avoids the problem
# rather than trying to remember to update it correctly every time.
_APP_TITLE = "TTS Studio"


class MainWindow(QMainWindow):
    def __init__(self, registry: EngineRegistry | None = None, settings: AppSettings | None = None):
        super().__init__()
        self.setWindowTitle(_APP_TITLE)
        self.resize(1000, 900)

        self.registry = registry or default_registry
        self.settings = settings or AppSettings.load()
        self.project = Project()
        self.audio = AudioProcessor()
        self.project_manager = ProjectManager()

        # Keep references to running workers so they aren't garbage
        # collected mid-flight, and so a new job can't start while one
        # is already running.
        self._detection_worker: Optional[LanguageDetectionWorker] = None
        self._translation_worker: Optional[SectionsTranslationWorker] = None
        self._synthesis_worker: Optional[SectionsSynthesisWorker] = None
        self._resource_manager: Optional[QDialog] = None
        self._model_worker: Optional[ResourceWorker] = None  # V3: auto-install-on-Translate-All background job
        self._diagnose_worker: Optional[ResourceWorker] = None  # V4: "Diagnose..." button background job
        self._previous_tts_engine_key: Optional[str] = None  # V4: tracks when we switch away from Chatterbox

        self.source_panel = SourcePanel()
        self.translation_panel = TranslationPanel()
        self.sections_panel = SectionsPanel()
        self.tts_panel = TTSPanel()
        self.output_panel = OutputPanel()

        central = QWidget()
        layout = QVBoxLayout(central)
        # A bit more room between the five stacked panels than Qt's
        # default spacing gives them -- purely cosmetic (each one is
        # already its own QGroupBox with a visible border), but the
        # default spacing reads as slightly cramped once the group box
        # titles above got bolded (see run.py's app-wide stylesheet).
        #
        # A later follow-up widened this further (10px -> 18px) and added
        # explicit content margins, chasing the same "cluttered and busy"
        # complaint -- reverted back to 10px here after a real user found
        # the result worse, not better. The five panels share one
        # fixed-size, non-scrolling window; only SourcePanel's text box and
        # SectionsPanel's table are set up to expand into whatever room is
        # left over once everything else takes its natural size. Any extra
        # spacing added here comes straight out of that same shared pool,
        # so it directly shrinks the text box and the sections table --
        # exactly what got reported as "everything else got harder to
        # see." See tts_panel.py's "Chatterbox voice tuning" toggle for
        # the declutter approach used instead, which reduces the height
        # budget rather than spending more of it.
        layout.setSpacing(10)
        layout.addWidget(self.source_panel)
        layout.addWidget(self.translation_panel)
        layout.addWidget(self.sections_panel)
        layout.addWidget(self.tts_panel)
        layout.addWidget(self.output_panel)
        self.setCentralWidget(central)

        self._build_menu()
        self._wire_signals()
        self._populate_engines()
        # A real user flagged this: every status message used to be
        # written to *two* places at once -- Qt's own bottom-of-window
        # statusBar() and the Output panel's own status label -- so
        # something like "Audio generation complete." visibly appeared
        # twice on screen simultaneously (and the two could disagree,
        # since a few call sites only updated one of them). One panel
        # should do all readouts, so the native status bar is no longer
        # used at all; self.output_panel.status_label -- already visible,
        # already wired for tooltips on truncation (see output_panel.py)
        # -- is now the single place every status message in this app is
        # shown. See _set_status() below.
        self.output_panel.set_status("Ready")
        self._refresh_installed_languages()

    # -- menu -----------------------------------------------------------
    def _build_menu(self) -> None:
        menu = self.menuBar().addMenu("&File")

        new_action = menu.addAction("&New Project")
        new_action.triggered.connect(self._on_new_project)

        open_action = menu.addAction("&Open Project...")
        open_action.triggered.connect(self._on_open_project)

        menu.addSeparator()

        save_action = menu.addAction("&Save Project")
        save_action.triggered.connect(self._on_save_project)

        save_as_action = menu.addAction("Save Project &As...")
        save_as_action.triggered.connect(self._on_save_project_as)

        menu.addSeparator()

        exit_action = menu.addAction("E&xit")
        exit_action.triggered.connect(self.close)

    # -- wiring ----------------------------------------------------------
    def _wire_signals(self) -> None:
        self.source_panel.detect_language_requested.connect(self._on_detect_language)
        self.source_panel.import_failed.connect(lambda msg: self._show_error("Import", msg))
        self.source_panel.split_requested.connect(self._on_split_into_sections)

        self.sections_panel.translate_all_requested.connect(self._on_translate_all)
        self.sections_panel.generate_all_requested.connect(self._on_generate_all)
        self.sections_panel.regenerate_section_requested.connect(self._on_regenerate_section)
        self.sections_panel.section_translation_edited.connect(self._on_translation_edited)

        self.tts_panel.engine_changed.connect(self._on_tts_engine_changed)
        self.translation_panel.manage_languages_requested.connect(self._open_language_manager)
        self.tts_panel.manage_voices_requested.connect(self._open_voice_manager)
        self.tts_panel.diagnose_requested.connect(self._on_diagnose_engine)
        self.output_panel.export_requested.connect(self._on_export)
        self.output_panel.normalize_changed.connect(self._rejoin_and_preview)

    def _populate_engines(self) -> None:
        tts_keys = self.registry.list_tts_engines()
        engines = []
        for key in tts_keys:
            engine = self.registry.get_tts_engine(key)
            label = engine.display_name or key
            if not engine.is_available():
                label += "  (not installed)"
            engines.append((key, label))
        self.tts_panel.set_engines(engines)
        if tts_keys:
            self._on_tts_engine_changed(tts_keys[0])

    def _current_translation_engine(self):
        # Argos is the only translation engine (see engine_registry.py's
        # note on the V3 LibreTranslate engine that was added and then
        # removed by request) -- kept as a one-line indirection rather
        # than inlining "argos" at every call site below, so a future
        # second engine only needs to change this one method again.
        return self.registry.get_translation_engine("argos")

    # -- language detection ------------------------------------------------
    def _on_detect_language(self) -> None:
        if self._detection_worker is not None and self._detection_worker.isRunning():
            return
        text = self.source_panel.get_text()
        if not text.strip():
            QMessageBox.information(self, "Nothing to detect", "Type or paste some text first.")
            return
        self.source_panel.detect_button.setEnabled(False)
        self._set_status("Detecting language...")
        engine = self._current_translation_engine()
        self._detection_worker = LanguageDetectionWorker(engine, text)
        self._detection_worker.finished_ok.connect(self._on_language_detected)
        self._detection_worker.failed.connect(lambda msg: self._show_error("Language detection", msg))
        self._detection_worker.finished.connect(lambda: self.source_panel.detect_button.setEnabled(True))
        self._detection_worker.start()

    def _on_language_detected(self, code: str, confidence: float) -> None:
        self.source_panel.set_detected_language(code, confidence)
        self._set_status(f"Detected {code} ({confidence:.0%} confidence).")

    # -- splitting into sections -----------------------------------------
    def _on_split_into_sections(self) -> None:
        text = self.source_panel.get_text()
        if not text.strip():
            QMessageBox.information(self, "Nothing to split", "Type, paste, or import some text first.")
            return
        self._split_into_sections(text)

    def _split_into_sections(self, text: str) -> list[TextSection]:
        mode = ChunkMode(self.source_panel.get_chunk_mode())
        max_chars = self.source_panel.get_max_chunk_chars()
        sections = TextChunker().chunk(text, ChunkerOptions(mode=mode, max_chunk_chars=max_chars))
        self.project.source_text = text
        self.project.chunk_mode = mode.value
        self.project.max_chunk_chars = max_chars
        self.project.sections = sections
        self.sections_panel.set_sections(sections)
        return sections

    def _ensure_sections(self) -> list[TextSection]:
        """Split now if the user went straight to Translate/Generate All."""
        if self.project.sections:
            return self.project.sections
        text = self.source_panel.get_text()
        if not text.strip():
            return []
        return self._split_into_sections(text)

    # -- translation -------------------------------------------------------
    def _on_translate_all(self) -> None:
        if self._translation_worker is not None and self._translation_worker.isRunning():
            return
        sections = self._ensure_sections()
        if not sections:
            QMessageBox.information(self, "Nothing to translate", "Type, paste, or import some text first.")
            return
        self._start_translation(sections)

    def _start_translation(self, sections: list[TextSection]) -> None:
        source_lang = self.source_panel.get_selected_source_language()
        target_lang = self.translation_panel.get_target_language()
        if source_lang is None:
            engine = self._current_translation_engine()
            self._detection_worker = LanguageDetectionWorker(engine, self.project.source_text)
            self._detection_worker.finished_ok.connect(
                lambda code, _conf: self._start_translation_with_lang(sections, code, target_lang)
            )
            self._detection_worker.failed.connect(lambda msg: self._show_error("Language detection", msg))
            self._detection_worker.start()
        else:
            self._start_translation_with_lang(sections, source_lang, target_lang)

    def _start_translation_with_lang(self, sections: list[TextSection], source_lang: str, target_lang: str) -> None:
        self.source_panel.set_detected_language(source_lang, 1.0)
        self.project.source_language = source_lang
        self.project.target_language = target_lang
        engine = self._current_translation_engine()
        self.project.translation_engine = engine.name

        if source_lang == target_lang:
            for section in sections:
                section.translated_text = section.source_text
                section.status = "translated"
                section.error_message = None
                self.sections_panel.update_section(section.index, section)
            self._set_status("Source and target languages match; no translation was needed.")
            return

        if not engine.is_available():
            # argostranslate itself isn't pip-installed. Don't run the
            # batch at all -- every section would otherwise independently
            # hit the same failure and land in the sections table as N
            # identical error rows with no translated text.
            self._show_error(
                "Translation engine unavailable",
                f"{engine.display_name} isn't available right now.\n\n"
                "Try: pip install argostranslate (see requirements.txt / README.md).",
            )
            return

        if not engine.has_translation(source_lang, target_lang):
            reply = QMessageBox.question(
                self,
                "Download translation language",
                f"The {source_lang} \N{RIGHTWARDS ARROW} {target_lang} translation package isn't "
                "installed yet.\n\nDownload and install it now?",
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.sections_panel.set_busy(True)
                self._set_status(f"Downloading translation package {source_lang} \N{RIGHTWARDS ARROW} {target_lang}...")
                worker = ResourceWorker(lambda: engine.install_package(source_lang, target_lang))
                worker.succeeded.connect(
                    lambda _result: self._on_auto_package_installed(sections, source_lang, target_lang)
                )
                worker.failed.connect(self._on_auto_package_failed)
                self._model_worker = worker
                worker.start()
            else:
                self._open_language_manager()
            return

        for section in sections:
            section.status = "translating"
            self.sections_panel.update_section(section.index, section)

        self.sections_panel.set_busy(True)
        self._set_status(f"Starting translation: {source_lang} \N{RIGHTWARDS ARROW} {target_lang}...")
        self._translation_worker = SectionsTranslationWorker(engine, sections, source_lang, target_lang)
        self._translation_worker.section_done.connect(self._on_section_translated)
        self._translation_worker.section_failed.connect(self._on_section_translation_failed)
        self._translation_worker.progress.connect(lambda _done, _total, message: self._set_status(message))
        self._translation_worker.all_done.connect(self._on_translation_batch_done)
        self._translation_worker.start()

    def _on_auto_package_installed(self, sections: list[TextSection], source_lang: str, target_lang: str) -> None:
        self.sections_panel.set_busy(False)
        self._refresh_installed_languages()
        self._set_status(f"Installed {source_lang} \N{RIGHTWARDS ARROW} {target_lang}. Starting translation...")
        self._start_translation_with_lang(sections, source_lang, target_lang)

    def _on_auto_package_failed(self, message: str) -> None:
        self.sections_panel.set_busy(False)
        self._set_status(f"Translation package download failed: {message}")
        self._show_error("Translation package download", message)

    def _on_translation_batch_done(self) -> None:
        self.sections_panel.set_busy(False)
        errors = sum(1 for section in self.project.sections if section.status == "error")
        self._set_status("Translation complete." if not errors else f"Translation finished with {errors} error(s).")

    def _on_section_translated(self, index: int, translated_text: str) -> None:
        section = self._find_section(index)
        if section is None:
            return
        section.translated_text = translated_text
        section.status = "translated"
        section.error_message = None
        self.sections_panel.update_section(index, section)

    def _on_section_translation_failed(self, index: int, message: str) -> None:
        section = self._find_section(index)
        if section is None:
            return
        section.status = "error"
        section.error_message = message
        self.sections_panel.update_section(index, section)

    def _on_translation_edited(self, index: int, new_text: str) -> None:
        section = self._find_section(index)
        if section is None:
            return
        section.translated_text = new_text
        if section.status not in ("synthesizing",):
            section.status = "translated"

    # -- TTS -----------------------------------------------------------
    def _on_tts_engine_changed(self, engine_key: str) -> None:
        if not engine_key:
            return
        # Chatterbox keeps a persistent worker process (with a model
        # loaded in memory) alive across calls for as long as it's the
        # selected engine -- see chatterbox_engine.py's module docstring
        # for why. Switching away from it is the natural point to shut
        # that worker down rather than leaving it idle in memory; this
        # is a no-op if it was never actually started.
        if self._previous_tts_engine_key == "chatterbox" and engine_key != "chatterbox":
            try:
                self.registry.get_tts_engine("chatterbox").shutdown()
            except TTSStudioError:
                pass
        self._previous_tts_engine_key = engine_key
        try:
            engine = self.registry.get_tts_engine(engine_key)
            voices = engine.available_voices()
        except TTSStudioError as exc:
            self._show_error("Voice list", exc.full_message)
            voices = []
        self.tts_panel.set_voices(voices)

    def _on_diagnose_engine(self) -> None:
        """Runs the currently selected TTS engine's `run_diagnostics()`
        (see TTSEngine's docstring) off the GUI thread -- Chatterbox's
        implementation loads a real model and generates a short test
        clip, which can take a while, especially on CPU."""
        engine_key = self.tts_panel.get_selected_engine()
        if not engine_key:
            return
        engine = self.registry.get_tts_engine(engine_key)
        self.tts_panel.set_busy(True)
        self._diagnose_worker = ResourceWorker(engine.run_diagnostics)
        self._diagnose_worker.succeeded.connect(self._on_diagnose_finished)
        self._diagnose_worker.failed.connect(self._on_diagnose_failed)
        self._diagnose_worker.start()

    def _on_diagnose_finished(self, report: object) -> None:
        self.tts_panel.set_busy(False)
        if report is None:
            QMessageBox.information(
                self,
                "Diagnose",
                "This engine doesn't have a deeper diagnostic check -- "
                "is_available() already covers what there is to check for it.",
            )
            return
        QMessageBox.information(self, "Diagnose", json.dumps(report, indent=2))

    def _on_diagnose_failed(self, message: str) -> None:
        self.tts_panel.set_busy(False)
        self._show_error("Diagnose", message)

    def _on_generate_all(self) -> None:
        if self._synthesis_worker is not None and self._synthesis_worker.isRunning():
            return
        sections = self._ensure_sections()
        if not sections:
            QMessageBox.information(self, "Nothing to synthesize", "Type, paste, or import some text first.")
            return
        self._start_synthesis(sections)

    def _on_regenerate_section(self, index: int) -> None:
        if (self._translation_worker is not None and self._translation_worker.isRunning()) or (
            self._synthesis_worker is not None and self._synthesis_worker.isRunning()
        ):
            return
        section = self._find_section(index)
        if section is None:
            return
        source_lang = self.source_panel.get_selected_source_language() or self.project.source_language
        target_lang = self.translation_panel.get_target_language()
        if source_lang is None:
            QMessageBox.information(self, "No source language", "Detect or choose a source language first.")
            return

        engine = self._current_translation_engine()
        section.status = "translating"
        self.sections_panel.update_section(index, section)
        worker = SectionsTranslationWorker(engine, [section], source_lang, target_lang)
        worker.section_done.connect(self._on_section_translated)
        worker.section_failed.connect(self._on_section_translation_failed)
        worker.all_done.connect(lambda: self._start_synthesis([section]))
        # Keep a reference so it isn't garbage-collected mid-run.
        self._translation_worker = worker
        worker.start()

    def _start_synthesis(self, sections: list[TextSection]) -> None:
        settings = self.tts_panel.get_synthesis_settings()
        if settings is None:
            QMessageBox.information(self, "No voice selected", "Choose a TTS engine and voice first.")
            return

        self.project.tts_engine = settings.voice.engine
        self.project.tts_voice_id = settings.voice.id
        self.project.speed = settings.speed
        self.project.volume = settings.volume
        self.project.pitch_semitones = settings.pitch_semitones
        self.project.character_preset = settings.character_preset
        self.project.tts_reference_audio_path = (
            str(settings.reference_audio_path) if settings.reference_audio_path else None
        )
        self.project.tts_exaggeration = settings.exaggeration
        self.project.tts_cfg_weight = settings.cfg_weight
        self.project.tts_temperature = settings.temperature
        self.project.tts_repetition_penalty = settings.repetition_penalty
        self.project.tts_min_p = settings.min_p
        self.project.tts_top_p = settings.top_p
        self.project.tts_top_k = settings.top_k

        for section in sections:
            section.status = "synthesizing"
            self.sections_panel.update_section(section.index, section)

        engine = self.registry.get_tts_engine(settings.voice.engine)
        self.tts_panel.set_busy(True)
        self.sections_panel.set_busy(True)
        self.output_panel.set_status("Generating speech...")
        self._synthesis_worker = SectionsSynthesisWorker(engine, sections, settings)
        self._synthesis_worker.section_done.connect(self._on_section_synthesized)
        self._synthesis_worker.section_failed.connect(self._on_section_synthesis_failed)
        self._synthesis_worker.progress.connect(lambda _done, _total, message: self._set_status(message))
        self._synthesis_worker.all_done.connect(self._on_synthesis_batch_done)
        self._synthesis_worker.start()

    def _on_section_synthesized(self, index: int, result) -> None:
        section = self._find_section(index)
        if section is None:
            return
        # A regenerate replaces this section's audio. If the file it used
        # to point at was one of our own not-yet-saved scratch temp WAVs,
        # nothing references it any more once we swap in the new path, so
        # clean it up now instead of leaving it orphaned in the OS temp
        # folder. A file that's already inside a saved project's audio/
        # folder is left alone -- it's simply overwritten the next time
        # the project is saved (see ProjectManager.save), so an unsaved
        # regenerate can never destroy an on-disk project asset.
        old_path = section.audio_path
        section.audio_path = result.samples_path
        section.status = "synthesized"
        section.error_message = None
        self.sections_panel.update_section(index, section)
        if old_path and Path(old_path) != Path(result.samples_path) and is_scratch_temp_file(Path(old_path)):
            try:
                Path(old_path).unlink(missing_ok=True)
            except OSError:
                pass

    def _on_section_synthesis_failed(self, index: int, message: str) -> None:
        section = self._find_section(index)
        if section is None:
            return
        section.status = "error"
        section.error_message = message
        self.sections_panel.update_section(index, section)

    def _on_synthesis_batch_done(self) -> None:
        self.tts_panel.set_busy(False)
        self.sections_panel.set_busy(False)
        self._rejoin_and_preview()
        errors = sum(1 for section in self.project.sections if section.status == "error")
        self._set_status("Audio generation complete." if not errors else f"Audio finished with {errors} error(s).")

    def _rejoin_and_preview(self) -> None:
        clips = []
        for section in sorted(self.project.sections, key=lambda s: s.index):
            if section.audio_path and Path(section.audio_path).exists():
                clips.append(self.audio.load(section.audio_path))
        if not clips:
            self.output_panel.set_status("No audio generated yet.")
            return
        joined_samples, joined_rate = self.audio.join(clips)
        if self.output_panel.get_normalize_output():
            # Applied to the whole joined clip, once -- not per section --
            # so relative loudness between sections is preserved; only the
            # overall level is brought up (or down) to the target peak.
            # Export re-encodes from this same preview file (see
            # _on_export() below), so this one call covers both.
            joined_samples = self.audio.normalize_peak(joined_samples)

        fd, path_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_preview_")
        os.close(fd)
        preview_path = Path(path_str)
        self.audio.export_wav(joined_samples, joined_rate, preview_path)
        self.output_panel.load_audio(preview_path)

    # -- export ------------------------------------------------------------
    def _on_export(self) -> None:
        current = self.output_panel.get_current_path()
        if current is None:
            return
        fmt = self.output_panel.get_export_format()
        default_dir = self.settings.default_export_dir
        Path(default_dir).mkdir(parents=True, exist_ok=True)
        target, _ = QFileDialog.getSaveFileName(
            self, "Export audio", str(Path(default_dir) / f"output.{fmt}"), f"{fmt.upper()} audio (*.{fmt})"
        )
        if not target:
            return
        try:
            samples, rate = self.audio.load(current)
            self.audio.export(samples, rate, Path(target), fmt)
            self.output_panel.set_status(f"Exported to {target}")
        except TTSStudioError as exc:
            self._show_error("Export", exc.full_message)

    # -- project: new / open / save -----------------------------------
    def _on_new_project(self) -> None:
        if self.project.sections:
            reply = QMessageBox.question(
                self, "New Project", "Discard the current project and start a new one?"
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        self.project = Project()
        self.source_panel.set_text("")
        self.sections_panel.set_sections([])
        self.output_panel.set_status("No audio generated yet.")
        self.setWindowTitle(_APP_TITLE)

    def _on_open_project(self) -> None:
        directory = QFileDialog.getExistingDirectory(self, "Open Project")
        if not directory:
            return
        try:
            project = self.project_manager.load(Path(directory))
        except TTSStudioError as exc:
            self._show_error("Open Project", exc.full_message)
            return

        self.project = project
        self.source_panel.set_text(project.source_text)
        self.source_panel.set_source_language(project.source_language)
        # project.translation_engine is kept for backward-compatible loading
        # of older saved projects, but there's no engine selector to restore
        # into any more -- Argos is the only translation engine now.
        if project.target_language:
            self.translation_panel.set_target_language(project.target_language)
        self.source_panel.set_chunk_mode(project.chunk_mode)
        self.source_panel.set_max_chunk_chars(project.max_chunk_chars)
        self.sections_panel.set_sections(project.sections)

        if project.tts_engine:
            self.tts_panel.set_selected_engine(project.tts_engine)
            self._on_tts_engine_changed(project.tts_engine)
            if project.tts_voice_id:
                self.tts_panel.set_selected_voice(project.tts_voice_id)
        self.tts_panel.set_speed(project.speed)
        self.tts_panel.set_volume(project.volume)
        self.tts_panel.set_pitch(project.pitch_semitones)
        self.tts_panel.set_character(project.character_preset)
        self.tts_panel.set_reference_audio_path(project.tts_reference_audio_path)
        # Must come after set_selected_engine()/set_selected_voice() above
        # (already true for set_speed()/set_pitch()/etc. too): selecting a
        # voice resets these to that tier's own default (see TTSPanel.
        # _apply_chatterbox_controls), so setting the saved project's real
        # values has to happen afterward or they'd just get overwritten.
        self.tts_panel.set_exaggeration(project.tts_exaggeration)
        self.tts_panel.set_cfg_weight(project.tts_cfg_weight)
        self.tts_panel.set_temperature(project.tts_temperature)
        self.tts_panel.set_repetition_penalty(project.tts_repetition_penalty)
        self.tts_panel.set_min_p(project.tts_min_p)
        self.tts_panel.set_top_p(project.tts_top_p)
        self.tts_panel.set_top_k(project.tts_top_k)
        self.output_panel.set_export_format(project.output_format)
        self.output_panel.set_normalize_output(project.normalize_output)

        self._rejoin_and_preview()
        self.setWindowTitle(f"{_APP_TITLE} -- {project.name}")

    def _on_save_project(self) -> None:
        if self.project.project_dir is None:
            self._on_save_project_as()
            return
        self._save_to(Path(self.project.project_dir))

    def _on_save_project_as(self) -> None:
        default_dir = self.settings.default_export_dir
        Path(default_dir).mkdir(parents=True, exist_ok=True)
        target, _ = QFileDialog.getSaveFileName(
            self, "Save Project As", str(Path(default_dir) / "MyProject"), ""
        )
        if not target:
            return
        self._save_to(Path(target))

    def _save_to(self, project_dir: Path) -> None:
        self.project.output_format = self.output_panel.get_export_format()
        self.project.normalize_output = self.output_panel.get_normalize_output()
        try:
            self.project_manager.save(self.project, project_dir)
            self.setWindowTitle(f"{_APP_TITLE} -- {self.project.name}")
            self.output_panel.set_status(f"Project saved to {project_dir}")
        except TTSStudioError as exc:
            self._show_error("Save Project", exc.full_message)

    # -- helpers -------------------------------------------------------
    def _find_section(self, index: int) -> Optional[TextSection]:
        return next((s for s in self.project.sections if s.index == index), None)

    def _show_error(self, title: str, message: str) -> None:
        logger.error("%s: %s", title, message)
        QMessageBox.warning(self, title, message)

    def _set_status(self, message: str) -> None:
        # Single readout location -- see the comment on the "Ready" call
        # in __init__ for why this no longer also touches statusBar().
        self.output_panel.set_status(message)

    # -- V3: Resource Manager (in-app downloads) --------------------------
    def _refresh_installed_languages(self) -> None:
        """Make sure every already-installed Argos pair's languages are
        selectable in both language combos, even ones not in the static
        COMMON_LANGUAGES starter list (e.g. installed on a previous run)."""
        try:
            engine = self.registry.get_translation_engine("argos")
            for package in engine.installed_packages():
                self.source_panel.add_language(package["from_code"], package["from_name"])
                self.source_panel.add_language(package["to_code"], package["to_name"])
                self.translation_panel.add_language(package["from_code"], package["from_name"])
                self.translation_panel.add_language(package["to_code"], package["to_name"])
        except TTSStudioError as exc:
            logger.warning("Could not refresh installed translation languages: %s", exc.full_message)

    def _add_discovered_languages(self, languages: object) -> None:
        for code, name in dict(languages).items():
            self.source_panel.add_language(code, name)
            self.translation_panel.add_language(code, name)

    def _resources_changed(self) -> None:
        """Something was installed via the Resource Manager -- refresh
        whatever list(s) could now show a new option."""
        self._refresh_installed_languages()
        current_engine = self.tts_panel.get_selected_engine()
        if current_engine:
            self._on_tts_engine_changed(current_engine)

    def _open_language_manager(self) -> None:
        translation_engine = self.registry.get_translation_engine("argos")
        dialog = LanguageManagerDialog(translation_engine, self)
        dialog.languages_discovered.connect(self._add_discovered_languages)
        dialog.language_installed.connect(self._select_language_pair)
        dialog.resources_changed.connect(self._resources_changed)
        self._resource_manager = dialog
        dialog.exec()
        self._resource_manager = None

    def _open_voice_manager(self) -> None:
        # Jump straight to whichever engine's tab the user is currently
        # using (tab order: 0 Piper, 1 Kokoro -- see gui/resource_manager.py).
        start_tab = 1 if self.tts_panel.get_selected_engine() == "kokoro" else 0
        piper_engine = self.registry.get_tts_engine("piper")
        kokoro_engine = self.registry.get_tts_engine("kokoro")
        dialog = VoiceManagerDialog(piper_engine, kokoro_engine, start_tab, self)
        dialog.resources_changed.connect(self._resources_changed)
        self._resource_manager = dialog
        dialog.exec()
        self._resource_manager = None

    def _select_language_pair(self, source: str, target: str) -> None:
        self.source_panel.set_source_language(source)
        self.translation_panel.set_target_language(target)

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        self.settings.save()
        self._cleanup_session_temp_files()
        # Chatterbox's persistent worker (see chatterbox_engine.py) needs
        # an explicit shutdown or it'd be left running as an orphaned
        # python.exe process after the window closes. A no-op if it was
        # never started.
        if self._previous_tts_engine_key == "chatterbox":
            try:
                self.registry.get_tts_engine("chatterbox").shutdown()
            except TTSStudioError:
                pass
        super().closeEvent(event)

    def _cleanup_session_temp_files(self) -> None:
        """Best-effort sweep of this app's own temp WAVs on exit.

        Per-call cleanup (in workers.py and _on_section_synthesized above)
        already removes a file the moment nothing references it any more,
        but a few paths still only exist for the life of the session --
        e.g. the running preview built by _rejoin_and_preview, or a
        section's temp audio that was never saved into a project. Sweep
        anything matching this app's own temp-file prefixes; a file still
        genuinely in use elsewhere can't collide since every prefix here
        is unique to this app and this process's synthesize() calls.
        """
        temp_dir = Path(tempfile.gettempdir())
        # Real gap, found in review: this list was missing Chatterbox's
        # own temp-file prefixes entirely (chatterbox_engine.py's
        # "ttsstudio_chatterbox_" for real generations and
        # _chatterbox_worker.py's "ttsstudio_chatterbox_diag_" for
        # Diagnose test clips -- "ttsstudio_chatterbox_" alone covers
        # both, since the diag prefix is itself an extension of it) and
        # audio_processor.py's own "ttsstudio_export_" (used when
        # rendering a non-WAV export format). Per-call cleanup still
        # handles the common success path for all of these; this sweep
        # exists specifically for what per-call cleanup can't reach -- a
        # crash, an aborted Diagnose run, or a generation interrupted
        # mid-synthesis -- so missing a prefix here means exactly those
        # failure cases quietly accumulate temp files forever instead of
        # being cleaned up on the next normal exit.
        prefixes = (
            "ttsstudio_piper_",
            "ttsstudio_kokoro_",
            "ttsstudio_chatterbox_",
            "ttsstudio_section_",
            "ttsstudio_preview_",
            "ttsstudio_export_",
        )
        for prefix in prefixes:
            for path in temp_dir.glob(f"{prefix}*"):
                try:
                    path.unlink()
                except OSError:
                    pass
