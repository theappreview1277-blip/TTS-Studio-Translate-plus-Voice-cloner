"""TTS Studio - modular, offline-first translation + text-to-speech desktop app."""

__version__ = "0.1.0"  # Version 1 (V1)
