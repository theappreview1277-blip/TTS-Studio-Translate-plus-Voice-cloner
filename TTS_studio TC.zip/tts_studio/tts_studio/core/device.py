"""
Compute device detection.

Both V1 TTS engines (Piper, Kokoro) run on onnxruntime, so GPU
availability is checked through onnxruntime's execution providers
rather than assuming a torch/CUDA stack is installed. This keeps V1's
dependency footprint light (no PyTorch requirement) while still
degrading gracefully to CPU when no GPU/onnxruntime-gpu is present.
torch-based engines added later (Chatterbox, F5-TTS, XTTS) can extend
`gpu_summary()` with their own check without changing this module's
contract.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class GpuSummary:
    onnx_providers: list[str]
    has_cuda: bool
    has_directml: bool  # relevant on Windows without a discrete NVIDIA GPU
    torch_cuda_available: bool


def _onnx_providers() -> list[str]:
    try:
        import onnxruntime as ort

        return ort.get_available_providers()
    except ImportError:
        logger.debug("onnxruntime not installed; assuming CPU-only.")
        return ["CPUExecutionProvider"]


def _torch_cuda_available() -> bool:
    try:
        import torch  # optional; only present if a torch-based engine was installed

        return bool(torch.cuda.is_available())
    except ImportError:
        return False
    except Exception:  # pragma: no cover - defensive: a broken torch install shouldn't crash the app
        logger.warning("torch.cuda.is_available() raised unexpectedly.", exc_info=True)
        return False


def gpu_summary() -> GpuSummary:
    providers = _onnx_providers()
    return GpuSummary(
        onnx_providers=providers,
        has_cuda="CUDAExecutionProvider" in providers,
        has_directml="DmlExecutionProvider" in providers,
        torch_cuda_available=_torch_cuda_available(),
    )


def preferred_onnx_providers() -> list[str]:
    """Ordered provider list: best available first, CPU always last as fallback."""
    summary = gpu_summary()
    providers = []
    if summary.has_cuda:
        providers.append("CUDAExecutionProvider")
    elif summary.has_directml:
        providers.append("DmlExecutionProvider")
    providers.append("CPUExecutionProvider")
    return providers
