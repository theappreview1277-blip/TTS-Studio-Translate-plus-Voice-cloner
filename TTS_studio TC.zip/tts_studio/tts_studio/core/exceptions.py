"""
Application-specific exceptions.

Every exception carries a `user_message` written for a normal Windows
user (not a stack trace) so the GUI's error dialogs can display
`str(exc.user_message)` directly without translation logic scattered
around the codebase. Internal detail (for logs) stays in the normal
exception message / __cause__ chain.
"""
from __future__ import annotations


class TTSStudioError(Exception):
    """Base class for every error this app raises on purpose."""

    def __init__(self, user_message: str, *, detail: str | None = None):
        self.user_message = user_message
        self.detail = detail
        super().__init__(f"{user_message}" + (f" ({detail})" if detail else ""))

    @property
    def full_message(self) -> str:
        """`user_message` plus the actionable `detail`, if any -- this is
        what should actually reach the user (error dialogs, section-error
        tooltips, logs), not `user_message` alone.

        This used to be a real gap: every GUI call site emitted/displayed
        `exc.user_message` only, so `detail` -- the one piece of text that
        actually says *why* something failed (a subprocess's stderr, an
        expected file path, a download's underlying error) -- was
        constructed everywhere and then silently thrown away. A user
        hitting e.g. SynthesisFailedError("<real traceback from the
        Chatterbox worker>") only ever saw the generic "Speech generation
        failed." with no way to self-diagnose or even report back
        anything specific. Fixed by routing every call site in
        main_window.py/workers.py/resource_manager.py/source_panel.py
        through this property instead of `user_message` directly.
        """
        if self.detail:
            return f"{self.user_message}\n\n{self.detail}"
        return self.user_message


class EngineUnavailableError(TTSStudioError):
    """A translation/TTS engine's Python package isn't installed."""

    def __init__(self, engine_name: str, install_hint: str):
        super().__init__(
            f"The '{engine_name}' engine isn't installed yet.",
            detail=f"Try: {install_hint}",
        )
        self.engine_name = engine_name
        self.install_hint = install_hint


class ModelNotFoundError(TTSStudioError):
    """A voice/model file the engine needs is missing on disk."""

    def __init__(self, model_name: str, engine_name: str, expected_path: str):
        super().__init__(
            f"The voice model '{model_name}' for {engine_name} isn't installed.",
            detail=f"Expected at: {expected_path}",
        )
        self.model_name = model_name
        self.engine_name = engine_name


class UnsupportedLanguageError(TTSStudioError):
    def __init__(self, message: str):
        super().__init__(message)


class LanguageDetectionError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__(
            "Couldn't detect the language of that text.", detail=detail
        )


class TranslationFailedError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__("Translation failed.", detail=detail)


class SynthesisFailedError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__("Speech generation failed.", detail=detail)


class AudioExportError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__("Couldn't export the audio file.", detail=detail)


class FFmpegNotFoundError(TTSStudioError):
    def __init__(self):
        super().__init__(
            "FFmpeg wasn't found on this system.",
            detail="Needed for MP3 export. Install it and make sure "
            "'ffmpeg' is on your PATH.",
        )


class ResourceDownloadError(TTSStudioError):
    """A V3 in-app download (translation package, Piper voice, Kokoro
    voice pack) failed -- network error, bad archive, disk full, etc."""

    def __init__(self, resource_name: str, detail: str):
        super().__init__(f"Couldn't download '{resource_name}'.", detail=detail)
        self.resource_name = resource_name


class ResourceRemovalError(TTSStudioError):
    """A V3 in-app removal (translation package, Piper voice, Kokoro
    voice pack) failed -- e.g. a file still open elsewhere, permissions."""

    def __init__(self, resource_name: str, detail: str):
        super().__init__(f"Couldn't remove '{resource_name}'.", detail=detail)
        self.resource_name = resource_name


class InsufficientResourcesError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__(
            "Your system doesn't have enough free memory/VRAM for this operation.",
            detail=detail,
        )


class CorruptedProjectError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__("This project file looks corrupted or incomplete.", detail=detail)


class DocumentImportError(TTSStudioError):
    def __init__(self, detail: str):
        super().__init__("Couldn't read that document.", detail=detail)


class InvalidOutputLocationError(TTSStudioError):
    def __init__(self, path: str):
        super().__init__(
            f"Can't write to '{path}'.",
            detail="Check the folder exists and you have permission to write there.",
        )
