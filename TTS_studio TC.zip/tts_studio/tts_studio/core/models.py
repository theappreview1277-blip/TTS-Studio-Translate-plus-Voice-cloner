"""
Core data models.

These are plain dataclasses with no dependency on any specific engine,
GUI toolkit, or storage format. Engines (translation/TTS) and the GUI
both speak this shared vocabulary, which is what keeps them decoupled.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


#: (key, display_label) pairs for the Kokoro voice-blending "character"
#: system -- see engines/tts/kokoro_engine.py's _CHARACTER_STYLES for the
#: mix ratios and speed/gain adjustments each key maps to. "neutral" must
#: always be first and always means "no blending, use the voice as-is",
#: since it's the safe default for engines/voices that don't support this
#: at all (see Voice.supports_character_presets below).
CHARACTER_PRESETS: list[tuple[str, str]] = [
    ("neutral", "Neutral"),
    ("warm", "Warm"),
    ("calm", "Calm"),
    ("energetic", "Energetic"),
    ("dramatic", "Dramatic"),
    ("storyteller", "Storyteller"),
]


@dataclass(frozen=True)
class Voice:
    """A single selectable voice, owned by exactly one TTS engine."""

    id: str  # engine-specific identifier, e.g. "en_US-lessac-medium" or "af_sarah"
    name: str  # human-readable label shown in the GUI
    engine: str  # registry name of the owning engine, e.g. "piper", "kokoro"
    language: str  # BCP-47-ish code, e.g. "en-US", "fr-FR"
    gender: Optional[str] = None
    sample_rate: int = 22050
    is_installed: bool = True
    size_mb: Optional[float] = None

    # Capability flags: the GUI queries these to decide which controls to
    # show for the *currently selected* voice, instead of hard-coding
    # per-engine behaviour. This is what satisfies "don't show voice
    # cloning controls for an engine that can't clone".
    supports_speed: bool = True
    supports_pitch: bool = False
    # V4 follow-up #2: how far Speed/Pitch can be pushed isn't the same
    # for every engine. Piper/Kokoro implement both as part of their own
    # model-level synthesis (Piper's `--length-scale`, Kokoro's `speed`
    # kwarg), which holds up fine across a wide range. Chatterbox has no
    # native equivalent for either, so this app applies them afterward as
    # ffmpeg DSP on the finished WAV instead (see chatterbox_engine.py's
    # _apply_speed_and_pitch()) -- a naive time-stretch/resample-based
    # approach that starts introducing audible artifacts (warble, a
    # robotic timbre) well before the wide range below does for a native
    # implementation. Each Voice declares its own safe range rather than
    # the GUI hard-coding "narrower for Chatterbox" by engine name -- see
    # TTSPanel._apply_voice_capabilities(), which reads this generically.
    speed_range: tuple[float, float] = (0.5, 2.0)
    pitch_range: tuple[float, float] = (-12.0, 12.0)
    supports_volume: bool = True
    supports_cloning: bool = False
    # V3: voice-style blending ("character" presets). Only Kokoro voices
    # set this True (it needs kokoro-onnx's get_voice_style()/ndarray-voice
    # support -- see kokoro_engine.py) -- the GUI reads this flag rather
    # than special-casing "kokoro" by name, same as every other capability
    # flag here.
    supports_character_presets: bool = False
    # V4 follow-up: Chatterbox's real, native generation-time controls,
    # verified directly against chatterbox-tts's own source (see
    # chatterbox_engine.py's module docstring) rather than assumed from
    # its README alone. These are deliberately split into several narrow
    # flags, same philosophy as every capability flag above, because the
    # three Chatterbox tiers genuinely support different subsets:
    # Original's generate() takes exaggeration/cfg_weight/min_p and has
    # no top_k parameter at all (passing one raises TypeError); Turbo/
    # Nano's generate() takes top_k but its own source explicitly warns
    # that exaggeration/cfg_weight/min_p "are not supported by the [Turbo/
    # Nano] version and will be ignored" if passed. temperature,
    # repetition_penalty, and top_p are accepted (and meaningful) on
    # every tier, so they don't need their own flag -- supports_
    # advanced_sampling alone covers whether to show that group at all.
    supports_expression: bool = False  # exaggeration + cfg_weight sliders (Original only)
    # True for the Turbo/Nano tier family, False for Original -- used by
    # TTSPanel to pick which Style preset table applies (Original's own,
    # or Turbo/Nano's own) and whether to show the preset dropdown at all
    # for a tier that doesn't set supports_expression. This used to also
    # gate a row of inline sound-tag insert buttons in SourcePanel
    # ([laugh]/[cough]/[chuckle], confirmed against chatterbox's own
    # README) under the name supports_sound_tags -- removed after a real
    # user found [laugh]/[chuckle] didn't actually work in practice and
    # asked for all three to come out; see ARCHITECTURE.md section I for
    # that story. Renamed rather than kept under its old name once its
    # only remaining job had nothing to do with sound tags any more.
    supports_turbo_nano_presets: bool = False
    supports_advanced_sampling: bool = False  # show the Advanced group at all (every Chatterbox tier)
    supports_min_p: bool = False  # min_p lives in Advanced, but only for Original
    supports_top_k: bool = False  # top_k lives in Advanced, but only for Turbo/Nano

    def label(self) -> str:
        gender_part = f", {self.gender}" if self.gender else ""
        return f"{self.name} ({self.language}{gender_part})"


@dataclass
class SynthesisSettings:
    """Everything needed to turn text into audio with a chosen voice."""

    voice: Voice
    speed: float = 1.0  # 1.0 = normal; >1 faster, <1 slower
    pitch_semitones: float = 0.0  # only meaningful if voice.supports_pitch
    volume: float = 1.0  # linear gain multiplier, applied uniformly in AudioProcessor
    character_preset: str = "neutral"  # only meaningful if voice.supports_character_presets
    # V4: path to a short reference clip a cloning-capable engine should
    # match the speaker identity of. Only meaningful if voice.supports_cloning;
    # every other engine's synthesize() simply never looks at this field,
    # which is what keeps adding a cloning engine from touching Piper's or
    # Kokoro's code at all. None means "use the engine's own default voice"
    # (e.g. Chatterbox's built-in speaker) rather than an error.
    reference_audio_path: Optional[Path] = None
    output_format: str = "wav"  # "wav" | "flac" | "ogg" | "mp3" as of V2, see AudioProcessor
    # V4 follow-up: Chatterbox's own native generation-time controls (see
    # Voice.supports_expression/supports_advanced_sampling/supports_min_p/
    # supports_top_k above for exactly which tier honors which of these).
    # Defaults below are chatterbox-tts's own upstream defaults for
    # Original's generate() -- verified directly against its source, not
    # guessed -- so a voice/engine that ignores these fields entirely
    # (every non-Chatterbox voice, and Turbo/Nano for the first three)
    # still gets a sensible, harmless value rather than an arbitrary one.
    exaggeration: float = 0.5  # "Expression" in the GUI; Original only
    cfg_weight: float = 0.5  # "Voice Guidance" in the GUI; Original only
    temperature: float = 0.8  # every Chatterbox tier
    repetition_penalty: float = 1.2  # every Chatterbox tier
    min_p: float = 0.05  # Original only
    top_p: float = 1.0  # every Chatterbox tier (Turbo/Nano's own upstream default is 0.95,
    # not 1.0 -- TTSPanel resets this field to whichever default matches
    # the newly-selected tier when the voice changes, the same reset-on-
    # capability-change pattern already used for pitch/character_preset)
    top_k: int = 1000  # Turbo/Nano only


@dataclass
class LanguageDetectionResult:
    language_code: str
    confidence: float  # 0..1, engine-reported or heuristic


@dataclass
class SynthesisResult:
    """What a TTSEngine.synthesize() call hands back."""

    samples_path: Path  # temp or final WAV path holding raw synthesized audio
    sample_rate: int
    duration_seconds: float
    engine: str
    voice_id: str


@dataclass
class TextSection:
    """One chunk of text as produced by the TextChunker."""

    index: int
    source_text: str
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    is_heading: bool = False
    translated_text: Optional[str] = None
    audio_path: Optional[Path] = None
    # pending | translating | translated | synthesizing | synthesized | error
    status: str = "pending"
    error_message: Optional[str] = None


@dataclass
class Project:
    """
    In-memory representation of a working session, and what
    ProjectManager (V2) reads/writes as project.json plus a project
    directory (see project/project_manager.py for the exact layout).

    TTS settings are stored as flat, primitive fields (engine name,
    voice id, speed/volume/pitch numbers) rather than nesting a
    SynthesisSettings/Voice object -- Voice carries engine-owned
    metadata (sample rate, capability flags, ...) that shouldn't be
    duplicated into every saved project file. MainWindow reconstructs
    a full Voice by looking `tts_voice_id` up in the chosen engine's
    `available_voices()` when a project is loaded.

    `tts_reference_audio_path` (V4, Chatterbox voice cloning) is stored
    as a plain absolute path string, unlike section audio: it is
    deliberately NOT copied into the project directory the way
    `TextSection.audio_path` is, so moving or sharing a saved project
    to another machine requires bringing that reference clip along
    separately if you want to resynthesize with the same cloned voice.
    Documented as a known limitation rather than silently broken --
    see ARCHITECTURE.md section I.
    """

    source_text: str = ""
    source_language: Optional[str] = None  # None = not yet detected
    target_language: Optional[str] = None
    translation_engine: Optional[str] = None
    tts_engine: Optional[str] = None
    tts_voice_id: Optional[str] = None
    speed: float = 1.0
    volume: float = 1.0
    pitch_semitones: float = 0.0
    character_preset: str = "neutral"  # V3 Kokoro voice-blending preset, see CHARACTER_PRESETS
    tts_reference_audio_path: Optional[str] = None  # V4: Chatterbox cloning reference clip
    # V4 follow-up #2: peak-normalizes the final joined preview/export
    # audio (see AudioProcessor.normalize_peak() and MainWindow.
    # _rejoin_and_preview()) so sections rendered at different volumes,
    # or a cloned voice that came out quieter than the built-in one,
    # don't need a separate manual pass in another program. Applied once
    # to the whole joined clip, not per-section -- see OutputPanel's
    # checkbox for the user-facing control.
    normalize_output: bool = False
    # V4 follow-up: Chatterbox's native generation controls -- see
    # SynthesisSettings' matching fields for what each one does and why
    # these particular defaults. Saved/restored the same flat-field way
    # as speed/volume/pitch_semitones above, for the same reason: no
    # SynthesisSettings/Voice object is nested into the saved project.
    tts_exaggeration: float = 0.5
    tts_cfg_weight: float = 0.5
    tts_temperature: float = 0.8
    tts_repetition_penalty: float = 1.2
    tts_min_p: float = 0.05
    tts_top_p: float = 1.0
    tts_top_k: int = 1000
    output_format: str = "wav"
    chunk_mode: str = "automatic"  # sentence | paragraph | automatic | custom
    max_chunk_chars: int = 500
    sections: list[TextSection] = field(default_factory=list)

    # Persistence metadata -- None until the project has been saved once.
    name: Optional[str] = None
    project_dir: Optional[Path] = None
    created_at: Optional[str] = None  # ISO 8601
    modified_at: Optional[str] = None  # ISO 8601
