"""
Adapter interfaces (ports, in hexagonal-architecture terms).

The GUI and Core layers only ever talk to these two abstract classes.
A concrete engine (Argos, Piper, Kokoro, and anything added later --
LibreTranslate, XTTS, Chatterbox, Qwen3-TTS, ...) implements one of
them and registers itself with EngineRegistry. Nothing outside
`tts_studio/engines/` should ever import a specific engine's package
directly -- that boundary is what lets new engines be added without
touching the GUI.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from tts_studio.core.models import LanguageDetectionResult, SynthesisSettings, SynthesisResult, Voice


class TranslationEngine(ABC):
    """One offline or online machine-translation backend."""

    #: Unique, stable registry key, e.g. "argos". Set on the subclass.
    name: str = ""
    #: Human-readable label for the GUI, e.g. "Argos Translate (offline)".
    display_name: str = ""

    @abstractmethod
    def is_available(self) -> bool:
        """Whether this engine's runtime is importable/usable right now."""

    @abstractmethod
    def supported_languages(self) -> list[str]:
        """BCP-47-ish codes this engine can translate between."""

    @abstractmethod
    def detect_language(self, text: str) -> LanguageDetectionResult:
        """Best-effort source language detection."""

    @abstractmethod
    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """Translate `text` from `source_lang` to `target_lang`."""


class TTSEngine(ABC):
    """One local (or remote) text-to-speech backend."""

    name: str = ""
    display_name: str = ""

    @abstractmethod
    def is_available(self) -> bool:
        """Whether this engine's runtime is importable/usable right now."""

    @abstractmethod
    def supported_languages(self) -> list[str]:
        ...

    @abstractmethod
    def available_voices(self, language: Optional[str] = None) -> list[Voice]:
        """Voices this engine can use, optionally filtered by language."""

    @abstractmethod
    def synthesize(self, text: str, settings: SynthesisSettings) -> SynthesisResult:
        """Render `text` to audio using `settings.voice` and return the result."""

    @abstractmethod
    def estimate_duration(self, text: str, settings: SynthesisSettings) -> float:
        """Rough seconds estimate, used for progress UI before generation runs."""

    def run_diagnostics(self) -> Optional[dict]:
        """Optional deep self-check beyond `is_available()` -- e.g.
        actually loading a model and generating a short test clip, not
        just checking that a module imports. Returns `None` if this
        engine doesn't support it (the default here); a concrete engine
        overrides this to return a JSON-able dict of findings instead.
        The GUI's "Diagnose..." button (see TTSPanel) calls this
        generically on whichever engine is selected, without needing a
        per-engine special case -- same reasoning as every capability
        flag on Voice."""
        return None

    def warmup_notice(self, settings: SynthesisSettings) -> Optional[str]:
        """Optional heads-up message for a `synthesize()` call that's
        about to be unusually slow for a reason that has nothing to do
        with the text itself -- most concretely, an engine that has to
        construct a large model from scratch before it can generate
        anything, with no progress of its own to report while doing so.
        Returns `None` if the upcoming call isn't expected to be
        unusually slow (the default here, and what every engine gets
        once nothing needs to warm up). A concrete engine overrides this
        to return a short user-facing string instead; `SectionsSynthesisWorker`
        (see gui/workers.py) shows it in place of the normal "Generating
        audio N of M..." status for that one call, generically, without
        the GUI needing a per-engine special case -- same reasoning as
        `run_diagnostics()` above. Added after a real user watched a
        stalled-looking status message during Chatterbox's first model
        load (which can genuinely take minutes on CPU) and reasonably
        assumed the app had frozen."""
        return None
