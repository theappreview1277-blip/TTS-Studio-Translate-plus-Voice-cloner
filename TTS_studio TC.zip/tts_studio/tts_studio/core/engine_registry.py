"""
Central registry of translation/TTS engines.

Adding a new engine later (LibreTranslate, XTTS, Chatterbox, Qwen3-TTS, ...)
means: write a new file under `engines/translation/` or `engines/tts/`
implementing the relevant interface, then add one line to
`register_builtin_engines()` below. Nothing in `gui/` ever imports an
engine module directly -- it only ever asks the registry.
"""
from __future__ import annotations

import logging
from typing import Callable

from tts_studio.core.interfaces import TranslationEngine, TTSEngine

logger = logging.getLogger(__name__)


class EngineRegistry:
    def __init__(self) -> None:
        self._translation_factories: dict[str, Callable[[], TranslationEngine]] = {}
        self._tts_factories: dict[str, Callable[[], TTSEngine]] = {}
        self._translation_cache: dict[str, TranslationEngine] = {}
        self._tts_cache: dict[str, TTSEngine] = {}

    # -- registration ----------------------------------------------------
    def register_translation_engine(self, key: str, factory: Callable[[], TranslationEngine]) -> None:
        self._translation_factories[key] = factory

    def register_tts_engine(self, key: str, factory: Callable[[], TTSEngine]) -> None:
        self._tts_factories[key] = factory

    # -- lookup ------------------------------------------------------------
    def get_translation_engine(self, key: str) -> TranslationEngine:
        if key not in self._translation_cache:
            if key not in self._translation_factories:
                raise KeyError(f"No translation engine registered as '{key}'")
            self._translation_cache[key] = self._translation_factories[key]()
        return self._translation_cache[key]

    def get_tts_engine(self, key: str) -> TTSEngine:
        if key not in self._tts_cache:
            if key not in self._tts_factories:
                raise KeyError(f"No TTS engine registered as '{key}'")
            self._tts_cache[key] = self._tts_factories[key]()
        return self._tts_cache[key]

    def list_translation_engines(self, *, available_only: bool = False) -> list[str]:
        keys = list(self._translation_factories.keys())
        if not available_only:
            return keys
        return [k for k in keys if self.get_translation_engine(k).is_available()]

    def list_tts_engines(self, *, available_only: bool = False) -> list[str]:
        keys = list(self._tts_factories.keys())
        if not available_only:
            return keys
        return [k for k in keys if self.get_tts_engine(k).is_available()]


def register_builtin_engines(registry: EngineRegistry) -> None:
    """Register every engine that ships with this version of the app."""
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine
    from tts_studio.engines.tts.piper_engine import PiperTTSEngine
    from tts_studio.engines.tts.kokoro_engine import KokoroTTSEngine
    from tts_studio.engines.tts.chatterbox_engine import ChatterboxTTSEngine

    registry.register_translation_engine("argos", ArgosTranslationEngine)
    registry.register_tts_engine("piper", PiperTTSEngine)
    registry.register_tts_engine("kokoro", KokoroTTSEngine)
    registry.register_tts_engine("chatterbox", ChatterboxTTSEngine)

    # LibreTranslate (an HTTP client for a self-hosted, optional AGPL-3.0
    # server) was added in V3 and then removed by request -- Argos stays
    # the sole, fully-offline translation engine. See ARCHITECTURE.md
    # section C for the original evaluation if it's ever worth revisiting.

    # V4+: Chatterbox (voice cloning) registered above. Qwen3-TTS and
    # Chatterbox's own Multilingual/Turbo/Nano variants are still staged --
    # see ARCHITECTURE.md sections H/J.


# Module-level singleton used by the GUI. Kept simple on purpose -- this
# is a desktop app with one window, not a multi-tenant service.
default_registry = EngineRegistry()
register_builtin_engines(default_registry)
