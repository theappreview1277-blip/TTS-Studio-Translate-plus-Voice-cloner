"""
Project save/load.

Directory layout (relocatable -- audio paths are stored relative to
the project directory, not absolute):

    <ProjectName>/
        project.json        Metadata, settings, and the section list
        source.txt           Full source text (human-readable mirror)
        translation.txt      Concatenated section translations (mirror)
        audio/
            section_0000.wav
            section_0001.wav
            ...
        metadata/            Reserved for future use (created empty)

`sections` in project.json is the source of truth for translated text
and per-section audio; source.txt/translation.txt are convenience
mirrors for anyone who wants to glance at the project outside this app.
"""
from __future__ import annotations

import json
import logging
import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

from tts_studio.core.exceptions import CorruptedProjectError
from tts_studio.core.models import Project, TextSection

logger = logging.getLogger(__name__)

PROJECT_FILE_NAME = "project.json"
SCHEMA_VERSION = 1

# Matches the tempfile.mkstemp(prefix=...) values used by the TTS engine
# adapters and SectionsSynthesisWorker for not-yet-saved section audio.
_OUR_TEMP_PREFIXES = (
    "ttsstudio_piper_", "ttsstudio_kokoro_", "ttsstudio_chatterbox_", "ttsstudio_section_",
)


def is_scratch_temp_file(path: Path) -> bool:
    """True only for one of this app's own scratch temp WAVs -- i.e. a
    file sitting directly in the OS temp directory whose name starts with
    one of our known synthesize()-output prefixes. Deliberately narrow:
    a file inside any project's own audio/ folder (including one being
    re-copied by "Save Project As") must never match this."""
    try:
        same_dir = path.resolve().parent == Path(tempfile.gettempdir()).resolve()
    except OSError:
        return False
    return same_dir and path.name.startswith(_OUR_TEMP_PREFIXES)


class ProjectManager:
    def save(self, project: Project, project_dir: Path) -> Project:
        project_dir = Path(project_dir)
        audio_dir = project_dir / "audio"
        metadata_dir = project_dir / "metadata"
        audio_dir.mkdir(parents=True, exist_ok=True)
        metadata_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now(timezone.utc).isoformat()
        project.project_dir = project_dir
        project.name = project.name or project_dir.name
        project.created_at = project.created_at or now
        project.modified_at = now

        (project_dir / "source.txt").write_text(project.source_text, encoding="utf-8")
        translation_text = "\n\n".join(s.translated_text for s in project.sections if s.translated_text)
        (project_dir / "translation.txt").write_text(translation_text, encoding="utf-8")

        sections_payload = []
        for section in project.sections:
            audio_rel = None
            if section.audio_path and Path(section.audio_path).exists():
                dest = audio_dir / f"section_{section.index:04d}.wav"
                source = Path(section.audio_path)
                if source.resolve() != dest.resolve():
                    shutil.copyfile(source, dest)
                    # Only remove the original if it was one of THIS app's
                    # own scratch temp files (from synthesize(), sitting in
                    # the OS temp dir with our naming prefix) -- never a
                    # file living inside a project folder. "Save Project
                    # As" re-copies an *already-saved* project's audio into
                    # a new directory via this same code path, and that
                    # source file (still the original project's asset)
                    # must survive the copy.
                    if is_scratch_temp_file(source):
                        try:
                            source.unlink()
                        except OSError:
                            pass
                section.audio_path = dest
                audio_rel = str(dest.relative_to(project_dir))
            sections_payload.append(
                {
                    "id": section.id,
                    "index": section.index,
                    "source_text": section.source_text,
                    "is_heading": section.is_heading,
                    "translated_text": section.translated_text,
                    "audio_path": audio_rel,
                    "status": section.status,
                    "error_message": section.error_message,
                }
            )

        payload = {
            "schema_version": SCHEMA_VERSION,
            "name": project.name,
            "created_at": project.created_at,
            "modified_at": project.modified_at,
            "source_language": project.source_language,
            "target_language": project.target_language,
            "translation_engine": project.translation_engine,
            "tts_engine": project.tts_engine,
            "tts_voice_id": project.tts_voice_id,
            "speed": project.speed,
            "volume": project.volume,
            "pitch_semitones": project.pitch_semitones,
            "character_preset": project.character_preset,
            "tts_reference_audio_path": project.tts_reference_audio_path,
            "tts_exaggeration": project.tts_exaggeration,
            "tts_cfg_weight": project.tts_cfg_weight,
            "tts_temperature": project.tts_temperature,
            "tts_repetition_penalty": project.tts_repetition_penalty,
            "tts_min_p": project.tts_min_p,
            "tts_top_p": project.tts_top_p,
            "tts_top_k": project.tts_top_k,
            "normalize_output": project.normalize_output,
            "output_format": project.output_format,
            "chunk_mode": project.chunk_mode,
            "max_chunk_chars": project.max_chunk_chars,
            "sections": sections_payload,
        }
        try:
            (project_dir / PROJECT_FILE_NAME).write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except OSError as exc:
            raise CorruptedProjectError(f"Couldn't write project.json: {exc}") from exc

        return project

    def load(self, project_dir: Path) -> Project:
        project_dir = Path(project_dir)
        project_file = project_dir / PROJECT_FILE_NAME
        if not project_file.exists():
            raise CorruptedProjectError(f"No {PROJECT_FILE_NAME} found in {project_dir}")

        try:
            payload = json.loads(project_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CorruptedProjectError(str(exc)) from exc

        try:
            sections = []
            for s in payload.get("sections", []):
                audio_path = project_dir / s["audio_path"] if s.get("audio_path") else None
                sections.append(
                    TextSection(
                        index=s["index"],
                        source_text=s["source_text"],
                        id=s.get("id") or uuid.uuid4().hex[:8],
                        is_heading=s.get("is_heading", False),
                        translated_text=s.get("translated_text"),
                        audio_path=audio_path,
                        status=s.get("status", "pending"),
                        error_message=s.get("error_message"),
                    )
                )

            source_text_path = project_dir / "source.txt"
            source_text = source_text_path.read_text(encoding="utf-8") if source_text_path.exists() else ""

            return Project(
                source_text=source_text,
                source_language=payload.get("source_language"),
                target_language=payload.get("target_language"),
                translation_engine=payload.get("translation_engine"),
                tts_engine=payload.get("tts_engine"),
                tts_voice_id=payload.get("tts_voice_id"),
                speed=payload.get("speed", 1.0),
                volume=payload.get("volume", 1.0),
                pitch_semitones=payload.get("pitch_semitones", 0.0),
                character_preset=payload.get("character_preset", "neutral"),
                tts_reference_audio_path=payload.get("tts_reference_audio_path"),
                tts_exaggeration=payload.get("tts_exaggeration", 0.5),
                tts_cfg_weight=payload.get("tts_cfg_weight", 0.5),
                tts_temperature=payload.get("tts_temperature", 0.8),
                tts_repetition_penalty=payload.get("tts_repetition_penalty", 1.2),
                tts_min_p=payload.get("tts_min_p", 0.05),
                tts_top_p=payload.get("tts_top_p", 1.0),
                tts_top_k=payload.get("tts_top_k", 1000),
                normalize_output=payload.get("normalize_output", False),
                output_format=payload.get("output_format", "wav"),
                chunk_mode=payload.get("chunk_mode", "automatic"),
                max_chunk_chars=payload.get("max_chunk_chars", 500),
                sections=sections,
                name=payload.get("name", project_dir.name),
                project_dir=project_dir,
                created_at=payload.get("created_at"),
                modified_at=payload.get("modified_at"),
            )
        except KeyError as exc:
            raise CorruptedProjectError(f"Missing required field: {exc}") from exc
