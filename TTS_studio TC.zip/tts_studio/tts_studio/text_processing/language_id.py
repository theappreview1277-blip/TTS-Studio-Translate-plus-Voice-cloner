"""
Offline source-language detection.

Uses `lingua` (pemistahl/lingua-py, Apache-2.0, actively maintained,
75 languages, no network/model download, good accuracy even on short
text) rather than Argos Translate itself, which does not do language
identification. Kept in text_processing/ rather than inside the Argos
adapter so any translation engine can reuse it.
"""
from __future__ import annotations

import logging
from functools import lru_cache

from tts_studio.core.exceptions import LanguageDetectionError
from tts_studio.core.models import LanguageDetectionResult

logger = logging.getLogger(__name__)

# Maps lingua's Language enum names to the BCP-47-ish codes used
# elsewhere in the app (matching what Argos Translate expects).
_LINGUA_TO_BCP47 = {
    "ENGLISH": "en", "FRENCH": "fr", "GERMAN": "de", "SPANISH": "es",
    "ITALIAN": "it", "PORTUGUESE": "pt", "RUSSIAN": "ru", "CHINESE": "zh",
    "JAPANESE": "ja", "KOREAN": "ko", "ARABIC": "ar", "HINDI": "hi",
    "DUTCH": "nl", "POLISH": "pl", "TURKISH": "tr", "SWEDISH": "sv",
    "DANISH": "da", "FINNISH": "fi", "NORWEGIAN": "nb", "GREEK": "el",
    "CZECH": "cs", "ROMANIAN": "ro", "HUNGARIAN": "hu", "UKRAINIAN": "uk",
    "HEBREW": "he", "INDONESIAN": "id", "VIETNAMESE": "vi", "THAI": "th",
}


@lru_cache(maxsize=1)
def _get_detector():
    try:
        from lingua import Language, LanguageDetectorBuilder
    except ImportError as exc:
        raise LanguageDetectionError(
            "lingua-language-detector isn't installed (pip install lingua-language-detector)."
        ) from exc

    languages = [
        getattr(Language, name) for name in _LINGUA_TO_BCP47 if hasattr(Language, name)
    ]
    return LanguageDetectorBuilder.from_languages(*languages).build()


def detect_language(text: str) -> LanguageDetectionResult:
    if not text or not text.strip():
        raise LanguageDetectionError("There's no text to detect a language from.")

    detector = _get_detector()
    confidence_values = detector.compute_language_confidence_values(text)
    if not confidence_values:
        raise LanguageDetectionError("Couldn't identify the language of this text.")

    top = confidence_values[0]
    code = _LINGUA_TO_BCP47.get(top.language.name, top.language.name.lower())
    return LanguageDetectionResult(language_code=code, confidence=top.value)
