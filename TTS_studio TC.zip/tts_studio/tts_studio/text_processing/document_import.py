"""
Document import.

V1 only opened plain .txt files. V2 adds .docx and .pdf:

- **.docx** via `python-docx` (MIT license, pure Python, actively
  maintained). We read `document.paragraphs` and use each paragraph's
  style name (e.g. "Heading 1", "Title") to mark headings -- these
  come through as their own blank-line-separated paragraph, so
  TextChunker's heading heuristic (and the "Heading 1" style
  information itself, which we could wire through more precisely
  later) has something to work with immediately.

- **.pdf** via `pypdf` (BSD-3-Clause, pure Python, actively
  maintained). Note: PyPDF2 -- which a lot of older tutorials still
  reference -- was deprecated by its own maintainer back into `pypdf`
  under one project; don't add PyPDF2 as a dependency, it's the same
  code at an older snapshot. `pypdf` extracts text well from
  born-digital PDFs; it does **not** OCR scanned/image-only PDFs --
  that would need a library like `pytesseract` plus a Tesseract
  install, which is a reasonable V3+ addition, not V2.
"""
from __future__ import annotations

import logging
from pathlib import Path

from tts_studio.core.exceptions import DocumentImportError

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".txt", ".md", ".docx", ".pdf"}
FILE_DIALOG_FILTER = "Documents (*.txt *.md *.docx *.pdf);;All files (*)"

# python-docx paragraph style names that should be treated as headings
# and kept as their own short paragraph rather than merged with body text.
_HEADING_STYLE_PREFIXES = ("Heading", "Title", "Subtitle")


def import_document(path: Path) -> str:
    """Return the plain text content of a supported document."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".txt", ".md"):
        return _import_plain_text(path)
    if ext == ".docx":
        return _import_docx(path)
    if ext == ".pdf":
        return _import_pdf(path)
    raise DocumentImportError(
        f"Unsupported file type '{ext}'. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
    )


def _import_plain_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise DocumentImportError(str(exc)) from exc


def _import_docx(path: Path) -> str:
    try:
        import docx
    except ImportError as exc:
        raise DocumentImportError(
            "python-docx isn't installed (pip install python-docx)."
        ) from exc

    try:
        document = docx.Document(str(path))
    except Exception as exc:  # noqa: BLE001 - python-docx raises several types for bad files
        raise DocumentImportError(str(exc)) from exc

    paragraphs: list[str] = []
    for para in document.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        paragraphs.append(text)  # heading vs. body distinction handled by
        # TextChunker's own heuristic downstream; style name is available
        # via para.style.name if a future version wants to use it directly
        # instead of re-deriving "looks like a heading" from the text.

    if not paragraphs:
        raise DocumentImportError("No readable text found in that document.")
    return "\n\n".join(paragraphs)


def _import_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise DocumentImportError("pypdf isn't installed (pip install pypdf).") from exc

    try:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            try:
                reader.decrypt("")  # try an empty password before giving up
            except Exception:  # noqa: BLE001
                raise DocumentImportError(
                    "This PDF is password-protected. Remove the password and try again."
                )
        pages_text = [page.extract_text() or "" for page in reader.pages]
    except DocumentImportError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise DocumentImportError(str(exc)) from exc

    text = "\n\n".join(t.strip() for t in pages_text if t.strip())
    if not text:
        raise DocumentImportError(
            "No extractable text found -- this may be a scanned/image-only PDF, "
            "which needs OCR (not supported yet)."
        )
    return text
