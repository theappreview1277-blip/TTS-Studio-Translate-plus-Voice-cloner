"""
Text chunking: paragraph, sentence, automatic, and custom-length modes.

Design note -- why this is hand-written instead of a dependency:
We evaluated pysbd (nipunsadvilkar/pySBD), the usual go-to for
sentence-boundary detection in Python. As of the research for this
project pysbd is effectively unmaintained (an open issue from
December 2025 asks the maintainer to archive it) and has a known,
unresolved catastrophic-backtracking regex bug
(`NUMBERED_REFERENCE_REGEX`) that can hang indefinitely on certain
input. That is not an acceptable risk for a tool whose whole job is
processing arbitrary, sometimes very long, user-supplied documents.
A small rule-based splitter gives us the exact behaviours this app
needs (headings, dialogue-aware quotes, a tunable abbreviation list)
with zero extra runtime dependency and no ReDoS surface. It won't be
linguistically perfect on every edge case; it is fast, predictable,
and easy to extend.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache

from tts_studio.core.models import TextSection

# Abbreviations after which a period should NOT be treated as a sentence
# boundary. Deliberately conservative and English-centric for V1; this is
# the natural place to add per-language lists in V2+.
#
# Note some entries are compound ("e.g", "i.e", "u.s", "u.k") and contain
# an internal period of their own -- see _protect_abbreviations below for
# why that requires matching the whole abbreviation at once rather than
# scanning one letter-run-plus-period at a time.
DEFAULT_ABBREVIATIONS = {
    "mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "mt", "ft",
    "vs", "etc", "e.g", "i.e", "u.s", "u.k", "no", "vol", "op", "cf",
    "approx", "apt", "dept", "est", "min", "max", "misc",
}

_ABBREV_PLACEHOLDER = "\u0000"  # never appears in normal text; safe temp marker

# Matches one sentence at a time: everything up to and including a run of
# terminal punctuation plus any closing quotes/brackets, OR (for text with
# no trailing punctuation) whatever is left to the end of the string. Using
# finditer to *capture* sentences, rather than re.split to remove
# delimiters, is what keeps a trailing closing quote (`he said "hi."`)
# attached to the sentence it belongs to instead of being eaten as part of
# the split delimiter.
_SENTENCE_RE = re.compile(r'[^.!?]*[.!?]+[\'"\)\]]*|[^.!?]+\Z')
_PARAGRAPH_SPLIT_RE = re.compile(r'\n\s*\n+')


class ChunkMode(str, Enum):
    SENTENCE = "sentence"
    PARAGRAPH = "paragraph"
    AUTOMATIC = "automatic"
    CUSTOM = "custom"


@lru_cache(maxsize=16)
def _abbreviation_pattern(abbreviations: frozenset[str]) -> re.Pattern:
    """One alternation matching each abbreviation *in full*, including any
    internal period ("u.s" -> literal "u.s"), followed by its closing
    period -- e.g. r"\\bu\\.s\\." for "u.s" -- so "U.S." is matched (and
    protected) as a single unit instead of as two independent
    letter-run-plus-period tokens.

    This replaces an earlier version that scanned `\\b([A-Za-z]+\\.)` one
    letter-run at a time: that approach could only ever see "U." and "S."
    separately, so it could never recognize a compound entry like "u.s" at
    all -- "U.S." (and "e.g.", "i.e.", "U.K.") were silently left
    unprotected and split into nonsense fragments ("U.", "S.", ...).
    Matching the whole abbreviation (including its internal period) as one
    alternative fixes that for both simple ("mr" -> "Mr.") and compound
    abbreviations alike.
    """
    # Longest-first so a compound abbreviation is never shadowed by a
    # shorter one that happens to be a prefix of it.
    ordered = sorted(abbreviations, key=len, reverse=True)
    alternation = "|".join(re.escape(a) for a in ordered)
    return re.compile(rf"\b(?:{alternation})\.", re.IGNORECASE)


def _protect_abbreviations(text: str, abbreviations: set[str]) -> str:
    pattern = _abbreviation_pattern(frozenset(abbreviations))
    # Replace every period *within* the matched span (there may be more
    # than one, for a compound abbreviation like "u.s.") with the
    # placeholder, leaving the letters untouched.
    return pattern.sub(lambda m: m.group(0).replace(".", _ABBREV_PLACEHOLDER), text)


def _restore_abbreviations(text: str) -> str:
    return text.replace(_ABBREV_PLACEHOLDER, ".")


def _protect_decimals(text: str) -> str:
    """So '3.14' or 'Version 2.5' isn't split into two sentences."""
    return re.sub(r"(?<=\d)\.(?=\d)", _ABBREV_PLACEHOLDER, text)


def looks_like_heading(paragraph: str) -> bool:
    """Heuristic: short line, no terminal sentence punctuation, single line."""
    stripped = paragraph.strip()
    if not stripped or "\n" in stripped:
        return False
    if len(stripped) > 80:
        return False
    if stripped[-1] in ".!?":
        return False
    word_count = len(stripped.split())
    return word_count <= 12


def split_paragraphs(text: str) -> list[str]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    paragraphs = [p.strip() for p in _PARAGRAPH_SPLIT_RE.split(normalized)]
    return [p for p in paragraphs if p]


def split_sentences(text: str, abbreviations: set[str] | None = None) -> list[str]:
    abbreviations = abbreviations or DEFAULT_ABBREVIATIONS
    protected = _protect_abbreviations(text.strip(), abbreviations)
    # Also protect single-letter initials like "J. R. R. Tolkien"
    protected = re.sub(
        r"\b([A-Z])\.(?=\s+[A-Z])",
        lambda m: m.group(1) + _ABBREV_PLACEHOLDER,
        protected,
    )
    protected = _protect_decimals(protected)

    sentences = []
    for match in _SENTENCE_RE.finditer(protected):
        piece = _restore_abbreviations(match.group()).strip()
        if piece:
            sentences.append(piece)
    return sentences


@dataclass
class ChunkerOptions:
    mode: ChunkMode = ChunkMode.AUTOMATIC
    max_chunk_chars: int = 500  # used by AUTOMATIC and CUSTOM modes
    abbreviations: set[str] | None = None


class TextChunker:
    """Splits raw text into TextSection objects ready for translation/TTS."""

    def chunk(self, text: str, options: ChunkerOptions | None = None) -> list[TextSection]:
        options = options or ChunkerOptions()
        if not text or not text.strip():
            return []

        if options.mode == ChunkMode.SENTENCE:
            pieces = self._chunk_sentence(text, options)
        elif options.mode == ChunkMode.PARAGRAPH:
            pieces = self._chunk_paragraph(text, options)
        elif options.mode == ChunkMode.CUSTOM:
            pieces = self._chunk_custom(text, options)
        else:
            pieces = self._chunk_automatic(text, options)

        return [
            TextSection(index=i, source_text=body, is_heading=is_heading)
            for i, (body, is_heading) in enumerate(pieces)
        ]

    # -- mode implementations --------------------------------------------
    def _chunk_sentence(self, text: str, options: ChunkerOptions) -> list[tuple[str, bool]]:
        result: list[tuple[str, bool]] = []
        for paragraph in split_paragraphs(text):
            if looks_like_heading(paragraph):
                result.append((paragraph, True))
                continue
            for sentence in split_sentences(paragraph, options.abbreviations):
                result.append((sentence, False))
        return result

    def _chunk_paragraph(self, text: str, options: ChunkerOptions) -> list[tuple[str, bool]]:
        result: list[tuple[str, bool]] = []
        for paragraph in split_paragraphs(text):
            is_heading = looks_like_heading(paragraph)
            if is_heading or len(paragraph) <= options.max_chunk_chars:
                result.append((paragraph, is_heading))
            else:
                # Guard: an oversized paragraph still gets packed into
                # TTS-safe pieces instead of being sent as one giant chunk.
                result.extend(self._pack_sentences(paragraph, options))
        return result

    def _chunk_automatic(self, text: str, options: ChunkerOptions) -> list[tuple[str, bool]]:
        result: list[tuple[str, bool]] = []
        for paragraph in split_paragraphs(text):
            if looks_like_heading(paragraph):
                result.append((paragraph, True))
                continue
            result.extend(self._pack_sentences(paragraph, options))
        return result

    def _chunk_custom(self, text: str, options: ChunkerOptions) -> list[tuple[str, bool]]:
        # Same packing logic as automatic, but ignores paragraph/heading
        # detection entirely and just fills to max_chunk_chars, preferring
        # to break on a sentence boundary when one is available nearby.
        sentences = split_sentences(text, options.abbreviations)
        return self._pack(sentences, options.max_chunk_chars)

    # -- shared helpers -----------------------------------------------------
    def _pack_sentences(self, paragraph: str, options: ChunkerOptions) -> list[tuple[str, bool]]:
        sentences = split_sentences(paragraph, options.abbreviations)
        return self._pack(sentences, options.max_chunk_chars)

    def _pack(self, sentences: list[str], max_chars: int) -> list[tuple[str, bool]]:
        chunks: list[tuple[str, bool]] = []
        current: list[str] = []
        current_len = 0
        for sentence in sentences:
            extra = len(sentence) + (1 if current else 0)
            if current and current_len + extra > max_chars:
                chunks.append((" ".join(current), False))
                current, current_len = [], 0
            if len(sentence) > max_chars:
                # A single sentence longer than the limit: emit it on its
                # own rather than dropping/mangling text. Real-world text
                # rarely hits this except with degenerate input.
                if current:
                    chunks.append((" ".join(current), False))
                    current, current_len = [], 0
                chunks.append((sentence, False))
                continue
            current.append(sentence)
            current_len += extra
        if current:
            chunks.append((" ".join(current), False))
        return chunks
