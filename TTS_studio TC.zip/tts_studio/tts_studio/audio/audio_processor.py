"""
Audio processing, kept completely independent of any TTS engine.

Engines only ever hand back a path to a WAV file (see
core.models.SynthesisResult) -- everything downstream (joining
sections, normalising, exporting) goes through this module.

V2 export format routing, and why it's split the way it is:

- **WAV, FLAC** go through `soundfile`/libsndfile directly. Both are
  solid there.
- **MP3, OGG** both go through an FFmpeg subprocess instead.  MP3
  needs FFmpeg regardless (libsndfile doesn't encode MP3 at all). OGG
  *can* technically be written by soundfile, but its libsndfile-based
  OGG/Vorbis writer has real, currently-open reliability problems --
  known reports of silently-empty output files on some libsndfile
  versions, and a reproducible crash (exit code 0xC00000FD) writing
  OGG on Windows (libsndfile/libsndfile#1093). FFmpeg's libvorbis
  encoder is far more battle-tested, so OGG is routed through the same
  FFmpeg path as MP3 rather than risking a silent bad export.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import soundfile as sf

from tts_studio.core.exceptions import AudioExportError, FFmpegNotFoundError, InvalidOutputLocationError

logger = logging.getLogger(__name__)

SOUNDFILE_FORMATS = {"wav", "flac"}
FFMPEG_FORMATS = {"mp3", "ogg"}
SUPPORTED_FORMATS = SOUNDFILE_FORMATS | FFMPEG_FORMATS


class AudioProcessor:
    def load(self, path: Path) -> tuple[np.ndarray, int]:
        samples, sample_rate = sf.read(str(path), dtype="float32", always_2d=False)
        return samples, sample_rate

    def join(
        self,
        clips: list[tuple[np.ndarray, int]],
        gap_seconds: float = 0.35,
    ) -> tuple[np.ndarray, int]:
        """Concatenate clips with a short silence gap between them.

        All clips are expected to share a sample rate (true for every
        section rendered by the same engine+voice in one run); a clip
        at a different rate is resampled with a simple linear
        interpolation rather than dropped, so a mixed-engine project
        still joins cleanly.
        """
        if not clips:
            return np.zeros(0, dtype=np.float32), 0

        target_rate = clips[0][1]
        pieces: list[np.ndarray] = []
        gap = np.zeros(int(target_rate * gap_seconds), dtype=np.float32)

        for i, (samples, rate) in enumerate(clips):
            if rate != target_rate:
                samples = _resample_linear(samples, rate, target_rate)
            if i > 0:
                pieces.append(gap)
            pieces.append(samples.astype(np.float32, copy=False))

        return np.concatenate(pieces), target_rate

    def normalize_peak(self, samples: np.ndarray, target_peak: float = 0.98) -> np.ndarray:
        """V4 follow-up #2: scales `samples` so its loudest sample sits at
        `target_peak` (just under full scale, to leave a little headroom
        rather than risk 0 dBFS clipping on re-encode), the same simple
        peak normalization idea as the "Normalise final audio" checkbox
        in OutputPanel. Deliberately peak-based, not loudness/LUFS-based
        -- a full loudness-normalization implementation is a much bigger
        piece of DSP than this app needs for "make sections generated at
        different volumes roughly match", and peak normalization is
        honest about what it's actually doing (matching the loudest
        sample, not perceived loudness). A silent clip (peak of exactly
        0) is returned unchanged rather than raising or dividing by zero
        -- there's nothing to normalize against."""
        if samples.size == 0:
            return samples
        peak = float(np.max(np.abs(samples)))
        if peak == 0.0:
            return samples
        return np.clip(samples * (target_peak / peak), -1.0, 1.0).astype(np.float32, copy=False)

    def export_wav(self, samples: np.ndarray, sample_rate: int, output_path: Path) -> Path:
        return self._export_via_soundfile(samples, sample_rate, output_path, "WAV", "PCM_16")

    def export_flac(self, samples: np.ndarray, sample_rate: int, output_path: Path) -> Path:
        return self._export_via_soundfile(samples, sample_rate, output_path, "FLAC", "PCM_16")

    def export_mp3(self, samples: np.ndarray, sample_rate: int, output_path: Path, bitrate_kbps: int = 192) -> Path:
        return self._export_via_ffmpeg(
            samples, sample_rate, output_path, ["-codec:a", "libmp3lame", "-b:a", f"{bitrate_kbps}k"]
        )

    def export_ogg(self, samples: np.ndarray, sample_rate: int, output_path: Path, quality: float = 5.0) -> Path:
        return self._export_via_ffmpeg(
            samples, sample_rate, output_path, ["-codec:a", "libvorbis", "-qscale:a", str(quality)]
        )

    def export(self, samples: np.ndarray, sample_rate: int, output_path: Path, fmt: str) -> Path:
        fmt = fmt.lower().lstrip(".")
        exporters = {
            "wav": self.export_wav,
            "flac": self.export_flac,
            "mp3": self.export_mp3,
            "ogg": self.export_ogg,
        }
        if fmt not in exporters:
            raise AudioExportError(
                f"Unsupported export format: '{fmt}'. Supported: {', '.join(sorted(SUPPORTED_FORMATS))}"
            )
        return exporters[fmt](samples, sample_rate, output_path)

    # -- internals -------------------------------------------------------
    def _export_via_soundfile(
        self, samples: np.ndarray, sample_rate: int, output_path: Path, sf_format: str, subtype: str
    ) -> Path:
        output_path = Path(output_path)
        self._ensure_writable(output_path)
        try:
            sf.write(str(output_path), samples, sample_rate, format=sf_format, subtype=subtype)
        except Exception as exc:  # noqa: BLE001
            raise AudioExportError(str(exc)) from exc
        return output_path

    def _export_via_ffmpeg(
        self, samples: np.ndarray, sample_rate: int, output_path: Path, codec_args: list[str]
    ) -> Path:
        output_path = Path(output_path)
        self._ensure_writable(output_path)
        if shutil.which("ffmpeg") is None:
            raise FFmpegNotFoundError()

        fd, tmp_wav_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_export_")
        os.close(fd)
        tmp_wav = Path(tmp_wav_str)
        try:
            sf.write(str(tmp_wav), samples, sample_rate, subtype="PCM_16")
            cmd = ["ffmpeg", "-y", "-i", str(tmp_wav), *codec_args, str(output_path)]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result.returncode != 0 or not output_path.exists():
                raise AudioExportError(result.stderr.strip()[-800:] or "ffmpeg exited without producing output.")
        finally:
            tmp_wav.unlink(missing_ok=True)
        return output_path

    @staticmethod
    def _ensure_writable(output_path: Path) -> None:
        parent = output_path.parent
        if not parent.exists() or not _dir_writable(parent):
            raise InvalidOutputLocationError(str(output_path))


def _dir_writable(path: Path) -> bool:
    import os

    return os.access(path, os.W_OK)


def _resample_linear(samples: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    if src_rate == dst_rate or len(samples) == 0:
        return samples
    duration = len(samples) / src_rate
    dst_len = max(int(round(duration * dst_rate)), 1)
    src_x = np.linspace(0.0, duration, num=len(samples), endpoint=False)
    dst_x = np.linspace(0.0, duration, num=dst_len, endpoint=False)
    return np.interp(dst_x, src_x, samples).astype(np.float32)
