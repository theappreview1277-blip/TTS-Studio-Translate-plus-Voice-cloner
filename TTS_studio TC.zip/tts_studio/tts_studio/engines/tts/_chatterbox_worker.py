"""
Chatterbox synthesis worker -- runs INSIDE the isolated `.venv-chatterbox`
environment, never imported by the main app's own process.

Why this file exists at all (see `chatterbox_engine.py`'s module
docstring for the full story): `chatterbox-tts` pins `numpy<2.0.0`,
which directly conflicts with `kokoro-onnx`'s `numpy>=2.0.2` requirement
in the main app's `.venv` -- there is no numpy version that satisfies
both, so Chatterbox cannot be imported in-process there. Instead it gets
its own environment, and `chatterbox_engine.py` runs this script as a
subprocess using *that* environment's `python.exe` -- structurally the
same isolation mechanism `piper_engine.py` already uses for a different
reason (GPL-3.0 licensing, not a dependency conflict).

**Persistent process, JSON-lines protocol** (rewritten from an earlier,
real design mistake): this used to be started fresh, do one
synthesize(), and exit -- for every section, and again for every
sub-chunk of a long section, which meant reloading the full model from
disk every single time. On CPU that's minutes of dead time per section
on top of the actual generation. Caught in review before more people hit
it: `chatterbox_engine.py` now starts this script ONCE and keeps it
alive for as long as Chatterbox stays selected, sending it one JSON
object per line on stdin and reading one JSON object per line back from
stdout, for as many `synthesize` calls as the session needs. The model
loads once per (tier, device) combination and stays resident in memory
between calls (see `_load_model`'s cache) instead of being rebuilt from
scratch every time.

**Reference-conditional caching** (a V4 follow-up, verified directly
against chatterbox's own `tts.py`/`tts_turbo.py` source): both
`ChatterboxTTS.generate()` and `ChatterboxTurboTTS.generate()` only call
the expensive `prepare_conditionals()` step (loads the reference wav via
librosa, resamples it, runs the voice encoder over it) when
`audio_prompt_path` is passed; otherwise they just reuse whatever
`self.conds` already holds, asserting it isn't `None`. Earlier versions
of this app passed `reference_audio_path` through to `audio_prompt_path`
on every single `synthesize()` call, which meant redoing that work for
every section of a project synthesized with the same cloned voice --
wasted, since the reference clip is normally the same for a whole
project. `_sync_reference_conditionals()` below tracks which reference
path (if any) is already reflected in the currently-loaded model's
`self.conds`, and skips passing `audio_prompt_path` again when this
call's reference matches -- `generate()` then reuses the already-
prepared conditionals for free. Fixed as a real side effect of this
change, not a separate one: previously, clicking "Clear" in the GUI to
go back to a tier's built-in voice after having used a custom reference
clip earlier in the same session did NOT actually revert anything --
omitting `audio_prompt_path` just reuses `self.conds` as-is, which was
still the last custom clone's conditionals, so the built-in voice was
silently never heard again until the persistent worker restarted or the
tier changed. `_load_model()` now stashes each freshly-loaded model's
own default `self.conds` (from its `conds.pt`, loaded during
`from_pretrained()`) the moment it's constructed, and
`_sync_reference_conditionals()` restores it explicitly -- a cheap
attribute assignment, not a re-run of `prepare_conditionals()` -- when a
request asks for "no reference" after a custom one was previously
prepared.

Wire protocol (newline-delimited JSON both directions):
  -> {"cmd": "synthesize", "id": <int>, "text": str, "output_path": str,
      "reference_audio_path": str | null, "voice_id": "nano"|"turbo"|"original"}
  <- {"id": <int>, "ok": true}                      -- WAV written to output_path
  <- {"id": <int>, "ok": false, "error": "<message + traceback>"}
  -> {"cmd": "shutdown"} -> {"id": null, "ok": true}, then the process exits.

Two other one-shot CLI modes, neither of which enters the loop above:
  `python _chatterbox_worker.py --diagnose`       -- see `_diagnose()`.
  `python _chatterbox_worker.py --download-only`  -- see `_download_all_tiers()`;
      fetches model weights via the same hf_hub_download/snapshot_download
      calls `from_pretrained()` uses internally, WITHOUT constructing the
      model (no `from_local()`, no `ChatterboxTTS(...)`/`ChatterboxTurboTTS(...)`)
      -- used by windows_install.ps1's pre-warm step so installing doesn't
      also allocate a full model in RAM (which made the installer look
      hung on a modest machine; see chatterbox_engine.py's module
      docstring and ARCHITECTURE.md section I).

**Why stdout is seized at the OS file-descriptor level before the loop
starts** (`_take_over_stdout`): stdout IS the response channel back to
chatterbox_engine.py. Torch, Hugging Face Hub, tqdm, or Chatterbox
itself printing so much as one stray line to stdout (progress output,
a notice, anything) during model loading or generation would corrupt
the JSON-lines protocol and take down every request for the rest of
this process's life, not just one. Redirecting at the raw file
descriptor (not just reassigning the `sys.stdout` Python object) covers
output from C extensions too, not only well-behaved `print()` calls.

**CPU-deserialization crash, patched defensively** (resemble-ai/
chatterbox issue #96, confirmed against the issue thread while debugging
a real failure report against this app): older chatterbox-tts releases
call `torch.load()` on the model checkpoint with no `map_location`,
which raises `RuntimeError: Attempting to deserialize object on a CUDA
device but torch.cuda.is_available() is False` on any machine with no
NVIDIA GPU -- most Windows PCs. `_patch_torch_load_for_cpu_safety` below
forces a CPU mapping only when there's no CUDA device to map to in the
first place; a no-op on a real GPU machine or an already-fixed
chatterbox-tts release.

**"TypeError: 'NoneType' object is not callable" on
`perth.PerthImplicitWatermarker()`** (resemble-ai/chatterbox issue #198,
resemble-ai/Perth issue #7, also confirmed against a real crash report
against this app): `perth` needs `pkg_resources` (from `setuptools`, not
the standard library) at its own import time, and silently sets
`PerthImplicitWatermarker = None` instead of raising when it's missing.
`pkg_resources` goes missing two different ways, and an earlier round of
this project only understood the first one:

1. Python's `venv` module stopped auto-installing setuptools into new
   virtual environments as of Python 3.12 -- easy to hit if
   `.venv-chatterbox` ends up on 3.12. `windows_install.ps1` now targets
   Python 3.11 for `.venv-chatterbox` specifically (upstream's own
   tested version, whose `venv` module still bundles setuptools) to
   avoid this outright, with a non-fatal fallback to whatever Python
   built the main `.venv` if 3.11 isn't available.
2. setuptools itself removed `pkg_resources` outright in v82.0.0
   (setuptools's own changelog, "Deprecations and Removals" for that
   release) -- so even on Python 3.11, or after (1) is fixed, installing
   setuptools with no version pin (or `--upgrade`ing it) can pull 82+
   and land on the exact same crash, freshly reintroduced. This is not
   hypothetical -- an earlier round of `windows_install.ps1` and
   `Run TTS Studio.cmd` did exactly that (unpinned/`--upgrade`d
   setuptools), so a previously-working install could silently break
   again the next time either ran. requirements-chatterbox.txt,
   windows_install.ps1, and Run TTS Studio.cmd all now pin an exact
   version below 82 for this reason -- see requirements-chatterbox.txt
   for which version and why.

Both are checked here too, explicitly, for whichever venv this script
ends up running in (a fallback-to-3.12 venv, one built before this fix,
or one where the pin above ever drifts). **This is a check ONLY -- it
does not run `pip install` here.** Reaching out to the network and
modifying this environment during a Generate click was flagged (rightly)
as its own problem: it makes speech generation silently depend on
having internet access, and can change the environment out from under
someone without warning. Installing (and correctly pinning) setuptools
is windows_install.ps1's and Run TTS Studio.cmd's job, before this
script ever runs; if it's still missing or still the wrong version when
this runs, the fix is to say so clearly and point at those, not to
silently try to fix it here too.

**Three model tiers** (see `chatterbox_engine.py`'s module docstring for
the full reasoning): "nano" and "turbo" both come from
`chatterbox.tts_turbo.ChatterboxTurboTTS.from_pretrained(device=...,
nano=True/False)` -- verified against upstream's README and its own
`example_tts_nano.py`, which agree with each other on that exact call
signature, though a direct source read of `tts_turbo.py` on GitHub's
`master` branch did NOT show a `nano` kwarg at all (a real, unresolved
discrepancy between upstream's docs/examples and at least one version of
its own source -- not a guess made up for this file). `_load_model`
below retries without `nano=` if passing it raises `TypeError`, so a
chatterbox-tts release that genuinely doesn't support it degrades to
plain Turbo instead of crashing. "original" is the base 500M-class
`chatterbox.tts.ChatterboxTTS` -- highest quality, slowest, the only
tier this app supported before this rewrite.
"""
from __future__ import annotations

import contextlib
import gc
import json
import os
import sys
import traceback

#: Cache of the one model tier currently loaded, if any -- deliberately
#: holds at most one model at a time (not one per tier) so switching
#: tiers mid-session can't quietly stack up multiple large models in
#: memory, which is exactly the kind of "consumes huge amounts of
#: memory" behaviour this rewrite exists to avoid.
#:
#: "default_conds"/"prepared_reference_audio_path" are the V4 follow-up
#: reference-conditional-caching fields -- see this module's own
#: docstring for the full rationale. "default_conds" is a direct
#: reference to the freshly-loaded model's own `self.conds` (its
#: built-in voice, from `conds.pt`), stashed once right after
#: construction so it can be restored later without re-running
#: `prepare_conditionals()`. "prepared_reference_audio_path" tracks
#: which reference clip path (None meaning "the built-in default") the
#: currently-loaded model's `self.conds` actually reflects right now.
_MODEL_CACHE: dict = {
    "voice_id": None,
    "device": None,
    "model": None,
    "default_conds": None,
    "prepared_reference_audio_path": None,
}


def _patch_torch_load_for_cpu_safety(torch_module, device: str) -> None:
    """Called once per _load_model() call, and _load_model() runs again
    every time the selected tier changes (nano -> turbo -> original,
    etc., in the same long-running persistent worker). Without the guard
    below, each tier switch would wrap `torch_module.load` in ANOTHER
    layer of `_cpu_safe_load` around the previous one -- still correct
    (each layer's `setdefault` is a harmless no-op once map_location is
    already set), just a pointlessly growing call stack that makes any
    future debugging of a real torch.load issue more confusing than it
    needs to be. The marker attribute makes this idempotent instead."""
    if device != "cpu":
        return
    if getattr(torch_module, "_tts_studio_cpu_load_patched", False):
        return
    real_load = torch_module.load

    def _cpu_safe_load(*args, **kwargs):
        kwargs.setdefault("map_location", torch_module.device("cpu"))
        return real_load(*args, **kwargs)

    torch_module.load = _cpu_safe_load
    torch_module._tts_studio_cpu_load_patched = True


def _check_pkg_resources_available() -> None:
    """Check-only (see module docstring point about not installing
    packages during synthesis) -- raises a clear repair instruction
    instead of silently reaching out to the network here."""
    try:
        import pkg_resources  # noqa: F401
    except ImportError as exc:
        raise RuntimeError(
            "Chatterbox needs the 'setuptools' package (a specific "
            "version below 82 -- see requirements-chatterbox.txt), which "
            "isn't correctly installed in .venv-chatterbox (a known "
            "upstream rough edge -- see this file's module docstring). "
            "Close TTS Studio completely and run 'Install TTS Studio.cmd' "
            "again -- it repairs this automatically, no command prompt "
            "needed. If it still fails after that, see README.md's "
            "'Voice cloning (Chatterbox)' section."
        ) from exc


def _check_perth_watermarker() -> None:
    """Raises a clear, specific RuntimeError instead of letting
    ChatterboxTTS.__init__ hit `perth.PerthImplicitWatermarker()` and
    blow up with a bare `TypeError: 'NoneType' object is not callable`."""
    import perth

    if getattr(perth, "PerthImplicitWatermarker", None) is None:
        raise RuntimeError(
            "perth.PerthImplicitWatermarker is None because 'setuptools' "
            "isn't correctly installed in .venv-chatterbox (perth needs "
            "it for pkg_resources, and silently disables itself instead "
            "of raising when it's missing -- either because it's absent, "
            "or because it's present but too new, v82 or later, which "
            "removed pkg_resources outright). Close TTS Studio completely "
            "and run 'Install TTS Studio.cmd' again -- it repairs the "
            "correct setuptools version automatically, no command prompt "
            "needed."
        )


def _release_cached_model(torch_module) -> None:
    """Explicitly drops whatever model is currently cached before a
    different one is constructed, rather than just overwriting the dict
    entries at the end of _load_model and trusting the garbage collector
    to get to the old one eventually. Real risk flagged in review:
    switching tiers mid-session (original -> turbo -> nano, or any other
    order) previously replaced `_MODEL_CACHE`'s references and left the
    OLD multi-hundred-MB-to-GB-class model reachable until some later,
    unpredictable GC cycle freed it -- on a memory-constrained machine,
    briefly holding two full models at once (the old one, not yet
    collected, plus the new one being constructed) is a realistic way to
    turn a tier switch into an out-of-memory failure that a prompt,
    explicit release would have avoided. Called BEFORE constructing the
    new model, not after, so peak memory is old-model-freed-then-new-
    model-built rather than both-at-once even briefly. `gc.collect()`
    forces the issue instead of waiting for Python to get around to it;
    `torch.cuda.empty_cache()` additionally hands freed CUDA memory back
    to the driver rather than just to torch's own allocator, and is
    always present on a real torch install (even a CPU-only one --
    `torch.cuda` exists either way, `is_available()` is just False)."""
    if _MODEL_CACHE["model"] is None:
        return
    _MODEL_CACHE["model"] = None
    _MODEL_CACHE["voice_id"] = None
    _MODEL_CACHE["device"] = None
    # Explicit, not just "the next _load_model() call will overwrite
    # these anyway" -- same "don't rely on an old reference lingering
    # reachable until the next assignment" reasoning as the three resets
    # above, and it means default_conds (a whole Conditionals object,
    # itself holding tensors) doesn't outlive the model it belongs to.
    _MODEL_CACHE["default_conds"] = None
    _MODEL_CACHE["prepared_reference_audio_path"] = None
    gc.collect()
    if torch_module.cuda.is_available():
        torch_module.cuda.empty_cache()


def _load_model(voice_id: str, device: str):
    """Loads (and caches) the model for the requested tier/device. A
    fast no-op if that exact combination is already loaded -- this is
    what makes the persistent-process design actually pay off: the
    expensive part only happens once per tier per worker lifetime."""
    if _MODEL_CACHE["voice_id"] == voice_id and _MODEL_CACHE["device"] == device:
        return _MODEL_CACHE["model"]

    _check_pkg_resources_available()

    import torch

    _patch_torch_load_for_cpu_safety(torch, device)
    _check_perth_watermarker()
    _release_cached_model(torch)

    if voice_id == "original":
        from chatterbox.tts import ChatterboxTTS

        model = ChatterboxTTS.from_pretrained(device=device)
    elif voice_id in ("nano", "turbo"):
        from chatterbox.tts_turbo import ChatterboxTurboTTS

        nano = voice_id == "nano"
        try:
            model = ChatterboxTurboTTS.from_pretrained(device=device, nano=nano)
        except TypeError as exc:
            if "nano" not in str(exc):
                raise
            print(
                f"Note: this chatterbox-tts version's "
                f"ChatterboxTurboTTS.from_pretrained() doesn't accept "
                f"nano= ({exc}); falling back to the standard Turbo "
                f"model instead of Nano.",
                file=sys.stderr,
            )
            model = ChatterboxTurboTTS.from_pretrained(device=device)
    else:
        raise ValueError(f"Unknown Chatterbox voice/model tier: {voice_id!r}")

    _MODEL_CACHE["voice_id"] = voice_id
    _MODEL_CACHE["device"] = device
    _MODEL_CACHE["model"] = model
    # See _sync_reference_conditionals() and this module's own docstring
    # ("Reference-conditional caching"): a freshly-constructed model's
    # self.conds is whatever from_pretrained() loaded from its own
    # conds.pt (its built-in voice), and no custom reference clip has
    # been prepared against THIS model instance yet, regardless of what
    # was prepared against whatever model was cached before it.
    _MODEL_CACHE["default_conds"] = model.conds
    _MODEL_CACHE["prepared_reference_audio_path"] = None
    return model


def _friendly_detail(exc: Exception) -> str:
    """A specific, actionable line in front of the raw traceback for the
    handful of failure modes real users are most likely to actually hit
    (found via the upstream issue tracker, not guessed)."""
    text = f"{type(exc).__name__}: {exc}"
    if "CUDA device" in text and "torch.cuda.is_available() is False" in text:
        return (
            "Chatterbox tried to load its model onto a GPU that isn't "
            "available on this machine, and the CPU-safety patch in this "
            "worker didn't catch it. Please report this -- the traceback "
            "below shows exactly where."
        )
    if "HFValidationError" in text or "huggingface_hub" in text.lower() or "Connection" in text:
        return (
            "Downloading Chatterbox's model from Hugging Face failed -- "
            "most likely a network problem (no internet connection right "
            "now, a firewall/proxy blocking huggingface.co, or the "
            "download was interrupted). Check your connection and try "
            "again; the traceback below has the specific error."
        )
    if "PerthImplicitWatermarker" in text or "'NoneType' object is not callable" in text:
        return (
            "This looks like the known perth/setuptools watermarker issue "
            "(see resemble-ai/chatterbox issue #198) -- close TTS Studio "
            "and run 'Install TTS Studio.cmd' again, it repairs the "
            "correct pinned 'setuptools' version automatically, no "
            "command prompt needed."
        )
    if isinstance(exc, (PermissionError, OSError)) and "reference" not in text.lower():
        return (
            "A file Chatterbox needed couldn't be read or written (disk "
            "full, permissions, or antivirus locking a file). See the "
            "traceback below for exactly which file."
        )
    return "Chatterbox failed with an unexpected error. Full details below:"


def _sampling_kwargs_for_tier(voice_id: str, request: dict) -> dict:
    """Picks out exactly the generate() keyword arguments the given tier's
    own signature actually defines -- verified directly against
    chatterbox-tts's source (see chatterbox_engine.py's module
    docstring), not inferred from one shared parameter list. This
    matters in both directions, not just "extra kwargs get ignored":
    Original's `generate()` has no `top_k` parameter at all, so passing
    one raises `TypeError` rather than being silently dropped; Turbo/
    Nano's `generate()` DOES accept `exaggeration`/`cfg_weight`/`min_p`
    without erroring, but its own source explicitly warns "are not
    supported by the [Turbo/Nano] version and will be ignored" if given
    non-default values -- so those three are left out for Turbo/Nano
    here too, rather than technically-legal-but-pointless (and
    warning-printing) values being sent anyway. `temperature`,
    `repetition_penalty`, and `top_p` are genuine, meaningful parameters
    on every tier, so they're always included.

    request.get(key) returning None (a field genuinely absent from an
    older saved project, or a caller that only sent a subset) leaves that
    keyword out entirely rather than passing `None` through to
    generate() -- which would itself raise, since these all have real
    numeric defaults upstream, not an Optional/None-accepting signature.
    """
    kwargs = {}
    for key in ("temperature", "repetition_penalty", "top_p"):
        value = request.get(key)
        if value is not None:
            kwargs[key] = value

    if voice_id == "original":
        for key in ("exaggeration", "cfg_weight", "min_p"):
            value = request.get(key)
            if value is not None:
                kwargs[key] = value
    else:
        value = request.get("top_k")
        if value is not None:
            kwargs["top_k"] = value

    return kwargs


def _sync_reference_conditionals(model, reference_audio_path) -> str | None:
    """Decides whether this call actually needs to pass `audio_prompt_path`
    to `generate()` (triggering its expensive `prepare_conditionals()`),
    or can instead reuse whatever conditionals the model already has
    prepared -- see this module's own docstring, "Reference-conditional
    caching", for the full rationale verified against chatterbox's real
    source. `reference_audio_path` is whatever the request sent: a real
    path string for a cloned voice, or None/empty for "use this tier's
    built-in voice".

    Three cases, in the order they're checked:

    1. Unchanged from what's already prepared (including the "still on
       the built-in default, still no reference requested" case, where
       both sides are falsy) -- nothing to do; return None so the caller
       omits audio_prompt_path and generate() reuses self.conds as-is.
    2. Reverting to the built-in voice (this call wants none, but a
       custom reference was prepared last) -- restore the model's own
       default conditionals (stashed by _load_model() the moment this
       model was constructed) directly onto self.conds. This is a plain
       attribute assignment, not a re-run of prepare_conditionals(), and
       fixes a real, separate bug this caching work surfaced: without
       it, simply omitting audio_prompt_path here would silently keep
       reusing the *previous* custom clone's conditionals forever,
       because generate() has no other way to know the caller wants the
       default back. Return None either way -- generate() should not be
       given a path in this branch.
    3. A genuinely new/different reference clip -- let generate() do the
       real work via audio_prompt_path, and record it as prepared for
       next time.
    """
    prepared = _MODEL_CACHE.get("prepared_reference_audio_path")
    if reference_audio_path == prepared:
        return None
    if not reference_audio_path:
        model.conds = _MODEL_CACHE.get("default_conds")
        _MODEL_CACHE["prepared_reference_audio_path"] = None
        return None
    _MODEL_CACHE["prepared_reference_audio_path"] = reference_audio_path
    return reference_audio_path


def _handle_synthesize(request: dict) -> None:
    import torch
    import torchaudio as ta

    device = "cuda" if torch.cuda.is_available() else "cpu"
    voice_id = request.get("voice_id") or "nano"
    model = _load_model(voice_id, device)

    generate_kwargs = _sampling_kwargs_for_tier(voice_id, request)
    audio_prompt_path = _sync_reference_conditionals(model, request.get("reference_audio_path"))
    if audio_prompt_path:
        generate_kwargs["audio_prompt_path"] = audio_prompt_path

    wav = model.generate(request["text"], **generate_kwargs)
    ta.save(request["output_path"], wav, model.sr)


#: Verified directly against chatterbox's own from_pretrained() source
#: (see chatterbox_engine.py's module docstring) -- the exact
#: hf_hub_download/snapshot_download calls it makes internally, kept
#: here too so --download-only can fetch the same files WITHOUT the
#: from_local()/model-construction step that follows them upstream.
_ORIGINAL_REPO_ID = "ResembleAI/chatterbox"
_ORIGINAL_FILES = ["ve.safetensors", "t3_cfg.safetensors", "s3gen.safetensors", "tokenizer.json", "conds.pt"]
_TURBO_REPO_ID = "ResembleAI/chatterbox-turbo"
# A real, distinct Hugging Face model repo -- verified directly (its own
# model card exists, describing a 110M-parameter model versus Turbo's
# 350M, loaded via the same `ChatterboxTurboTTS.from_pretrained(...,
# nano=True)` call). What's still NOT verified, despite a direct,
# repeated, verbatim source read of `tts_turbo.py` on GitHub's `master`
# branch: whether `from_pretrained(nano=True)` -- when some chatterbox-tts
# release actually implements that kwarg, since `master`'s current
# `from_pretrained()` doesn't accept it at all and this app's own
# fallback (see _load_model below) catches exactly that -- pulls from
# THIS repo specifically, or from a subset of `_TURBO_REPO_ID`'s own
# files instead. Given that genuine uncertainty, this is pre-fetched
# defensively alongside Turbo's files rather than assumed unnecessary:
# the cost is some extra disk space and download time during install,
# the alternative is the exact bug a real reviewer flagged -- "the
# installer says it downloaded everything, Nano is the default, and the
# first real Nano generation still needs the network" -- which a
# pre-fetch miss would reintroduce silently.
_NANO_REPO_ID = "ResembleAI/chatterbox-nano"
_TURBO_ALLOW_PATTERNS = ["*.safetensors", "*.json", "*.txt", "*.pt", "*.model"]


def _download_all_tiers() -> None:
    """Fetches every tier's model weights into the local Hugging Face
    cache without building any model object -- see module docstring.
    Used by windows_install.ps1's pre-warm step so the installer doesn't
    also pay the RAM/CPU cost of constructing a full model. Nano's own
    repo is fetched separately from Turbo's -- see _NANO_REPO_ID's
    comment for exactly why, and for the honest limits of what's
    actually confirmed here versus defensively covered."""
    from huggingface_hub import hf_hub_download, snapshot_download

    for fname in _ORIGINAL_FILES:
        hf_hub_download(repo_id=_ORIGINAL_REPO_ID, filename=fname)
    snapshot_download(repo_id=_TURBO_REPO_ID, allow_patterns=_TURBO_ALLOW_PATTERNS)
    try:
        snapshot_download(repo_id=_NANO_REPO_ID, allow_patterns=_TURBO_ALLOW_PATTERNS)
    except Exception:  # noqa: BLE001
        # Non-fatal on purpose: if this specific repo ever doesn't exist
        # under this name/is renamed/is merged into the Turbo repo
        # upstream, that shouldn't take down Original/Turbo's own
        # (verified, working) downloads along with it. A first real Nano
        # generation would then fall back to downloading over the
        # network at that point, same as before this fix existed -- a
        # regression back to the known gap, not a new failure mode.
        pass


def _cached_chatterbox_repos():
    """Best-effort list of Chatterbox-related repos already in the local
    Hugging Face cache, for --diagnose. Deliberately doesn't hardcode
    exact repo IDs per tier (nano vs. turbo's actual cache location
    isn't fully confirmed -- see module docstring) -- it just reports
    what's really there instead of guessing and possibly reporting
    something false."""
    try:
        from huggingface_hub import scan_cache_dir

        info = scan_cache_dir()
        return sorted(r.repo_id for r in info.repos if "chatterbox" in r.repo_id.lower())
    except Exception as exc:  # noqa: BLE001
        return f"unavailable: {exc}"


def _diagnose() -> dict:
    """One-shot JSON diagnostic report (`--diagnose`). Unlike
    `chatterbox_engine.py`'s `is_available()` (which only checks that
    `import chatterbox.tts` succeeds), this actually tries to load a
    model and generate a short clip -- so it catches problems an
    import-only check can't: a broken torch/CUDA install, a corrupted
    cached model, the perth/setuptools issue, and so on."""
    result: dict = {
        "python_version": sys.version,
        "chatterbox_version": None,
        "torch_version": None,
        "torchaudio_version": None,
        "cuda_available": None,
        "setuptools_available": None,
        "setuptools_version": None,
        "perth_watermarker_ok": None,
        "cached_chatterbox_repos": _cached_chatterbox_repos(),
        "model_tier_tested": "nano",
        "test_generation": {"ok": False, "detail": None},
    }

    try:
        import pkg_resources  # noqa: F401

        result["setuptools_available"] = True
    except ImportError:
        result["setuptools_available"] = False

    # Reported separately from the pkg_resources check above (and even
    # when that check fails) because "some setuptools is installed" and
    # "pkg_resources is importable" are no longer the same fact:
    # setuptools >= 82.0.0 installs fine but removed pkg_resources
    # entirely (setuptools's own changelog, "Deprecations and Removals"
    # for that release) -- exactly the failure mode requirements-
    # chatterbox.txt's pin exists to prevent. Surfacing the actual
    # installed version makes a stale or drifted pin (someone edits
    # requirements-chatterbox.txt without noticing why 80.9.0 was
    # chosen, or a manual `pip install --upgrade setuptools` in this
    # venv) visible here instead of only as a recurrence of the original
    # crash.
    try:
        import importlib.metadata as _importlib_metadata

        result["setuptools_version"] = _importlib_metadata.version("setuptools")
    except Exception as exc:  # noqa: BLE001
        result["setuptools_version"] = f"unknown: {exc}"

    try:
        import torch

        result["torch_version"] = torch.__version__
        result["cuda_available"] = torch.cuda.is_available()
    except Exception as exc:  # noqa: BLE001
        result["torch_version"] = f"unavailable: {exc}"
        result["cuda_available"] = False

    try:
        import torchaudio

        result["torchaudio_version"] = torchaudio.__version__
    except Exception as exc:  # noqa: BLE001
        result["torchaudio_version"] = f"unavailable: {exc}"

    try:
        import chatterbox

        result["chatterbox_version"] = getattr(chatterbox, "__version__", "unknown")
    except Exception as exc:  # noqa: BLE001
        result["chatterbox_version"] = f"unavailable: {exc}"

    try:
        import perth

        result["perth_watermarker_ok"] = getattr(perth, "PerthImplicitWatermarker", None) is not None
    except Exception as exc:  # noqa: BLE001
        result["perth_watermarker_ok"] = f"unavailable: {exc}"

    try:
        import tempfile

        device = "cuda" if result.get("cuda_available") is True else "cpu"
        model = _load_model("nano", device)
        import torchaudio as ta

        fd, path = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_chatterbox_diag_")
        os.close(fd)
        try:
            wav = model.generate("Testing, one two three.")
            ta.save(path, wav, model.sr)
            result["test_generation"] = {
                "ok": True,
                "detail": f"wrote {os.path.getsize(path)} bytes to a test WAV",
            }
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    except Exception as exc:  # noqa: BLE001
        result["test_generation"] = {
            "ok": False,
            "detail": f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}",
        }

    return result


@contextlib.contextmanager
def _stdout_seized_for_protocol():
    """Moves the real stdout file descriptor aside so this process's own
    JSON-lines writes are the only thing that can ever reach it -- see
    module docstring. Yields a text-mode file object connected to the
    ORIGINAL stdout; everything else (`sys.stdout`, and fd 1 at the OS
    level) is repointed at stderr for the duration, and restored again
    on the way out -- production only ever calls this once, right
    before the process exits, so the restore doesn't matter there, but
    making it fully reversible is what makes this testable in-process
    at all instead of permanently clobbering fd 1 for whatever called it.
    """
    real_stdout_fd = os.dup(1)
    real_stdout = os.fdopen(real_stdout_fd, "w", buffering=1)
    saved_sys_stdout = sys.stdout
    restore_fd = os.dup(1)  # a second, independent duplicate, purely to undo the dup2 below
    os.dup2(2, 1)  # OS-level: fd 1 now goes wherever fd 2 (stderr) goes
    sys.stdout = sys.stderr
    try:
        yield real_stdout
    finally:
        os.dup2(restore_fd, 1)
        os.close(restore_fd)
        sys.stdout = saved_sys_stdout
        real_stdout.close()


def _run_persistent_loop() -> int:
    with _stdout_seized_for_protocol() as real_stdout:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except json.JSONDecodeError as exc:
                print(json.dumps({"id": None, "ok": False, "error": f"Malformed request: {exc}"}), file=real_stdout, flush=True)
                continue

            req_id = request.get("id")
            cmd = request.get("cmd")
            if cmd == "shutdown":
                print(json.dumps({"id": req_id, "ok": True}), file=real_stdout, flush=True)
                return 0
            if cmd != "synthesize":
                print(json.dumps({"id": req_id, "ok": False, "error": f"Unknown command: {cmd!r}"}), file=real_stdout, flush=True)
                continue

            try:
                _handle_synthesize(request)
                response = {"id": req_id, "ok": True}
            except Exception as exc:  # noqa: BLE001 - this IS the error boundary
                detail = _friendly_detail(exc) + "\n\n" + traceback.format_exc()
                response = {"id": req_id, "ok": False, "error": detail}
            print(json.dumps(response), file=real_stdout, flush=True)
    return 0


def main(argv: list[str]) -> int:
    if len(argv) >= 2 and argv[1] == "--diagnose":
        # Real bug, hit by a real user: `_diagnose()` loads an actual
        # model and runs an actual short generation, and chatterbox/
        # torch/perth print plain progress text straight to stdout while
        # doing that (confirmed from an actual Diagnose-button report:
        # "loaded PerthNet (Implicit) at step 250,000" and "S3 Token ->
        # Mel Inference..." showed up glued to the front of the JSON).
        # `chatterbox_engine.py`'s `run_diagnostics()` does a plain
        # `json.loads()` on this process's entire captured stdout, so
        # that leading text broke parsing every time, surfacing as
        # "Unreadable diagnostics output" in the GUI instead of a real
        # report. The comment that used to be here ("plain stdout is
        # fine, nothing else reads this as JSON-lines") was wrong: it's
        # true nothing is doing line-by-line framing here, but something
        # IS doing whole-output JSON parsing, which is just as broken by
        # stray text. Fixed the same way the persistent loop protects
        # itself: seize real stdout for the whole diagnose run, and only
        # the final JSON is ever written to it.
        with _stdout_seized_for_protocol() as real_stdout:
            result = _diagnose()
            print(json.dumps(result, indent=2), file=real_stdout, flush=True)
        return 0

    if len(argv) >= 2 and argv[1] == "--download-only":
        try:
            _download_all_tiers()
        except Exception:  # noqa: BLE001 - windows_install.ps1 treats this step as non-fatal either way
            traceback.print_exc()
            return 1
        print("Chatterbox: model files downloaded")
        return 0

    return _run_persistent_loop()


if __name__ == "__main__":
    sys.exit(main(sys.argv))
