"""
Kokoro TTS adapter.

Kokoro-82M (hexgrad/Kokoro-82M) weights are Apache-2.0 -- fully
permissive; the model card explicitly welcomes commercial deployment.
V1 uses the `kokoro-onnx` package (thewh1teagle/kokoro-onnx, MIT/
Apache-style) rather than the original PyTorch `kokoro` package: it
runs on onnxruntime, the same runtime Piper already needs, so adding
a second TTS engine doesn't also pull in a multi-gigabyte PyTorch
install. Because the license is fully permissive we import
kokoro_onnx in-process (unlike Piper -- see piper_engine.py for why
that one runs as a subprocess instead).

Model files (fixed names, as published by kokoro-onnx's releases):
    models/kokoro/kokoro-v1.0.onnx
    models/kokoro/voices-v1.0.bin
V3 adds an in-app downloader for these (download_voice_pack() below,
driven from gui/resource_manager.py) -- it fetches BOTH files, since an
earlier draft of this downloader only fetched voices-v1.0.bin and left
the engine unable to load even though the button reported success.
They can still be grabbed by hand from:
    https://github.com/thewh1teagle/kokoro-onnx/releases

V3 GPU note: Kokoro's own constructor takes no `providers=` argument --
its GPU support is either "install onnxruntime-gpu and it's autodetected"
or an ONNX_PROVIDER environment variable (verified against kokoro-onnx's
source). Neither lets this app pick DirectML on a non-NVIDIA Windows box
without mutating global env state, so `_ensure_loaded` below instead
builds our own `onnxruntime.InferenceSession` with
`core.device.preferred_onnx_providers()` and hands it to Kokoro via the
`Kokoro.from_session()` classmethod, which *does* accept a pre-built
session. This is the same CPU/CUDA/DirectML provider list `core/device.py`
already computes -- Kokoro just wasn't using it before V3.

Two different "language code" needs collide in this engine, which is
why there are two columns in _KOKORO_VOICE_TABLE below:

  1. The app-wide language code (Voice.language / _lang_matches), which
     must line up with the plain BCP-47-ish codes used everywhere else
     in this app (COMMON_LANGUAGES in gui/panels/source_panel.py uses
     "ja", "zh", "es", ... -- English keeps its "en-US"/"en-GB" region
     tag since that's what Piper's voices also expose, and _lang_matches
     already does a prefix comparison so "en-US" still matches a
     request for "en").
  2. kokoro-onnx's own `lang=` parameter for Kokoro.create(), which uses
     a different, non-uniform set of tags: "en-us", "en-gb", "ja",
     "cmn" (not "zh"!), "es", "fr-fr" (not "fr"!), "hi", "it", "pt-br"
     (not "pt"!).

An earlier version of this file derived kokoro's `lang=` tag from
Voice.language via a single `.lower()` call. That happens to work for
English ("en-US".lower() == "en-us", which is coincidentally also
kokoro's own tag) but is wrong for every other language: it would pass
"zh" instead of "cmn", "fr" instead of "fr-fr", "pt" instead of
"pt-br", and (worse) it would use a single ungrouped letter like "j"
or "z" as the *app-level* language too, which meant filtering the
voice list by a real target language ("ja", "zh", ...) silently
returned zero Kokoro voices for every non-English language. The table
below fixes both problems by storing the two tags separately.
"""
from __future__ import annotations

import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Optional

from tts_studio.core.device import preferred_onnx_providers
from tts_studio.core.exceptions import (
    EngineUnavailableError,
    ModelNotFoundError,
    ResourceDownloadError,
    ResourceRemovalError,
    SynthesisFailedError,
)
from tts_studio.core.interfaces import TTSEngine
from tts_studio.core.models import SynthesisResult, SynthesisSettings, Voice

logger = logging.getLogger(__name__)

DEFAULT_VOICES_DIR = Path("models") / "kokoro"
MODEL_FILENAME = "kokoro-v1.0.onnx"
VOICES_FILENAME = "voices-v1.0.bin"
_RELEASE_BASE_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0"

# V3 "character" presets: a light voice-style blend plus a matched
# speed/gain nudge, layered on top of whatever voice/speed/volume the
# user picked. "mix" is how much of a second voice's style vector gets
# blended into the primary one (see _character_voice below); "voices"
# is a short list of stylistically-fitting candidates to blend *from*,
# ordered by nothing in particular -- _character_voice picks whichever
# candidate best matches the primary voice's own locale/gender prefix.
# These are a starting point, not a scientifically tuned set -- they're
# easy to retune by eye/ear once this runs on real hardware.
_CHARACTER_STYLES: dict[str, dict] = {
    "neutral": {"mix": 0.0, "speed": 1.0, "gain": 1.0, "voices": []},
    "warm": {
        "mix": 0.22, "speed": 0.96, "gain": 1.02,
        "voices": ["af_heart", "bf_emma", "am_michael", "bm_george"],
    },
    "calm": {
        "mix": 0.18, "speed": 0.88, "gain": 0.96,
        "voices": ["af_sky", "bf_lily", "af_sarah", "bm_lewis"],
    },
    "energetic": {
        "mix": 0.25, "speed": 1.12, "gain": 1.04,
        "voices": ["af_nova", "am_puck", "af_bella", "bm_fable"],
    },
    "dramatic": {
        "mix": 0.32, "speed": 0.92, "gain": 1.08,
        "voices": ["am_onyx", "bm_george", "af_bella", "bf_isabella"],
    },
    "storyteller": {
        "mix": 0.25, "speed": 0.94, "gain": 1.0,
        "voices": ["bm_fable", "af_sarah", "bf_emma", "am_michael"],
    },
}

# voice_id -> (app_language_code, kokoro_lang_tag, display_language, gender)
#
# This is the full Kokoro-82M v1.0 voice pack (54 voices across 8
# languages), taken from the model's own VOICES.md / examples rather than
# guessed from the voice-id prefix. If a future kokoro-onnx release adds
# voices not listed here, available_voices() below still surfaces them
# (via get_voices() when the installed package exposes it) with a
# best-effort language guess -- but anything in this table gets its
# correct app-level language, correct kokoro `lang=` tag, and gender.
_KOKORO_VOICE_TABLE: dict[str, tuple[str, str, str, str]] = {
    # American English
    "af_heart": ("en-US", "en-us", "English (US)", "female"),
    "af_alloy": ("en-US", "en-us", "English (US)", "female"),
    "af_aoede": ("en-US", "en-us", "English (US)", "female"),
    "af_bella": ("en-US", "en-us", "English (US)", "female"),
    "af_jessica": ("en-US", "en-us", "English (US)", "female"),
    "af_kore": ("en-US", "en-us", "English (US)", "female"),
    "af_nicole": ("en-US", "en-us", "English (US)", "female"),
    "af_nova": ("en-US", "en-us", "English (US)", "female"),
    "af_river": ("en-US", "en-us", "English (US)", "female"),
    "af_sarah": ("en-US", "en-us", "English (US)", "female"),
    "af_sky": ("en-US", "en-us", "English (US)", "female"),
    "am_adam": ("en-US", "en-us", "English (US)", "male"),
    "am_echo": ("en-US", "en-us", "English (US)", "male"),
    "am_eric": ("en-US", "en-us", "English (US)", "male"),
    "am_fenrir": ("en-US", "en-us", "English (US)", "male"),
    "am_liam": ("en-US", "en-us", "English (US)", "male"),
    "am_michael": ("en-US", "en-us", "English (US)", "male"),
    "am_onyx": ("en-US", "en-us", "English (US)", "male"),
    "am_puck": ("en-US", "en-us", "English (US)", "male"),
    "am_santa": ("en-US", "en-us", "English (US)", "male"),
    # British English
    "bf_alice": ("en-GB", "en-gb", "English (UK)", "female"),
    "bf_emma": ("en-GB", "en-gb", "English (UK)", "female"),
    "bf_isabella": ("en-GB", "en-gb", "English (UK)", "female"),
    "bf_lily": ("en-GB", "en-gb", "English (UK)", "female"),
    "bm_daniel": ("en-GB", "en-gb", "English (UK)", "male"),
    "bm_fable": ("en-GB", "en-gb", "English (UK)", "male"),
    "bm_george": ("en-GB", "en-gb", "English (UK)", "male"),
    "bm_lewis": ("en-GB", "en-gb", "English (UK)", "male"),
    # Japanese
    "jf_alpha": ("ja", "ja", "Japanese", "female"),
    "jf_gongitsune": ("ja", "ja", "Japanese", "female"),
    "jf_nezumi": ("ja", "ja", "Japanese", "female"),
    "jf_tebukuro": ("ja", "ja", "Japanese", "female"),
    "jm_kumo": ("ja", "ja", "Japanese", "male"),
    # Mandarin Chinese -- app code "zh" (matches COMMON_LANGUAGES), but
    # kokoro-onnx's own `lang=` value for this voice family is "cmn", not
    # "zh". Passing "zh" straight into Kokoro.create() would be wrong.
    "zf_xiaobei": ("zh", "cmn", "Chinese (Mandarin)", "female"),
    "zf_xiaoni": ("zh", "cmn", "Chinese (Mandarin)", "female"),
    "zf_xiaoxiao": ("zh", "cmn", "Chinese (Mandarin)", "female"),
    "zf_xiaoyi": ("zh", "cmn", "Chinese (Mandarin)", "female"),
    "zm_yunjian": ("zh", "cmn", "Chinese (Mandarin)", "male"),
    "zm_yunxi": ("zh", "cmn", "Chinese (Mandarin)", "male"),
    "zm_yunxia": ("zh", "cmn", "Chinese (Mandarin)", "male"),
    "zm_yunyang": ("zh", "cmn", "Chinese (Mandarin)", "male"),
    # Spanish
    "ef_dora": ("es", "es", "Spanish", "female"),
    "em_alex": ("es", "es", "Spanish", "male"),
    "em_santa": ("es", "es", "Spanish", "male"),
    # French -- kokoro's tag is "fr-fr", not "fr".
    "ff_siwis": ("fr", "fr-fr", "French", "female"),
    # Hindi
    "hf_alpha": ("hi", "hi", "Hindi", "female"),
    "hf_beta": ("hi", "hi", "Hindi", "female"),
    "hm_omega": ("hi", "hi", "Hindi", "male"),
    "hm_psi": ("hi", "hi", "Hindi", "male"),
    # Italian
    "if_sara": ("it", "it", "Italian", "female"),
    "im_nicola": ("it", "it", "Italian", "male"),
    # Portuguese (Brazil) -- kokoro's tag is "pt-br", not "pt".
    "pf_dora": ("pt", "pt-br", "Portuguese (Brazil)", "female"),
    "pm_alex": ("pt", "pt-br", "Portuguese (Brazil)", "male"),
    "pm_santa": ("pt", "pt-br", "Portuguese (Brazil)", "male"),
}


class KokoroTTSEngine(TTSEngine):
    name = "kokoro"
    display_name = "Kokoro (offline, Apache-2.0)"

    def __init__(self, voices_dir: Optional[Path] = None):
        self.voices_dir = Path(voices_dir) if voices_dir else DEFAULT_VOICES_DIR
        self._kokoro = None

    @property
    def _model_path(self) -> Path:
        return self.voices_dir / MODEL_FILENAME

    @property
    def _voices_path(self) -> Path:
        return self.voices_dir / VOICES_FILENAME

    def _ensure_loaded(self):
        if self._kokoro is not None:
            return self._kokoro
        try:
            from kokoro_onnx import Kokoro
        except ImportError as exc:
            raise EngineUnavailableError("kokoro", "pip install kokoro-onnx") from exc

        if not self._model_path.exists() or not self._voices_path.exists():
            raise ModelNotFoundError(MODEL_FILENAME, self.name, str(self.voices_dir))

        # Build our own onnxruntime session with the best available
        # provider (CUDA, then DirectML, then CPU -- see core/device.py)
        # instead of relying on Kokoro's own env-var-driven autodetection,
        # which has no way to prefer DirectML over CPU on a non-NVIDIA
        # Windows box. Falls back to Kokoro's plain constructor if
        # building the session fails for any reason (e.g. onnxruntime
        # missing entirely, which kokoro_onnx already depends on and
        # would have failed the import above anyway, but this keeps a
        # safety net rather than a hard crash).
        try:
            import onnxruntime as ort

            providers = preferred_onnx_providers()
            session = ort.InferenceSession(str(self._model_path), providers=providers)
            logger.info("Kokoro loaded with onnxruntime providers: %s", providers)
            self._kokoro = Kokoro.from_session(session, str(self._voices_path))
        except Exception:  # noqa: BLE001 - fall back to the simple constructor
            logger.warning("Falling back to Kokoro's default session setup.", exc_info=True)
            self._kokoro = Kokoro(str(self._model_path), str(self._voices_path))
        return self._kokoro

    def is_available(self) -> bool:
        try:
            import kokoro_onnx  # noqa: F401
            return True
        except ImportError:
            return False

    def voice_pack_status(self) -> str:
        if self._model_path.exists() and self._voices_path.exists():
            return f"Installed ({len(self.bundled_voice_ids())} voices)"
        if self._model_path.exists() or self._voices_path.exists():
            return "Incomplete (run Download / Repair to fetch the missing file)"
        return "Not installed"

    def bundled_voice_ids(self) -> list[str]:
        if not self._voices_path.exists():
            return sorted(_KOKORO_VOICE_TABLE)
        try:
            import numpy as np

            # voices-v1.0.bin is itself a numpy .npz archive despite the
            # .bin extension -- np.load() sniffs the real format from the
            # file's contents, not the name, which is also how kokoro-onnx
            # itself reads this same file internally.
            with np.load(self._voices_path) as voices:
                return sorted(voices.keys())
        except Exception:  # noqa: BLE001 - a damaged pack is handled by Repair
            logger.warning("Couldn't read the Kokoro voice pack; it may be corrupted.", exc_info=True)
            return []

    def download_voice_pack(self) -> None:
        """Download (or repair) BOTH files Kokoro needs: the ~80MB onnx
        model and the voice-style pack. An earlier version of this method
        only fetched voices-v1.0.bin, which left voice_pack_status()
        reporting success while synthesize() still raised
        ModelNotFoundError for the missing model file -- fixed here by
        always fetching both, skipping whichever one is already present
        and intact-looking (non-zero size)."""
        from urllib.request import urlopen

        self.voices_dir.mkdir(parents=True, exist_ok=True)
        for filename, dest in (
            (MODEL_FILENAME, self._model_path),
            (VOICES_FILENAME, self._voices_path),
        ):
            if dest.exists() and dest.stat().st_size > 0:
                continue
            url = f"{_RELEASE_BASE_URL}/{filename}"
            partial = dest.with_suffix(dest.suffix + ".part")
            try:
                with urlopen(url, timeout=60) as response, partial.open("wb") as output:
                    shutil.copyfileobj(response, output, length=1024 * 1024)
                partial.replace(dest)
            except Exception as exc:  # noqa: BLE001
                partial.unlink(missing_ok=True)
                raise ResourceDownloadError(f"Kokoro {filename}", str(exc)) from exc
        self._kokoro = None  # force a reload with the (now complete) files

    def remove_voice_pack(self) -> None:
        """Both files are one indivisible pack (see voice_pack_status) --
        there's no per-voice removal the way there is for Piper, since
        Kokoro's 54 voices all live inside the single voices-v1.0.bin
        archive. Frees the disk space; a later Download/Repair fetches
        both files again from scratch."""
        if not self._model_path.exists() and not self._voices_path.exists():
            raise ResourceRemovalError("Kokoro voice pack", "It isn't installed.")
        try:
            self._model_path.unlink(missing_ok=True)
            self._voices_path.unlink(missing_ok=True)
        except OSError as exc:
            raise ResourceRemovalError("Kokoro voice pack", str(exc)) from exc
        self._kokoro = None

    def supported_languages(self) -> list[str]:
        return sorted({v.language for v in self.available_voices()})

    def available_voices(self, language: Optional[str] = None) -> list[Voice]:
        voice_ids: list[str] = []
        try:
            kokoro = self._ensure_loaded()
            get_voices = getattr(kokoro, "get_voices", None)
            if callable(get_voices):
                voice_ids = list(get_voices())
        except (EngineUnavailableError, ModelNotFoundError):
            pass  # engine/model not ready yet -- fall back to the static table

        if not voice_ids:
            # Model files not installed yet (or this kokoro-onnx version
            # doesn't expose get_voices()): show the full known catalog so
            # the user can still see what they'd get, marked not-installed.
            voice_ids = list(_KOKORO_VOICE_TABLE.keys())

        installed = self._model_path.exists() and self._voices_path.exists()
        voices = []
        for voice_id in sorted(voice_ids):
            if voice_id in _KOKORO_VOICE_TABLE:
                lang, _kokoro_tag, _display, gender = _KOKORO_VOICE_TABLE[voice_id]
            else:
                # A voice this table doesn't know about yet (e.g. a newer
                # kokoro-onnx release) -- best-effort guess from the
                # prefix so it isn't dropped entirely, but log it so it's
                # easy to notice and add properly.
                logger.warning(
                    "Kokoro voice '%s' isn't in the known voice table; "
                    "guessing its language from the id prefix.", voice_id,
                )
                lang = _guess_lang_from_prefix(voice_id)
                gender = "female" if voice_id[1:2] == "f" else "male"
            voices.append(Voice(
                id=voice_id,
                name=voice_id,
                engine=self.name,
                language=lang,
                gender=gender,
                sample_rate=24000,
                supports_speed=True,
                supports_pitch=False,  # no pitch-shift DSP in V1
                supports_volume=True,
                supports_cloning=False,
                supports_character_presets=True,
                is_installed=installed,
            ))
        if language is None:
            return voices
        return [v for v in voices if _lang_matches(v.language, language)]

    def estimate_duration(self, text: str, settings: SynthesisSettings) -> float:
        words = max(len(text.split()), 1)
        seconds_per_word = 0.38 / max(settings.speed, 0.1)
        return words * seconds_per_word

    def synthesize(self, text: str, settings: SynthesisSettings) -> SynthesisResult:
        kokoro = self._ensure_loaded()
        kokoro_lang = _kokoro_lang_tag(settings.voice.id, settings.voice.language)
        style = _CHARACTER_STYLES.get(settings.character_preset, _CHARACTER_STYLES["neutral"])
        voice = self._character_voice(kokoro, settings.voice.id, style)
        # The character preset nudges speed/gain on top of the user's own
        # speed/volume rather than replacing them, clamped to Kokoro's
        # sane range so an aggressive preset stacked with an aggressive
        # manual speed can't produce garbled output.
        effective_speed = min(2.0, max(0.5, settings.speed * style["speed"]))
        try:
            samples, sample_rate = kokoro.create(
                text, voice=voice, speed=effective_speed, lang=kokoro_lang
            )
        except Exception as exc:  # noqa: BLE001 - surfaced to the user as-is
            raise SynthesisFailedError(str(exc)) from exc

        gain = max(settings.volume, 0.0) * style["gain"]
        if gain != 1.0:
            import numpy as np

            samples = np.clip(samples * gain, -1.0, 1.0)

        import soundfile as sf  # local import: keeps module import light

        fd, path_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_kokoro_")
        os.close(fd)
        final_path = Path(path_str)
        sf.write(str(final_path), samples, sample_rate, subtype="PCM_16")

        return SynthesisResult(
            samples_path=final_path,
            sample_rate=sample_rate,
            duration_seconds=len(samples) / sample_rate,
            engine=self.name,
            voice_id=settings.voice.id,
        )

    @staticmethod
    def _character_voice(kokoro, primary_id: str, style: dict):
        """Return either `primary_id` unchanged (neutral, or blending
        isn't possible right now) or a blended style-vector ndarray.
        Verified against kokoro-onnx's own source: `Kokoro.create(voice=)`
        accepts either a voice-id string or a raw
        NDArray[np.float32] style embedding, and `get_voice_style(name)`
        is what returns that embedding for a given voice id -- so linearly
        interpolating two such arrays and passing the result straight to
        create() is a supported use of the public API, not an internal
        hack."""
        mix = float(style["mix"])
        if mix <= 0:
            return primary_id
        get_voices = getattr(kokoro, "get_voices", None)
        get_style = getattr(kokoro, "get_voice_style", None)
        if not callable(get_voices) or not callable(get_style):
            return primary_id
        available = set(get_voices())
        candidates = [voice for voice in style["voices"] if voice in available and voice != primary_id]
        if not candidates:
            return primary_id
        # Prefer a candidate sharing the primary voice's locale prefix
        # (e.g. "a" = American English) and then its gender marker
        # ("f"/"m") -- keeps the blend from crossing accents unless
        # nothing better is offered for this character preset.
        secondary_id = max(
            candidates,
            key=lambda voice: (2 if voice[:1] == primary_id[:1] else 0)
            + (1 if voice[1:2] == primary_id[1:2] else 0),
        )
        try:
            primary_style = get_style(primary_id)
            secondary_style = get_style(secondary_id)
            return primary_style * (1.0 - mix) + secondary_style * mix
        except Exception:  # noqa: BLE001 - blending is a nice-to-have, never fatal
            logger.warning("Character-preset voice blend failed; using the unblended voice.", exc_info=True)
            return primary_id


def _kokoro_lang_tag(voice_id: str, app_language: str) -> str:
    """The tag to pass as Kokoro.create(..., lang=...). Looks up the known
    table first (this is what fixes voices whose kokoro tag differs from
    the app-level language code, e.g. Chinese/French/Portuguese); falls
    back to lower-casing the app-level code, which is only correct for
    English but is the best guess available for an unrecognized voice."""
    entry = _KOKORO_VOICE_TABLE.get(voice_id)
    if entry is not None:
        return entry[1]
    return app_language.lower()


def _guess_lang_from_prefix(voice_id: str) -> str:
    prefix = voice_id.split("_", 1)[0][:1].lower()
    return {
        "a": "en-US", "b": "en-GB", "j": "ja", "z": "zh",
        "e": "es", "f": "fr", "h": "hi", "i": "it", "p": "pt",
    }.get(prefix, prefix)


def _lang_matches(voice_lang: str, requested: str) -> bool:
    return voice_lang.split("-")[0].lower() == requested.split("-")[0].lower()
