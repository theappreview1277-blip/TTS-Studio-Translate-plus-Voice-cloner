"""
Chatterbox TTS adapter -- V4's first voice-cloning engine.

Chatterbox (resemble-ai/chatterbox) is **MIT-licensed for both the
inference code and the model weights** (verified against the repo's
`LICENSE` file and the `ResembleAI/chatterbox` Hugging Face model card
while building this), which is what put it ahead of XTTS-v2 (CPML,
non-commercial) and F5-TTS (CC-BY-NC-4.0) as V4's first cloning engine --
see ARCHITECTURE.md sections B and I.

**Why this engine runs in a SEPARATE virtual environment, unlike Kokoro:**
`chatterbox-tts` pins `numpy<2.0.0` (verified against its published
`pyproject.toml`), while `kokoro-onnx` -- already required by this app's
main environment -- pins `numpy>=2.0.2`. Those two constraints have no
overlap, so `chatterbox-tts` cannot be `pip install`-ed into the same
environment as the rest of this app, full stop. The fix is a second
environment, `.venv-chatterbox` (created by `windows_install.ps1` from
`requirements-chatterbox.txt`, targeting Python 3.11 -- see below), with
this engine talking to it over a subprocess -- see `_chatterbox_worker.py`,
the only thing that ever actually imports `chatterbox`/`torch`.

**Why Python 3.11 for `.venv-chatterbox`, not 3.12 like the main `.venv`**
(added after a real round of debugging a crash report against this app):
upstream chatterbox develops and tests against Python 3.11 (its own
README says so verbatim), and Python 3.12 changed `venv` to stop
bundling `setuptools` by default -- which chatterbox's `perth`
watermarking dependency needs for `pkg_resources`, and silently no-ops
instead of raising when it's missing (see `_chatterbox_worker.py`'s
docstring for the exact bug this caused). Note that 3.11 alone doesn't
fully solve this on its own: setuptools also removed `pkg_resources`
outright in v82.0.0, so an unpinned install could still break even on
3.11 -- `requirements-chatterbox.txt` pins an exact pre-82 version for
that reason, see there for the full story. `windows_install.ps1` targets
3.11 for this venv specifically now, with a non-fatal fallback to
whatever Python built the main `.venv` if 3.11 truly isn't available --
either way, `_chatterbox_worker.py` still defends against the
setuptools gap directly, since a pre-existing `.venv-chatterbox` or a
fallback-to-3.12 install can still hit it.

**Why this talks to a PERSISTENT worker process, not one subprocess per
synthesize() call (this replaced an earlier, real design mistake, caught
in review before it shipped further)**: the original version of this
file started a fresh `_chatterbox_worker.py` subprocess for every single
`synthesize()` call, which reloaded the ~500M-1B parameter model from
disk from scratch every time -- for every section, and again for every
sub-chunk of a long section. On CPU that's minutes of dead time per
section just for model loading, on top of the actual generation, plus
repeated full memory allocation/deallocation. That is not a "slow but
works" trade-off, it's the kind of thing that looks exactly like a
frozen or crashed app to someone trying to generate a real document.
Fixed by keeping ONE worker process alive for as long as Chatterbox
stays the selected engine (or the app stays open): the model loads once,
and every `synthesize()` call after that just sends a JSON-lines request
over the existing process's stdin and reads one JSON-lines response back
from its stdout. See `_start_worker`/`_send_request`/`shutdown` below,
and `_chatterbox_worker.py`'s docstring for the wire protocol.

**Three model tiers, exposed as three ordinary Voice entries** (added
after this session's own review flagged that the original 500M base
model is a poor default for a Windows/CPU-first app): Chatterbox also
ships a Turbo model and a Nano variant of it (110M params, ~3x realtime
on 8 CPU cores per upstream's own README), both via
`chatterbox.tts_turbo.ChatterboxTurboTTS.from_pretrained(device=...,
nano=True/False)` -- verified against upstream's README and its own
`example_tts_nano.py`, both of which agree on that exact call signature.
An earlier round of this project flagged a real, unresolved discrepancy
here: a direct source dive into `tts_turbo.py` on `master` at the time
didn't show the `nano` kwarg (or a `NANO_REPO_ID` constant) at all,
directly contradicting the docs/examples. A later re-check (during the
native-controls follow-up below) fetched the same file again and found
`nano=False` genuinely present on `from_pretrained()`, plus a real
`NANO_REPO_ID = "ResembleAI/chatterbox-nano"` constant -- upstream
appears to have added this since the original check, resolving what was
an honest discrepancy rather than a wrong guess on either side.
`_chatterbox_worker.py` still retries without the `nano` kwarg if
passing it raises `TypeError`, kept now as a defensive fallback for
whatever chatterbox-tts version happens to be installed (older pins
genuinely won't have it) rather than because the kwarg itself is still
in doubt. Nano is the default voice (first in the list) since it's the
one upstream explicitly recommends for CPU/on-device use; Turbo and the
original English `ChatterboxTTS` ("Original -- highest quality") are
also selectable. Chatterbox's Multilingual variant (23 languages) still
isn't wired up -- see ARCHITECTURE.md section I for why.

**Speed and Pitch, added in a second follow-up pass, as ffmpeg DSP on
the finished WAV rather than a model-level control Chatterbox doesn't
have.** Chatterbox's public API exposes no speed or pitch parameter at
all (unlike Speed on Piper/Kokoro, which they implement natively as part
of their own synthesis -- neither engine has ever supported Pitch at
all, so Chatterbox is actually the first voice in this app to expose a
Pitch control at all, not catching up to something Piper/Kokoro already
had). The first version of this file reflected the Chatterbox gap
honestly with
`supports_speed=False`/`supports_pitch=False` rather than faking
support, and deferred a DSP-based approximation to a later pass (see
ARCHITECTURE.md section J for that original deferral). This pass builds
that approximation: `_apply_speed_and_pitch()` below runs the finished
WAV through ffmpeg's `atempo` filter for Speed (a standard time-stretch
that changes duration without shifting pitch), and, for Pitch, the
standard `asetrate`-then-`atempo` trick (changing playback rate shifts
pitch *and* duration together; a second `atempo` call undoes just the
duration part, leaving only the pitch shift) -- both real, well-
established ffmpeg techniques, not something invented for this app. All
three tiers set `supports_speed=True`/`supports_pitch=True` now, but
with a narrower `speed_range`/`pitch_range` than Piper/Kokoro's native
implementations tolerate (0.75x-1.50x and +/-4 semitones, vs. their
0.5x-2.0x and, once Pitch is implemented natively somewhere, presumably
wider) -- a naive DSP approach audibly warbles well before those wider
bounds do. ffmpeg is already a soft dependency of this app (MP3/OGG
export -- see `audio/audio_processor.py`); Speed/Pitch simply extends
where it's used, and only when actually requested (Speed at 1.0x and
Pitch at 0 semitones skip ffmpeg entirely, so nothing changes for anyone
who leaves both alone).

**Native generation-time controls, added in a follow-up pass and
verified directly against chatterbox-tts's own source rather than a
README skim** (see `Voice.supports_expression`/`supports_turbo_nano_presets`/
`supports_advanced_sampling`/`supports_min_p`/`supports_top_k` in
core/models.py for the full per-tier breakdown, and `_chatterbox_worker.
py`'s `_handle_synthesize()` for where each one is actually gated before
reaching `model.generate()`): Original exposes `exaggeration` ("Expression"
in the GUI) and `cfg_weight` ("Voice Guidance"), which genuinely change
how the model performs a line, not just a post-processing effect on top
of one performance. Turbo/Nano don't honor those three (upstream's own
source warns they're ignored if passed), but do honor `top_k`, and both
families honor `temperature`/`repetition_penalty`/`top_p`, tucked under
an "Advanced" section in the GUI since most users have no reason to
understand token-sampling parameters.

**Inline paralinguistic sound tags were tried and then removed.** An
earlier version of this pass added Turbo/Nano-only insert buttons in
SourcePanel for `[laugh]`, `[cough]`, and `[chuckle]` -- all three
documented in chatterbox's own README as real, working tags, not
invented for this app. A real user reported that `[laugh]`/`[chuckle]`
didn't actually produce a laugh/chuckle sound in practice, and asked for
all three to come out rather than leaving `[cough]` alone once two of
three were known unreliable; with no way to independently verify
chatterbox's actual generation behavior in this sandbox, that real-world
result was taken over the README. The feature (buttons, the
`_SOUND_TAGS` list, and the `TTSPanel.voice_changed` signal/`MainWindow.
_on_tts_voice_changed()` bridge that existed solely to show/hide them)
was removed entirely rather than left half-working; what used to be
`Voice.supports_sound_tags` was renamed to `supports_turbo_nano_presets`
once its only remaining job (picking which Style preset table applies)
had nothing to do with sound tags any more.

Device selection (CPU vs. CUDA) happens inside `_chatterbox_worker.py`
using that environment's own `torch.cuda.is_available()` -- this file's
process doesn't have torch installed at all, so it can't check that
itself.
"""
from __future__ import annotations

import collections
import json
import logging
import os
import queue
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

from tts_studio.core.exceptions import EngineUnavailableError, SynthesisFailedError
from tts_studio.core.interfaces import TTSEngine
from tts_studio.core.models import SynthesisResult, SynthesisSettings, Voice

logger = logging.getLogger(__name__)

# Resolved from this file's own location, not the process's current
# working directory -- a bare `Path(".venv-chatterbox")` only ever
# worked because run.py happens to os.chdir() to the app root before
# anything else runs; anything that launched this module a different
# way (a different shortcut, a test, a future entry point) would look
# for `.venv-chatterbox` wherever the process happened to start instead
# of where it actually lives. `chatterbox_engine.py` sits at
# `tts_studio/tts_studio/engines/tts/chatterbox_engine.py`, so four
# `.parent`s up from this file is the app root that contains
# `.venv-chatterbox`, `run.py`, `requirements-chatterbox.txt`, etc.
_APP_ROOT = Path(__file__).resolve().parents[3]
_CHATTERBOX_VENV_DIR = _APP_ROOT / ".venv-chatterbox"
_WORKER_SCRIPT = Path(__file__).resolve().parent / "_chatterbox_worker.py"
_INSTALL_HINT = (
    "run windows_install.ps1 again (it sets up .venv-chatterbox automatically), "
    "or by hand: py -3.11 -m venv .venv-chatterbox && "
    ".venv-chatterbox\\Scripts\\pip install -r requirements-chatterbox.txt"
)

# How long to wait for one synthesize() response from the worker before
# giving up and treating it as hung. Generous on purpose -- CPU
# generation of a long section is genuinely slow -- but a hard ceiling
# beats the app looking frozen forever with no way out.
_RESPONSE_TIMEOUT_SECONDS = 1200

# How many of the worker's most recent stderr lines to keep around for
# error messages -- see _start_stderr_drain_thread. Bounded so a very
# chatty worker (verbose library warnings, progress lines) can't grow
# this without limit over a long session; recent lines are what matters
# for diagnosing a failure anyway.
_STDERR_BUFFER_LINES = 500

#: (voice id, display name, sort-first-means-default) -- Nano first
#: because it's what upstream recommends for CPU/on-device use, which is
#: this app's primary audience (see module docstring).
_VOICE_TIERS: list[tuple[str, str]] = [
    ("nano", "Chatterbox Nano (fastest, best for CPU)"),
    ("turbo", "Chatterbox Turbo (higher quality, best with a GPU)"),
    ("original", "Chatterbox Original (highest quality, slowest)"),
]


def _chatterbox_python() -> Path:
    """Path to the isolated environment's interpreter. Windows-only build
    (per README.md), so only the Scripts/ layout is checked -- a
    bin/python fallback would be trivial to add if this ever needs to
    run on macOS/Linux during development."""
    return _CHATTERBOX_VENV_DIR / "Scripts" / "python.exe"


def _lang_matches(voice_lang: str, requested: str) -> bool:
    return voice_lang.split("-")[0].lower() == requested.split("-")[0].lower()


class ChatterboxTTSEngine(TTSEngine):
    name = "chatterbox"
    display_name = "Chatterbox (voice cloning, MIT)"

    def __init__(self) -> None:
        self._process: Optional[subprocess.Popen] = None
        self._lock = threading.RLock()
        self._next_id = 0
        self._loaded_voice_id: Optional[str] = None
        # Bounded buffer of the worker's stderr, kept continuously drained
        # by a background thread -- see _start_stderr_drain_thread's
        # docstring for the real deadlock this fixes. Guarded by its OWN
        # lock, deliberately separate from self._lock: _send_request holds
        # self._lock for its entire round trip, including the (possibly
        # 1200-second) wait for a response. If the drain thread had to
        # take self._lock too, it could never append a line while a
        # request was in flight -- exactly the case where the worker's
        # stderr chatter matters most (a slow/stuck load) -- and it would
        # still be locked out at the moment _drain_stderr_after_death
        # tries to join it, since that join is itself called from inside
        # _send_request's own self._lock. A separate lock lets the drain
        # thread keep appending at any time, independent of whatever
        # _send_request is doing.
        self._stderr_lines: "collections.deque[str]" = collections.deque(maxlen=_STDERR_BUFFER_LINES)
        self._stderr_lock = threading.Lock()
        self._stderr_thread: Optional[threading.Thread] = None

    # -- availability ----------------------------------------------------
    def is_available(self) -> bool:
        """Fast, filesystem-only check -- NOT a subprocess import probe
        any more. A real user hit a real bug from the old approach:
        Chatterbox showed as "(not installed)" in the engine dropdown
        even though a Diagnose run moments earlier had already loaded
        chatterbox/torch/perth and generated real audio successfully.
        Root cause: this used to run `python -c "import chatterbox.tts"`
        as a subprocess with a 15-second timeout, and that import pulls
        in the same heavy torch-class stack that made a persistent
        worker necessary in the first place -- a cold import of it on a
        real Windows machine (first run after venv creation, antivirus
        scanning every DLL, a slow disk) can easily take longer than 15
        seconds, at which point `subprocess.TimeoutExpired` (a
        `SubprocessError`) was caught here and silently turned into
        "not installed". That's not just occasionally slow, it's a
        correctness bug that hides a working engine. This is also called
        far more often than it looks like it should be worth a subprocess
        spawn for: once per engine at startup (MainWindow._populate_engines),
        and again every time available_voices() runs (every engine
        switch) -- so the old approach was needlessly slow even on the
        machines where it didn't time out.

        This only needs to answer "does it look plausible that Chatterbox
        works", not "does it definitely work" -- actually proving that is
        already `run_diagnostics()`'s job (a real model load + short
        generation, behind the "Diagnose..." button), and `synthesize()`
        itself still raises a clear, specific error if something's
        actually broken despite this returning True. So a fast,
        best-effort filesystem check is the right trade here, not a
        worse one. (Checks more than one directory now -- see below.)"""
        python = _chatterbox_python()
        if not python.exists():
            return False
        # Derived from `python`'s own location (Scripts/python.exe -> two
        # .parents up is the venv root), not the fixed `_CHATTERBOX_VENV_DIR`
        # module constant directly -- same reasoning as `_chatterbox_python()`
        # itself, and what lets tests redirect this by faking
        # `_chatterbox_python()` alone, without also having to patch a
        # module-level constant. Windows-only build (see
        # `_chatterbox_python()`'s docstring), so the venv's site-packages
        # always live under Lib\site-packages, not the Unix
        # lib/pythonX.Y/site-packages layout.
        venv_root = python.parent.parent
        site_packages = venv_root / "Lib" / "site-packages"
        # Checking more than just "chatterbox" itself: a partially failed
        # `pip install -r requirements-chatterbox.txt` (interrupted
        # download, disk full, a dependency conflict) can leave an
        # importable `chatterbox` package behind while torch/torchaudio/
        # perth -- each installed as separate steps of the same
        # resolution -- are still missing or incomplete. Checking all
        # four catches more partial-install states than checking one,
        # while staying a handful of `is_dir()` calls -- still no
        # subprocess, still effectively instant. This is still a
        # best-effort "looks installed" heuristic, not a guarantee:
        # `run_diagnostics()` (a real model load + generation) and
        # `synthesize()`'s own error handling are what actually prove
        # Chatterbox works, and both still report a clear, specific error
        # if something here looks fine but isn't.
        return all((site_packages / name).is_dir() for name in ("chatterbox", "torch", "torchaudio", "perth"))

    # -- voices --------------------------------------------------------
    def supported_languages(self) -> list[str]:
        return ["en"]

    def available_voices(self, language: Optional[str] = None) -> list[Voice]:
        if language is not None and not _lang_matches("en", language):
            return []
        installed = self.is_available()
        return [
            Voice(
                id=voice_id,
                name=name,
                engine=self.name,
                language="en",
                sample_rate=24000,  # placeholder default; synthesize() reports the real rate
                # V4 follow-up #2: Chatterbox's generate() itself still has
                # no speed/pitch parameter -- these are satisfied by
                # _apply_speed_and_pitch()'s ffmpeg post-processing below,
                # not by the model, hence the narrower ranges than Piper/
                # Kokoro's native Speed implementation uses (see
                # Voice.speed_range/pitch_range's comment in core/models.py).
                supports_speed=True,
                supports_pitch=True,
                speed_range=(0.75, 1.50),
                pitch_range=(-4.0, 4.0),
                supports_volume=True,
                supports_cloning=True,
                supports_character_presets=False,
                # Verified directly against chatterbox-tts's own source
                # (see Voice.supports_expression's docstring in
                # core/models.py): "original" is the only tier whose
                # generate() does anything with exaggeration/cfg_weight/
                # min_p; "nano"/"turbo" share a generate() that instead
                # takes top_k, and explicitly ignores (with a runtime
                # warning) exaggeration/cfg_weight/min_p if passed.
                supports_expression=voice_id == "original",
                supports_turbo_nano_presets=voice_id in ("nano", "turbo"),
                supports_advanced_sampling=True,  # temperature/repetition_penalty/top_p apply to all three
                supports_min_p=voice_id == "original",
                supports_top_k=voice_id in ("nano", "turbo"),
                is_installed=installed,
            )
            for voice_id, name in _VOICE_TIERS
        ]

    # -- diagnostics -----------------------------------------------------
    def run_diagnostics(self) -> Optional[dict]:
        """Runs `_chatterbox_worker.py --diagnose` as a one-shot
        subprocess (deliberately NOT through the persistent worker --
        this is meant to actually exercise a real model load + short
        generation as an independent check, even while a stuck
        persistent worker is the very thing being diagnosed) and
        returns its parsed JSON report. See TTSPanel's "Diagnose..."
        button and _chatterbox_worker.py's `_diagnose()`.

        Two real problems fixed here, both flagged in review:

        1. Shuts the persistent worker down FIRST if one is running.
           Diagnose loads a real model in its own separate process; if
           the persistent worker already had a different tier resident
           (say "original", the heaviest), the machine would briefly have
           two Chatterbox models in memory at once -- purely to run a
           check, not because the user asked to use two tiers together.
           On a memory-constrained machine that's a real way to turn "run
           a diagnostic" into an out-of-memory failure. `shutdown()`
           already tolerates a stuck/unresponsive worker (falls back to
           `kill()` after a short wait), so this is safe even if the
           persistent worker is itself the thing hanging -- if anything,
           it helps, since a hung worker holding a model resident is
           freed before diagnosis runs instead of sitting there
           indefinitely. The persistent worker restarts lazily on the
           next real synthesize() call, same as an engine switch.
        2. Timeout raised from 180 seconds to match `_RESPONSE_TIMEOUT_SECONDS`
           (1200s), the same budget real synthesis gets. 180s was
           inconsistent with this app's own "Loading Chatterbox... may
           take a few minutes on CPU" messaging (see warmup_notice) -- a
           slow-but-working CPU install of the Original tier could
           legitimately take longer than 180 seconds just to load,
           reporting "Diagnostics produced no output" for a machine that
           would have succeeded given the same patience real generation
           gets."""
        self.shutdown()
        python = _chatterbox_python()
        if not python.exists():
            return {"error": f"Chatterbox isn't installed yet. {_INSTALL_HINT}"}
        try:
            result = subprocess.run(
                [str(python), str(_WORKER_SCRIPT), "--diagnose"],
                capture_output=True,
                text=True,
                timeout=_RESPONSE_TIMEOUT_SECONDS,
            )
        except subprocess.SubprocessError as exc:
            return {"error": f"Couldn't run Chatterbox diagnostics: {exc}"}
        if not result.stdout.strip():
            return {"error": result.stderr.strip() or "Diagnostics produced no output."}
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return {"error": f"Unreadable diagnostics output: {result.stdout[:500]!r}"}

    # -- warmup notice ----------------------------------------------------
    def warmup_notice(self, settings: SynthesisSettings) -> Optional[str]:
        """See TTSEngine.warmup_notice. Added after a real user report:
        the very first synthesize() call for a given model tier (or the
        first call after the persistent worker was (re)started) has to
        construct that model from scratch inside the worker -- which is
        genuinely slow on CPU, anywhere from under a minute to several
        minutes, especially for the 'original' tier -- and has no
        progress of its own to report while it's happening. Watching a
        generic "Generating audio 1 of N..." message sit unchanged for
        several minutes is indistinguishable from a real freeze, which is
        exactly what got reported. `_loaded_voice_id` (set in
        synthesize() above only after a real successful response) is
        what makes this an honest check rather than a guess -- it's None
        for a fresh/dead worker or a not-yet-used tier, and set to
        whichever tier last completed successfully otherwise."""
        with self._lock:
            already_warm = (
                self._process is not None
                and self._process.poll() is None
                and self._loaded_voice_id == settings.voice.id
            )
        if already_warm:
            return None
        # Kept short and on one line deliberately: an earlier, much
        # longer version of this message forced the whole app window
        # wider than the screen (a real user report -- see
        # OutputPanel.status_label's fix in output_panel.py for the
        # actual layout bug that let a status message do that at all).
        # Fixing the label is the real fix, but there's no reason for
        # this specific message to be a full paragraph either.
        return f"Loading Chatterbox '{settings.voice.id}' model (first time, up to a few min on CPU)..."

    # -- synthesis -----------------------------------------------------
    def estimate_duration(self, text: str, settings: SynthesisSettings) -> float:
        words = max(len(text.split()), 1)
        # V4 follow-up #2: Speed is now real (via _apply_speed_and_pitch()
        # below), so it belongs in this rough placeholder the same way
        # piper_engine.py/kokoro_engine.py already factor it into theirs.
        return words * 0.4 / max(settings.speed, 0.1)

    def synthesize(self, text: str, settings: SynthesisSettings) -> SynthesisResult:
        reference_path = settings.reference_audio_path
        if reference_path is not None and not Path(reference_path).exists():
            raise SynthesisFailedError(f"Reference audio file not found: {reference_path}")

        fd, path_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_chatterbox_")
        os.close(fd)
        final_path = Path(path_str)

        request = {
            "cmd": "synthesize",
            "text": text,
            "output_path": str(final_path),
            "reference_audio_path": str(reference_path) if reference_path else None,
            "voice_id": settings.voice.id,
            # Sent unconditionally -- TTSPanel.get_synthesis_settings()
            # already zeroes/defaults whichever of these the selected
            # voice doesn't support (same pattern as pitch_semitones/
            # character_preset there), and _chatterbox_worker.py's
            # _handle_synthesize() is the authoritative, tier-gated
            # decision of which of these actually reach model.generate()
            # -- so a stale or out-of-range value here can't reach a tier
            # that doesn't support it even if some other caller (a
            # hand-edited saved project, say) sent one.
            "exaggeration": settings.exaggeration,
            "cfg_weight": settings.cfg_weight,
            "temperature": settings.temperature,
            "repetition_penalty": settings.repetition_penalty,
            "min_p": settings.min_p,
            "top_p": settings.top_p,
            "top_k": settings.top_k,
        }

        try:
            response = self._send_request(request)
        except Exception:
            final_path.unlink(missing_ok=True)
            raise

        if not response.get("ok"):
            final_path.unlink(missing_ok=True)
            raise SynthesisFailedError(
                response.get("error") or "The Chatterbox worker reported failure without a message."
            )
        # Real voice/tier tracking, not just reset-to-None bookkeeping --
        # this is what lets warmup_notice() below tell a genuinely-first
        # (slow) call apart from a warm one.
        with self._lock:
            self._loaded_voice_id = settings.voice.id
        if not final_path.exists():
            raise SynthesisFailedError(
                "The Chatterbox worker reported success but produced no audio file."
            )

        try:
            # Speed/Pitch first, gain second: DSP-based time-stretching
            # changes the file's duration, so the sample count/sample
            # rate used for duration_seconds below has to reflect the
            # *post*-DSP file, not the raw worker output. Gain is a pure
            # amplitude scale with no effect on duration either way, so
            # its own ordering relative to this doesn't matter -- it just
            # needs the final, already-time-stretched file to read from.
            _apply_speed_and_pitch(final_path, settings.speed, settings.pitch_semitones)
            samples, sample_rate = _read_and_apply_gain(final_path, settings.volume)
        except Exception as exc:  # noqa: BLE001 - surfaced to the user as-is
            final_path.unlink(missing_ok=True)
            raise SynthesisFailedError(str(exc)) from exc

        return SynthesisResult(
            samples_path=final_path,
            sample_rate=sample_rate,
            duration_seconds=len(samples) / sample_rate,
            engine=self.name,
            voice_id=settings.voice.id,
        )

    # -- persistent worker lifecycle ------------------------------------
    def _ensure_worker_started(self) -> subprocess.Popen:
        """Starts the persistent worker once and reuses it for every
        subsequent call -- see module docstring for why this exists.
        Restarts automatically if the process has died since last use."""
        with self._lock:
            if self._process is not None and self._process.poll() is None:
                return self._process

            python = _chatterbox_python()
            if not python.exists():
                raise EngineUnavailableError("chatterbox", _INSTALL_HINT)

            self._process = subprocess.Popen(
                [str(python), str(_WORKER_SCRIPT)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,  # line-buffered, required for the JSON-lines protocol
            )
            self._loaded_voice_id = None
            with self._stderr_lock:
                self._stderr_lines.clear()
            self._start_stderr_drain_thread(self._process)
            return self._process

    def _start_stderr_drain_thread(self, proc: subprocess.Popen) -> None:
        """Real deadlock, not a hypothetical one: `stderr=subprocess.PIPE`
        gives the worker's stderr a finite OS pipe buffer, and nothing
        was reading it during normal operation -- only after the process
        had already died (`_drain_stderr_after_death`, called from error
        paths). `_chatterbox_worker.py` deliberately routes chatterbox's/
        torch's/perth's own chatty print() output to stderr (see
        `_stdout_seized_for_protocol`), so a model that logs enough
        during loading or generation can fill that pipe faster than it
        looks like it should. Once it's full, the worker's own `print()`
        call blocks inside the OS write() syscall -- before it can ever
        get to sending the JSON response on stdout -- and
        `_send_request`'s `_readline_with_timeout` then waits out the
        full `_RESPONSE_TIMEOUT_SECONDS` (1200s) for a response that was
        never going to come, which is indistinguishable from a genuine
        freeze to whoever's watching the GUI. Fixed the standard way for
        an unread pipe: a dedicated background thread whose only job is
        to keep reading it, always, for the process's entire lifetime --
        not just after something has already gone wrong. Read lines are
        kept in a bounded ring buffer (`_STDERR_BUFFER_LINES`) rather
        than an ever-growing string, and `_drain_stderr_after_death` now
        reads THAT buffer instead of the pipe directly, since this thread
        is the pipe's only legitimate reader from here on."""

        def _drain() -> None:
            try:
                for line in iter(proc.stderr.readline, ""):
                    with self._stderr_lock:
                        self._stderr_lines.append(line.rstrip("\n"))
            except (ValueError, OSError):
                # Pipe closed out from under us (process killed/reaped
                # elsewhere) -- nothing left to drain, just stop quietly.
                pass

        thread = threading.Thread(target=_drain, daemon=True, name="chatterbox-stderr-drain")
        self._stderr_thread = thread
        thread.start()

    def _send_request(self, request: dict) -> dict:
        with self._lock:
            proc = self._ensure_worker_started()
            self._next_id += 1
            request = dict(request, id=self._next_id)
            try:
                proc.stdin.write(json.dumps(request) + "\n")
                proc.stdin.flush()
            except (BrokenPipeError, OSError) as exc:
                stderr_text = self._drain_stderr_after_death()
                self._terminate_locked()
                raise SynthesisFailedError(
                    stderr_text or f"Couldn't reach the Chatterbox worker process: {exc}"
                ) from exc

            line = _readline_with_timeout(proc.stdout, _RESPONSE_TIMEOUT_SECONDS)
            if line is None:
                self._terminate_locked()
                raise SynthesisFailedError(
                    f"Chatterbox didn't respond within {_RESPONSE_TIMEOUT_SECONDS} seconds "
                    "and was stopped. It may be stuck, or the machine may be too slow for "
                    "this text length on the selected model tier -- try a smaller section, "
                    "or the Nano tier if you weren't already using it."
                )
            if line == "":
                stderr_text = self._drain_stderr_after_death()
                self._terminate_locked()
                raise SynthesisFailedError(
                    stderr_text or "The Chatterbox worker exited unexpectedly without responding."
                )

            try:
                return json.loads(line)
            except json.JSONDecodeError as exc:
                raise SynthesisFailedError(
                    f"Got an unreadable response from the Chatterbox worker: {line!r}"
                ) from exc

    def _drain_stderr_after_death(self) -> str:
        """Returns whatever the background drain thread has captured
        (see _start_stderr_drain_thread) -- does NOT read `proc.stderr`
        directly any more, since that thread is now the pipe's one and
        only reader for the process's whole lifetime; reading it again
        here would race with that thread instead of adding a second,
        independent way to see the same output.

        Every call site here is only reached once the worker is already
        dead or is about to be (a broken stdin pipe, EOF on stdout, or a
        response timeout that's about to `kill()` it) -- in every one of
        those cases the OS closes the process's stderr for us shortly
        after, which is exactly what makes the drain thread's `for line
        in iter(readline, "")` loop finish on its own. So this joins that
        thread (bounded, in case something unexpected keeps the pipe
        open) instead of guessing at a fixed sleep duration: a flat sleep
        either wastes time waiting past when the thread already finished,
        or -- worse -- returns too early on a slower/more loaded machine
        and silently reports an empty message even though the real
        content arrives microseconds later. Joining is exact instead of
        a guess either way.

        This method is always called from inside `_send_request`'s own
        `with self._lock:` block. That is exactly why the drain thread
        must use its own separate `self._stderr_lock` rather than
        `self._lock`: if it took `self._lock`, the join below would wait
        for a thread that itself could never proceed, because it'd be
        stuck trying to acquire the very lock this (joining) thread is
        already holding -- a real deadlock this method's caller would
        have hit on every crash-mid-request case, masked only by the 3s
        join timeout into "reports no stderr" rather than "hangs"."""
        thread = self._stderr_thread
        if thread is not None:
            thread.join(timeout=3.0)
        with self._stderr_lock:
            return "\n".join(self._stderr_lines).strip()

    def _terminate_locked(self) -> None:
        """Caller must hold self._lock."""
        proc, self._process = self._process, None
        self._loaded_voice_id = None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                proc.kill()
        except Exception:  # noqa: BLE001 - best-effort cleanup
            pass

    def shutdown(self) -> None:
        """Stops the persistent worker, if one is running. Called when
        the app closes (see MainWindow.closeEvent) and when the user
        switches away from Chatterbox to another engine, so an idle
        model isn't left resident in memory or as an orphaned process."""
        with self._lock:
            proc = self._process
            if proc is None:
                return
            if proc.poll() is None:
                try:
                    proc.stdin.write(json.dumps({"cmd": "shutdown"}) + "\n")
                    proc.stdin.flush()
                    proc.wait(timeout=5)
                except Exception:  # noqa: BLE001 - fall through to a hard kill
                    try:
                        proc.kill()
                    except Exception:  # noqa: BLE001
                        pass
            self._process = None
            self._loaded_voice_id = None


def _readline_with_timeout(pipe, timeout: float) -> Optional[str]:
    """`pipe.readline()` with a timeout, since a plain blocking read has
    no cross-platform, subprocess-pipe-safe way to time out on Windows.
    Returns the line (possibly `""` at EOF) or `None` on timeout. The
    reader thread is a daemon: if we time out, we abandon it rather than
    join it -- the caller kills the process right after, which unblocks
    the underlying read.
    """
    result: "queue.Queue[str]" = queue.Queue(maxsize=1)

    def _reader() -> None:
        try:
            result.put(pipe.readline())
        except Exception:  # noqa: BLE001
            result.put("")

    thread = threading.Thread(target=_reader, daemon=True)
    thread.start()
    try:
        return result.get(timeout=timeout)
    except queue.Empty:
        return None


def _apply_speed_and_pitch(path: Path, speed: float, pitch_semitones: float) -> None:
    """V4 follow-up #2: gives Chatterbox a Speed/Pitch control neither
    tier's own generate() has, by running the worker's raw output back
    through ffmpeg -- see the module docstring's "Speed and Pitch" section
    for why this exists and how it differs from Piper/Kokoro's native
    approach. A no-op (speed exactly 1.0 and pitch exactly 0) returns
    immediately without ever touching ffmpeg, so nobody who leaves both
    controls alone pays any cost or needs ffmpeg installed at all -- the
    same "only when actually used" principle MP3/OGG export already
    follows in audio/audio_processor.py.

    Speed uses ffmpeg's own `atempo` filter directly: a standard time-
    stretch that changes playback duration without shifting pitch, valid
    for a single filter instance anywhere from 0.5x to 2.0x -- this app's
    own 0.75x-1.50x GUI range (Voice.speed_range for Chatterbox) sits
    safely inside that, so one atempo call is always enough; no need for
    the multi-filter chaining trick some guides use to cover more extreme
    ratios.

    Pitch uses the standard "change the sample rate, then stretch the
    duration back out" trick: `asetrate=<original_rate * factor>` plays
    the file faster/slower AND raises/lowers its pitch together (exactly
    what changing a turntable's speed does to a record), where `factor =
    2 ** (semitones / 12)` is the frequency ratio for a given number of
    semitones; `aresample=<original_rate>` relabels it back to the
    original sample rate so downstream code (this app's own soundfile
    read included) doesn't silently misinterpret the timing; a second
    `atempo=<1 / factor>` then restretches the now-wrong duration back to
    the original length, undoing only the speed side-effect and leaving
    just the pitch shift. `factor` for this app's own +/-4 semitone range
    (Voice.pitch_range for Chatterbox) works out to roughly 0.79-1.26, so
    that restretch's own atempo call is comfortably inside the 0.5x-2.0x
    single-filter range too. When both Speed and Pitch are requested
    together, the two are simply chained as separate filters in one `-af`
    graph -- ffmpeg validates each `atempo` instance's own factor
    independently, not the combined effect of the whole chain, so this
    stays valid across this app's entire GUI range for both controls at
    once.
    """
    if speed == 1.0 and pitch_semitones == 0.0:
        return
    if shutil.which("ffmpeg") is None:
        raise SynthesisFailedError(
            "Speed/Pitch adjustment needs ffmpeg, which wasn't found on PATH. "
            "Install ffmpeg and make sure it's on PATH, or reset Speed to 1.00x "
            "and Pitch to 0 to skip this step."
        )

    import soundfile as sf

    original_rate = sf.info(str(path)).samplerate

    filters = []
    if pitch_semitones != 0.0:
        factor = 2.0 ** (pitch_semitones / 12.0)
        filters.append(f"asetrate={int(round(original_rate * factor))}")
        filters.append(f"aresample={original_rate}")
        filters.append(f"atempo={1.0 / factor:.6f}")
    if speed != 1.0:
        filters.append(f"atempo={speed:.6f}")

    fd, tmp_out_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_chatterbox_dsp_")
    os.close(fd)
    tmp_out = Path(tmp_out_str)
    try:
        cmd = ["ffmpeg", "-y", "-i", str(path), "-af", ",".join(filters), str(tmp_out)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0 or not tmp_out.exists():
            raise SynthesisFailedError(
                "ffmpeg failed while applying Speed/Pitch: "
                + (result.stderr.strip()[-800:] or "no error output.")
            )
        # os.replace rather than shutil.move: both paths are already
        # confirmed to be plain files on the same filesystem (both come
        # from tempfile.mkstemp), and os.replace is atomic where
        # shutil.move's copy-then-delete fallback isn't -- not that
        # anything else is racing this file, but there's no reason to
        # take the less-safe path when the safer one costs nothing here.
        os.replace(str(tmp_out), str(path))
    finally:
        tmp_out.unlink(missing_ok=True)  # no-op once os.replace has already consumed it


def _read_and_apply_gain(path: Path, volume: float):
    """Read back the worker's output and apply this app's usual volume
    gain in-process (same numpy/soundfile round-trip kokoro_engine.py/
    piper_engine.py use), rather than teaching the isolated worker about
    `SynthesisSettings` at all -- keeps the wire protocol to the bare
    minimum and keeps gain math testable without needing the isolated
    environment."""
    import numpy as np
    import soundfile as sf

    samples, sample_rate = sf.read(str(path))
    gain = max(volume, 0.0)
    if gain != 1.0:
        samples = np.clip(samples * gain, -1.0, 1.0)
        sf.write(str(path), samples, sample_rate, subtype="PCM_16")
    return samples, sample_rate
