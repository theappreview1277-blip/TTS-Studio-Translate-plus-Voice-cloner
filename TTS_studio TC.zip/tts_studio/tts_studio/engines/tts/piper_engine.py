"""
Piper TTS adapter.

Piper is now developed at OHF-Voice/piper1-gpl (the original
rhasspy/piper repo was archived read-only in Oct 2025 and is
MIT-licensed but unmaintained). The actively maintained project is
licensed **GPL-3.0**, not MIT -- an important change from what older
write-ups of Piper say, and worth knowing before you decide how you
want to license/distribute this app.

To keep this application's own licensing options open, we invoke
Piper as a separate `python -m piper` **subprocess** rather than
`from piper import PiperVoice` in-process. Running a GPL-3.0 program
as a subprocess and talking to it over files/stdio is normally
treated as "mere aggregation" (no copyleft obligation on the calling
program), whereas `import`-ing GPL code into the same process is
generally treated as creating a combined/derivative work that would
need to be GPL-compatible too. This is a conservative, defensible
default -- not legal advice. If you're fine with the whole app being
GPL-3.0, switching to the in-process Python API
(`from piper import PiperVoice, SynthesisConfig`) is simpler and is
documented at https://github.com/OHF-Voice/piper1-gpl/blob/main/docs/API_PYTHON.md

Model files: Piper voices are `<name>.onnx` + `<name>.onnx.json` pairs.
V3 adds an in-app "Download Voices..." manager (downloadable_voice_ids/
download_voice below, driven from gui/resource_manager.py) that wraps
`python -m piper.download_voices` so voices no longer have to be fetched
by hand -- they still land in `voices_dir` (default: ./models/piper), and
the manual command still works if you prefer it:
`python -m piper.download_voices en_US-lessac-medium --data-dir models/piper`.

V3 GPU note: Piper's CLI was checked directly against its own docs
(CLI.md / API_PYTHON.md in OHF-Voice/piper1-gpl) while wiring up V3's
device-detection work -- the *only* hardware-acceleration flag it
exposes is `--cuda` (CUDA via onnxruntime-gpu). There is currently no
DirectML flag on the CLI at all, so unlike Kokoro (see kokoro_engine.py)
there's nothing for this adapter to "wire up" for a non-NVIDIA Windows
GPU -- Piper simply runs on CPU there today. That's an upstream gap in
piper1-gpl, not something this app's subprocess wrapper can paper over
without dropping to the in-process Python API (which would pull
GPL-3.0 into this app's own process -- see the licensing note above).
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

from tts_studio.core.device import gpu_summary
from tts_studio.core.exceptions import (
    ModelNotFoundError,
    ResourceDownloadError,
    ResourceRemovalError,
    SynthesisFailedError,
)
from tts_studio.core.interfaces import TTSEngine
from tts_studio.core.models import SynthesisResult, SynthesisSettings, Voice

logger = logging.getLogger(__name__)

DEFAULT_VOICES_DIR = Path("models") / "piper"
# Piper's own published catalog of every downloadable voice ID -> metadata.
_VOICE_CATALOG_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main/voices.json?download=true"


class PiperTTSEngine(TTSEngine):
    name = "piper"
    display_name = "Piper (offline, GPL-3.0 engine)"

    def __init__(self, voices_dir: Optional[Path] = None):
        self.voices_dir = Path(voices_dir) if voices_dir else DEFAULT_VOICES_DIR

    # -- process plumbing -----------------------------------------------
    @staticmethod
    def _piper_command() -> list[str]:
        return [sys.executable, "-m", "piper"]

    def is_available(self) -> bool:
        try:
            result = subprocess.run(
                self._piper_command() + ["--help"],
                capture_output=True,
                timeout=15,
                text=True,
            )
            return result.returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False

    # -- voices --------------------------------------------------------
    def supported_languages(self) -> list[str]:
        return sorted({v.language for v in self.available_voices()})

    def available_voices(self, language: Optional[str] = None) -> list[Voice]:
        voices: list[Voice] = []
        if not self.voices_dir.exists():
            return voices

        for onnx_path in sorted(self.voices_dir.glob("*.onnx")):
            config_path = onnx_path.with_suffix(".onnx.json")
            meta: dict = {}
            if config_path.exists():
                try:
                    meta = json.loads(config_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    logger.warning("Couldn't parse Piper voice config: %s", config_path)

            lang_code = (
                meta.get("language", {}).get("code")
                or _guess_lang_from_filename(onnx_path.stem)
            )
            sample_rate = meta.get("audio", {}).get("sample_rate", 22050)
            voice = Voice(
                id=onnx_path.stem,
                name=onnx_path.stem,
                engine=self.name,
                language=lang_code,
                sample_rate=sample_rate,
                supports_speed=True,
                supports_pitch=False,  # no pitch-shift DSP in V1
                supports_volume=True,
                supports_cloning=False,
            )
            if language is None or _lang_matches(voice.language, language):
                voices.append(voice)
        return voices

    # -- V3: in-app voice management -------------------------------------
    def downloadable_voice_ids(self) -> list[str]:
        """Every voice ID Piper's own published catalog knows about,
        regardless of whether it's installed locally yet."""
        try:
            from urllib.request import urlopen

            with urlopen(_VOICE_CATALOG_URL, timeout=30) as response:
                import json as _json

                catalog = _json.load(response)
            return sorted(catalog.keys())
        except Exception as exc:  # noqa: BLE001
            raise ResourceDownloadError("Piper voice catalog", str(exc)) from exc

    def download_voice(self, voice_id: str) -> None:
        """Fetch one voice via Piper's own `piper.download_voices` module
        (a subprocess call, same GPL-isolation reasoning as synthesize()
        above) straight into voices_dir."""
        self.voices_dir.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(
            [sys.executable, "-m", "piper.download_voices", voice_id, "--data-dir", str(self.voices_dir)],
            capture_output=True,
            text=True,
            timeout=900,
        )
        if result.returncode != 0:
            raise ResourceDownloadError(voice_id, result.stderr.strip() or "Voice download failed.")

    def remove_voice(self, voice_id: str) -> None:
        """Piper voices are just two local files (no registry/database to
        update) -- removal is deleting them from voices_dir. Silently
        no-ops on whichever of the pair is already missing rather than
        raising, since a half-installed voice (one file present, one
        not) is exactly the broken state a removal should be able to
        clean up, not refuse to touch."""
        onnx_path = self.voices_dir / f"{voice_id}.onnx"
        config_path = self.voices_dir / f"{voice_id}.onnx.json"
        if not onnx_path.exists() and not config_path.exists():
            raise ResourceRemovalError(voice_id, "That voice isn't installed.")
        try:
            onnx_path.unlink(missing_ok=True)
            config_path.unlink(missing_ok=True)
        except OSError as exc:
            raise ResourceRemovalError(voice_id, str(exc)) from exc

    # -- synthesis -----------------------------------------------------
    def estimate_duration(self, text: str, settings: SynthesisSettings) -> float:
        words = max(len(text.split()), 1)
        seconds_per_word = 0.38 / max(settings.speed, 0.1)
        return words * seconds_per_word

    def synthesize(self, text: str, settings: SynthesisSettings) -> SynthesisResult:
        model_path = self.voices_dir / f"{settings.voice.id}.onnx"
        if not model_path.exists():
            raise ModelNotFoundError(settings.voice.id, self.name, str(model_path))

        # Piper's `length_scale` is inverse of speed: >1.0 = slower.
        length_scale = 1.0 / max(settings.speed, 0.1)

        with tempfile.TemporaryDirectory(prefix="ttsstudio_piper_") as tmp_dir:
            tmp_dir_path = Path(tmp_dir)
            input_txt = tmp_dir_path / "input.txt"
            input_txt.write_text(text, encoding="utf-8")
            output_wav = tmp_dir_path / "output.wav"

            cmd = self._piper_command() + [
                "-m", str(model_path),
                "--input-file", str(input_txt),
                "-f", str(output_wav),
                "--length-scale", f"{length_scale:.4f}",
                "--volume", f"{max(settings.volume, 0.0):.4f}",
            ]
            if gpu_summary().has_cuda:
                cmd.append("--cuda")

            logger.debug("Running Piper: %s", " ".join(cmd))
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result.returncode != 0 or not output_wav.exists():
                raise SynthesisFailedError(
                    result.stderr.strip()
                    or "piper exited without producing audio (see logs for details)."
                )

            # Copy the WAV out before the TemporaryDirectory is deleted.
            fd, final_path_str = tempfile.mkstemp(suffix=".wav", prefix="ttsstudio_piper_")
            os.close(fd)
            final_path = Path(final_path_str)
            final_path.write_bytes(output_wav.read_bytes())

        import soundfile as sf  # local import: keeps module import light

        info = sf.info(str(final_path))
        return SynthesisResult(
            samples_path=final_path,
            sample_rate=info.samplerate,
            duration_seconds=info.duration,
            engine=self.name,
            voice_id=settings.voice.id,
        )


def _guess_lang_from_filename(stem: str) -> str:
    # Piper voice filenames follow "<lang>_<REGION>-<name>-<quality>",
    # e.g. "en_US-lessac-medium" -> "en-US".
    lang_part = stem.split("-")[0]
    if "_" in lang_part:
        lang, region = lang_part.split("_", 1)
        return f"{lang}-{region}"
    return lang_part


def _lang_matches(voice_lang: str, requested: str) -> bool:
    return voice_lang.split("-")[0].lower() == requested.split("-")[0].lower()
