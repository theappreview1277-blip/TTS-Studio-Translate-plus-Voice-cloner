"""
Argos Translate adapter.

Argos Translate (argosopentech/argos-translate, dual MIT/CC0, offline,
pure-Python, built on CTranslate2+OpenNMT) is this app's sole
translation engine (a second, optional LibreTranslate HTTP-client engine
existed briefly in V3 and was removed by request -- see ARCHITECTURE.md
section C). It was chosen over NLLB/Marian (NLLB weights are
CC-BY-NC-4.0, non-commercial only; see ARCHITECTURE.md) as the default.
Language packages ("<from>_<to>.argosmodel") used to require a manual
`argospm`/curl step before V3 -- the methods below back the in-app
"Download Languages..." manager (gui/resource_manager.py) so that step
can happen from inside the app instead. translate() still raises a
clear UnsupportedLanguageError telling the user what's missing if they
try to translate a pair that was never installed.
"""
from __future__ import annotations

import logging

from tts_studio.core.exceptions import (
    EngineUnavailableError,
    ResourceDownloadError,
    ResourceRemovalError,
    TranslationFailedError,
    UnsupportedLanguageError,
)
from tts_studio.core.interfaces import TranslationEngine
from tts_studio.core.models import LanguageDetectionResult
from tts_studio.text_processing.language_id import detect_language

logger = logging.getLogger(__name__)


class ArgosTranslationEngine(TranslationEngine):
    name = "argos"
    display_name = "Argos Translate (offline)"

    def __init__(self) -> None:
        self._translate_module = None

    def _ensure_loaded(self):
        if self._translate_module is not None:
            return self._translate_module
        try:
            import argostranslate.translate as argos_translate
        except ImportError as exc:
            raise EngineUnavailableError("argos", "pip install argostranslate") from exc
        self._translate_module = argos_translate
        return argos_translate

    def is_available(self) -> bool:
        try:
            self._ensure_loaded()
            return True
        except EngineUnavailableError:
            return False

    def supported_languages(self) -> list[str]:
        argos_translate = self._ensure_loaded()
        installed = argos_translate.get_installed_languages()
        return sorted({lang.code for lang in installed})

    # -- V3: in-app language-package management --------------------------
    def installed_packages(self) -> list[dict[str, str]]:
        """Every already-installed <from>-><to> translate package, for
        display in the Resource Manager and for has_translation() below."""
        try:
            import argostranslate.package as argos_package
        except ImportError as exc:
            raise EngineUnavailableError("argos", "pip install argostranslate") from exc
        packages = []
        for package in argos_package.get_installed_packages():
            if getattr(package, "type", "translate") != "translate":
                continue
            packages.append({
                "from_code": package.from_code, "from_name": package.from_name,
                "to_code": package.to_code, "to_name": package.to_name,
            })
        return sorted(packages, key=lambda p: (p["from_name"], p["to_name"]))

    def available_packages(self, *, refresh: bool = True) -> list[dict[str, str]]:
        """Every <from>-><to> package Argos's index knows how to fetch.
        `refresh=True` re-downloads the index first (argostranslate caches
        it locally, so this is a small JSON fetch, not a model download)."""
        try:
            import argostranslate.package as argos_package
        except ImportError as exc:
            raise EngineUnavailableError("argos", "pip install argostranslate") from exc
        if refresh:
            try:
                argos_package.update_package_index()
            except Exception as exc:  # noqa: BLE001
                raise ResourceDownloadError("Argos package index", str(exc)) from exc
        packages = []
        for package in argos_package.get_available_packages():
            if getattr(package, "type", "translate") != "translate":
                continue
            packages.append({
                "from_code": package.from_code, "from_name": package.from_name,
                "to_code": package.to_code, "to_name": package.to_name,
            })
        return sorted(packages, key=lambda p: (p["from_name"], p["to_name"]))

    def install_package(self, source_lang: str, target_lang: str) -> None:
        try:
            import argostranslate.package as argos_package
        except ImportError as exc:
            raise EngineUnavailableError("argos", "pip install argostranslate") from exc
        try:
            argos_package.update_package_index()
            match = next((
                package for package in argos_package.get_available_packages()
                if getattr(package, "type", "translate") == "translate"
                and package.from_code == source_lang and package.to_code == target_lang
            ), None)
            if match is None:
                raise UnsupportedLanguageError(
                    f"No downloadable Argos package exists for {source_lang} \N{RIGHTWARDS ARROW} {target_lang}."
                )
            match.install()
        except UnsupportedLanguageError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ResourceDownloadError(f"{source_lang} \N{RIGHTWARDS ARROW} {target_lang}", str(exc)) from exc

    def uninstall_package(self, source_lang: str, target_lang: str) -> None:
        """Remove an installed <source>-><target> package. Argos's own API
        is a module-level `uninstall(pkg)` taking the Package object
        itself (not from/to code strings) -- verified against
        argos-translate's source rather than guessed -- so this looks the
        matching installed package up first."""
        try:
            import argostranslate.package as argos_package
        except ImportError as exc:
            raise EngineUnavailableError("argos", "pip install argostranslate") from exc
        match = next((
            package for package in argos_package.get_installed_packages()
            if getattr(package, "type", "translate") == "translate"
            and package.from_code == source_lang and package.to_code == target_lang
        ), None)
        if match is None:
            raise UnsupportedLanguageError(
                f"No installed Argos package for {source_lang} \N{RIGHTWARDS ARROW} {target_lang} to remove."
            )
        try:
            argos_package.uninstall(match)
        except Exception as exc:  # noqa: BLE001
            raise ResourceRemovalError(f"{source_lang} \N{RIGHTWARDS ARROW} {target_lang}", str(exc)) from exc

    def has_translation(self, source_lang: str, target_lang: str) -> bool:
        if source_lang == target_lang:
            return True
        try:
            argos_translate = self._ensure_loaded()
        except EngineUnavailableError:
            return False
        installed = argos_translate.get_installed_languages()
        source = next((lang for lang in installed if lang.code == source_lang), None)
        target = next((lang for lang in installed if lang.code == target_lang), None)
        return bool(source and target and source.get_translation(target) is not None)

    def detect_language(self, text: str) -> LanguageDetectionResult:
        # Argos itself has no language-ID model; delegate to the shared
        # offline detector (see text_processing/language_id.py).
        return detect_language(text)

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        argos_translate = self._ensure_loaded()
        installed = argos_translate.get_installed_languages()

        source = next((l for l in installed if l.code == source_lang), None)
        target = next((l for l in installed if l.code == target_lang), None)
        if source is None or target is None:
            missing = source_lang if source is None else target_lang
            raise UnsupportedLanguageError(
                f"No Argos Translate language package is installed for '{missing}'. "
                "Install it (argospm / Model Manager) and try again."
            )

        translation = source.get_translation(target)
        if translation is None:
            raise UnsupportedLanguageError(
                f"Argos Translate has no '{source_lang}\N{RIGHTWARDS ARROW}{target_lang}' "
                "package installed, and pivot translation didn't find a path either."
            )

        try:
            return translation.translate(text)
        except Exception as exc:  # noqa: BLE001 - surfaced to the user as-is
            raise TranslationFailedError(str(exc)) from exc
