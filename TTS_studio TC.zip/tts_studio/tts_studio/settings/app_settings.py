"""
Application settings.

A plain JSON file rather than QSettings: it's human-readable/editable,
trivially testable without a QApplication instance, and portable if
the GUI toolkit ever changes. Stored under the OS-appropriate app-data
directory (on Windows: %APPDATA%\\TTSStudio\\settings.json).
"""
from __future__ import annotations

import json
import logging
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


def _default_config_dir() -> Path:
    if sys.platform == "win32":
        base = os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
    return Path(base) / "TTSStudio"


@dataclass
class AppSettings:
    piper_voices_dir: str = "models/piper"
    kokoro_voices_dir: str = "models/kokoro"
    last_translation_engine: str = "argos"
    last_tts_engine: str = "piper"
    last_source_language: str = ""
    last_target_language: str = ""
    last_voice_id: str = ""
    prefer_gpu: bool = True
    default_export_dir: str = field(default_factory=lambda: str(Path.home() / "Documents" / "TTS Studio"))

    @classmethod
    def load(cls, path: Path | None = None) -> "AppSettings":
        path = path or (_default_config_dir() / "settings.json")
        if not path.exists():
            return cls()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            known = {f: data[f] for f in cls.__dataclass_fields__ if f in data}
            return cls(**known)
        except (OSError, json.JSONDecodeError, TypeError) as exc:
            logger.warning("Couldn't read settings at %s, using defaults: %s", path, exc)
            return cls()

    def save(self, path: Path | None = None) -> None:
        path = path or (_default_config_dir() / "settings.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
