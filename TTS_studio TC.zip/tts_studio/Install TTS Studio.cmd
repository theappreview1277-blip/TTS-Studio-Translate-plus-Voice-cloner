@echo off
setlocal
cd /d "%~dp0"
title TTS Studio Installer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows_install.ps1"
set "INSTALL_EXIT=%ERRORLEVEL%"
echo.
if not "%INSTALL_EXIT%"=="0" (
  echo Installation did not finish. The error is shown above.
  pause
  exit /b %INSTALL_EXIT%
)
echo Installation complete. You can now double-click "Run TTS Studio.cmd".
pause
