"""V4: exercise ChatterboxTTSEngine's persistent-worker design.

Chatterbox runs in its own `.venv-chatterbox` environment (see
chatterbox_engine.py's module docstring for why) and talks to a
persistent `_chatterbox_worker.py` subprocess over a JSON-lines protocol
on stdin/stdout, started once and reused for every synthesize() call
instead of one subprocess per call (a real design mistake from an
earlier version of this file, caught in review: reloading a
several-hundred-MB model from disk for every section -- and again for
every sub-chunk of a long one -- is what "painfully slow on CPU" and
"may appear frozen" actually look like in practice).

Neither chatterbox-tts nor a second Python environment is available in
this sandbox, so these tests fake the things chatterbox_engine.py
actually depends on: `_chatterbox_python()` (which env to use, via
`_FakeEnv`, which also lays down a fake `Lib/site-packages/chatterbox/`
directory since `is_available()` is a plain filesystem check against
that path now -- see chatterbox_engine.py's `is_available()` docstring;
it used to be a subprocess import probe, until a real user's report of
Chatterbox showing "not installed" despite demonstrably working traced
back to that probe's 15-second timeout being too short for a real cold
import of chatterbox's dependency stack) and `subprocess.Popen` (a fake
persistent process that understands the JSON-lines protocol well enough
to respond realistically). This verifies this app's own glue code --
request-building, process reuse, error surfacing, volume-gain math -- not
the isolated worker script's internals or chatterbox-tts itself; see
test_chatterbox_worker_v4.py for the worker script's own pure-Python
logic (which has zero chatterbox-tts/torch imports at that level).

`soundfile` (used to read back the worker's raw output and apply volume
gain, same as piper_engine.py/kokoro_engine.py) also isn't installable
in this sandbox -- a tiny fake module is injected for the same reason it
was needed before this rewrite.
"""
import json
import queue
import subprocess
import sys
import tempfile
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import tts_studio.engines.tts.chatterbox_engine as chatterbox_engine
from tts_studio.core.exceptions import EngineUnavailableError, SynthesisFailedError
from tts_studio.core.models import SynthesisSettings
from tts_studio.engines.tts.chatterbox_engine import ChatterboxTTSEngine


def _fake_soundfile_write(path, data, samplerate, subtype=None):
    import numpy as np

    arr = np.asarray(data, dtype=np.float32)
    with open(path, "wb") as f:
        np.array([samplerate, arr.shape[0]], dtype=np.int64).tofile(f)
        arr.tofile(f)


def _fake_soundfile_read(path, **_kwargs):
    import numpy as np

    with open(path, "rb") as f:
        header = np.fromfile(f, dtype=np.int64, count=2)
        samplerate, count = int(header[0]), int(header[1])
        data = np.fromfile(f, dtype=np.float32, count=count)
    return data, samplerate


def _install_fake_soundfile():
    fake = types.ModuleType("soundfile")
    fake.write = _fake_soundfile_write
    fake.read = _fake_soundfile_read
    sys.modules["soundfile"] = fake


def _remove_fake_soundfile():
    sys.modules.pop("soundfile", None)


class _FakeEnv:
    """Sets up a fake '.venv-chatterbox/Scripts/python.exe' that merely
    needs to exist as a file (its content is never executed -- every
    test also fakes subprocess.Popen so nothing really shells out).

    Also creates fake 'Lib/site-packages/{chatterbox,torch,torchaudio,
    perth}/' marker directories by default, since `is_available()` is a
    plain filesystem check against those paths now, not a subprocess
    import probe -- see chatterbox_engine.py's `is_available()`
    docstring for why that changed (a real user saw Chatterbox reported
    as "not installed" even though it demonstrably worked, because the
    old subprocess-based import probe's 15-second timeout was too short
    for a cold real-world import of chatterbox's torch-class dependency
    stack) and for why it checks all four now, not just `chatterbox`
    alone (a partially failed pip install can leave one importable while
    the others are missing). Pass `chatterbox_installed=False` for tests
    specifically about that "venv exists but the package doesn't look
    installed" case."""

    def __init__(self, exists: bool = True, chatterbox_installed: bool = True):
        self._tmp = tempfile.TemporaryDirectory()
        venv_root = Path(self._tmp.name)
        python_dir = venv_root / "Scripts"
        python_dir.mkdir(parents=True)
        self.python_path = python_dir / "python.exe"
        if exists:
            self.python_path.touch()
        if exists and chatterbox_installed:
            site_packages = venv_root / "Lib" / "site-packages"
            for name in ("chatterbox", "torch", "torchaudio", "perth"):
                (site_packages / name).mkdir(parents=True)
        self._original = chatterbox_engine._chatterbox_python
        chatterbox_engine._chatterbox_python = lambda: self.python_path

    def close(self):
        chatterbox_engine._chatterbox_python = self._original
        self._tmp.cleanup()


class _FakeWritable:
    def __init__(self, on_write):
        self._on_write = on_write

    def write(self, text):
        self._on_write(text)

    def flush(self):
        pass


class _FakeReadable:
    """Backed by a queue.Queue, not a plain list -- readline() BLOCKS
    until either a line is pushed or the pipe is explicitly closed (a
    `None` sentinel), matching how a real OS pipe behaves. This matters
    now in a way it didn't before: chatterbox_engine.py's new
    `_start_stderr_drain_thread` (see chatterbox_engine.py) starts a
    long-lived background reader as soon as the fake process exists,
    well before anything's been written to it yet. A plain list-based
    fake ("empty means EOF right now") would look like the process died
    immediately to that thread, well before the test ever gets around to
    pushing real content -- a real, hit-during-this-fix bug in this test
    file's own infrastructure, not just a hypothetical one. The
    pre-existing per-call stdout reads (_readline_with_timeout always
    starts its one-shot reader thread AFTER the corresponding stdin
    write already ran synchronously in every test here) behave
    identically with this queue-based version, since the data's already
    queued by the time anything calls readline()."""

    def __init__(self):
        self._queue: "queue.Queue" = queue.Queue()
        self._closed = False

    def push_line(self, line: str) -> None:
        self._queue.put(line)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._queue.put(None)  # sentinel: readline() returns "" forever after

    def readline(self) -> str:
        item = self._queue.get()
        if item is None:
            self._queue.put(None)  # put it back so a later readline() also sees EOF
            return ""
        return item

    def read(self) -> str:
        parts = []
        while True:
            try:
                item = self._queue.get_nowait()
            except queue.Empty:
                break
            if item is None:
                self._queue.put(None)
                break
            parts.append(item)
        return "".join(parts)


class _FakeProcess:
    """Stands in for subprocess.Popen's return value: a persistent
    process that understands the {"cmd": "synthesize"/"shutdown"}
    JSON-lines protocol well enough to respond like the real worker
    would, without actually running one. `handler(request) -> dict`
    computes the response body (everything except "id", which is
    threaded through automatically, matching the real protocol)."""

    def __init__(self, handler):
        self._handler = handler
        self._returncode = None
        self.stdin = _FakeWritable(self._on_stdin_write)
        self.stdout = _FakeReadable()
        self.stderr = _FakeReadable()
        self.started_count = 1  # informational, for assertions

    def _on_stdin_write(self, text):
        line = text.strip()
        if not line:
            return
        request = json.loads(line)
        if request.get("cmd") == "shutdown":
            self.stdout.push_line(json.dumps({"id": request.get("id"), "ok": True}) + "\n")
            self._returncode = 0
            return
        response = dict(self._handler(request))
        response["id"] = request.get("id")
        self.stdout.push_line(json.dumps(response) + "\n")

    def poll(self):
        return self._returncode

    def wait(self, timeout=None):
        return self._returncode

    def kill(self):
        self._returncode = -9
        # Matches a real killed process's pipes going to EOF -- also
        # what lets the stderr-drain thread's background reader loop
        # actually terminate instead of blocking forever (harmless for
        # test correctness either way, since it's a daemon thread, but
        # this is the realistic behavior to model).
        self.stdout.close()
        self.stderr.close()


def _writes_wav_and_succeeds(request: dict) -> dict:
    import numpy as np

    _fake_soundfile_write(request["output_path"], np.array([0.1, -0.2, 0.3, -0.1] * 25), 24000)
    return {"ok": True}


class _PopenFactory:
    """Installed in place of subprocess.Popen for the duration of a
    test. `handler` builds each fake process's synthesize-response;
    `processes` records every _FakeProcess actually created, so a test
    can assert exactly one was started across several synthesize()
    calls (the whole point of this rewrite).

    No longer needs to special-case an `is_available()` `-c` import
    probe: `is_available()` is a plain filesystem check now (see
    chatterbox_engine.py and `_FakeEnv` above), so `subprocess.Popen` is
    only ever reached here for the real persistent-worker process."""

    def __init__(self, handler=_writes_wav_and_succeeds, process_factory=None):
        self.handler = handler
        self.process_factory = process_factory or (lambda: _FakeProcess(self.handler))
        self.processes: list = []
        self._original = subprocess.Popen
        subprocess.Popen = self._popen

    def _popen(self, cmd, **kwargs):
        proc = self.process_factory()
        self.processes.append(proc)
        return proc

    def close(self):
        subprocess.Popen = self._original


def test_is_available_false_when_environment_missing():
    env = _FakeEnv(exists=False)
    try:
        assert ChatterboxTTSEngine().is_available() is False
    finally:
        env.close()


def test_is_available_true_when_environment_and_package_both_present():
    env = _FakeEnv(exists=True, chatterbox_installed=True)
    try:
        assert ChatterboxTTSEngine().is_available() is True
    finally:
        env.close()


def test_is_available_false_when_environment_exists_but_package_missing():
    """The venv (and its python.exe) exists, but the `chatterbox` package
    directory doesn't -- e.g. `windows_install.ps1` created the venv but
    `pip install -r requirements-chatterbox.txt` failed partway through.
    Also covers the original real bug's shape from the other direction:
    this must NOT depend on timing/subprocess behavior any more, only on
    what's actually on disk."""
    env = _FakeEnv(exists=True, chatterbox_installed=False)
    try:
        assert ChatterboxTTSEngine().is_available() is False
    finally:
        env.close()


def test_is_available_false_on_a_partial_install_missing_one_dependency():
    """Real gap flagged in review: checking only for the `chatterbox`
    directory would report "installed" even when a partially failed
    `pip install -r requirements-chatterbox.txt` (interrupted download,
    disk full, a resolver conflict) left torch/torchaudio/perth missing
    or incomplete -- `chatterbox` itself can be a small, quick-to-install
    package that finishes before a later, larger dependency in the same
    resolution fails. is_available() now requires all four site-packages
    directories to exist, so a partial install like this is correctly
    reported as not available instead of silently passing."""
    env = _FakeEnv(exists=True, chatterbox_installed=True)
    try:
        # Simulate exactly this partial-install shape: chatterbox made it
        # in, torch didn't.
        venv_root = env.python_path.parent.parent
        import shutil

        shutil.rmtree(venv_root / "Lib" / "site-packages" / "torch")
        assert ChatterboxTTSEngine().is_available() is False
    finally:
        env.close()


def test_available_voices_exposes_three_model_tiers_nano_first():
    env = _FakeEnv(exists=True, chatterbox_installed=True)
    try:
        engine = ChatterboxTTSEngine()
        voices = engine.available_voices()
        assert [v.id for v in voices] == ["nano", "turbo", "original"]
        for voice in voices:
            assert voice.engine == "chatterbox"
            assert voice.language == "en"
            assert voice.supports_cloning is True
            # V4 follow-up #2: Speed/Pitch became real (via ffmpeg DSP)
            # after this test was first written -- see
            # test_available_voices_sets_speed_and_pitch_capability_and_ranges()
            # below for the dedicated coverage of the new flags/ranges.
            assert voice.supports_speed is True
            assert voice.supports_volume is True
            assert voice.is_installed is True

        assert len(engine.available_voices("en")) == 3
        assert len(engine.available_voices("en-US")) == 3
        assert engine.available_voices("fr") == []
    finally:
        env.close()


def test_available_voices_sets_tier_specific_native_control_flags():
    """Verified directly against chatterbox-tts's own source (see
    chatterbox_engine.py's module docstring): Original is the only tier
    whose generate() does anything with exaggeration/cfg_weight/min_p,
    and Turbo/Nano's generate() has top_k instead -- both families accept
    temperature/repetition_penalty/top_p.

    supports_turbo_nano_presets (was supports_sound_tags before the
    sound-tags feature was removed -- see chatterbox_engine.py's module
    docstring) now only decides which Style preset table TTSPanel shows;
    it still uses the exact same nano/turbo-vs-original split, which is
    the only reason it's covered in this same tier-flags test."""
    env = _FakeEnv(exists=True, chatterbox_installed=True)
    try:
        engine = ChatterboxTTSEngine()
        voices = {v.id: v for v in engine.available_voices()}
        for tier in ("nano", "turbo", "original"):
            assert voices[tier].supports_advanced_sampling is True

        assert voices["original"].supports_expression is True
        assert voices["original"].supports_min_p is True
        assert voices["original"].supports_turbo_nano_presets is False
        assert voices["original"].supports_top_k is False

        for tier in ("nano", "turbo"):
            assert voices[tier].supports_expression is False
            assert voices[tier].supports_min_p is False
            assert voices[tier].supports_turbo_nano_presets is True
            assert voices[tier].supports_top_k is True
    finally:
        env.close()


def test_available_voices_sets_speed_and_pitch_capability_and_ranges():
    """V4 follow-up #2: all three tiers get Speed/Pitch now (via ffmpeg
    DSP -- see chatterbox_engine.py's module docstring), but with a
    narrower range than Piper/Kokoro's native Speed implementation uses,
    since a naive DSP approach starts sounding warbly/artificial well
    before Voice's own wide 0.5x-2.0x/-12..+12 defaults would be a
    problem for a native implementation. Same narrower range on all
    three tiers -- the DSP itself doesn't care which tier generated the
    audio it's post-processing."""
    env = _FakeEnv(exists=True, chatterbox_installed=True)
    try:
        engine = ChatterboxTTSEngine()
        for voice in engine.available_voices():
            assert voice.supports_speed is True
            assert voice.supports_pitch is True
            assert voice.speed_range == (0.75, 1.50)
            assert voice.pitch_range == (-4.0, 4.0)
    finally:
        env.close()


def test_synthesize_raises_engine_unavailable_when_environment_missing():
    env = _FakeEnv(exists=False)
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        assert voice.is_installed is False
        settings = SynthesisSettings(voice=voice)
        try:
            engine.synthesize("text", settings)
            assert False, "expected EngineUnavailableError"
        except EngineUnavailableError as exc:
            assert "chatterbox" in exc.engine_name
    finally:
        env.close()


def test_worker_process_is_started_once_and_reused_across_calls():
    """The entire point of this rewrite: two synthesize() calls in a row
    must reuse the same persistent worker process, not start a new one
    each time (that was the original, real performance bug)."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)

        result1 = engine.synthesize("first section", settings)
        result2 = engine.synthesize("second section", settings)
        try:
            assert len(popen_factory.processes) == 1, "expected exactly one worker process across two calls"
        finally:
            result1.samples_path.unlink(missing_ok=True)
            result2.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_warmup_notice_is_shown_before_first_synthesize_and_cleared_after():
    """Added after a real user report: the first synthesize() call for a
    given model tier constructs that model from scratch inside the
    worker, which is genuinely slow on CPU with no progress of its own --
    watching a generic "Generating..." message sit unchanged for minutes
    looked exactly like a frozen app. warmup_notice() must say something
    before that first call, and go quiet (return None) once a real
    successful response for that same tier has come back, since later
    calls with an already-loaded tier are the fast path."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)

        notice_before = engine.warmup_notice(settings)
        assert notice_before, "expected a non-empty warmup notice before any synthesize() call"
        assert voice.id in notice_before

        result = engine.synthesize("first section", settings)
        try:
            notice_after = engine.warmup_notice(settings)
            assert notice_after is None, "expected no warmup notice once this tier's model is already loaded"
        finally:
            result.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_warmup_notice_reappears_after_switching_model_tier():
    """A loaded 'nano' model doesn't make 'original' warm too -- the
    worker only keeps one model resident at a time (see
    _chatterbox_worker.py's _MODEL_CACHE), so switching tiers mid-session
    is just as slow as the very first call."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        engine = ChatterboxTTSEngine()
        voices = {v.id: v for v in engine.available_voices()}
        nano_settings = SynthesisSettings(voice=voices["nano"])
        original_settings = SynthesisSettings(voice=voices["original"])

        result = engine.synthesize("nano text", nano_settings)
        try:
            assert engine.warmup_notice(nano_settings) is None
            notice_for_original = engine.warmup_notice(original_settings)
            assert notice_for_original, "expected a warmup notice for a tier that hasn't loaded yet"
            assert "original" in notice_for_original
        finally:
            result.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_warmup_notice_reappears_after_shutdown():
    """shutdown() kills the persistent worker, so whatever was loaded in
    it is gone too -- the next call is a cold start again."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)

        result = engine.synthesize("text", settings)
        try:
            assert engine.warmup_notice(settings) is None
        finally:
            result.samples_path.unlink(missing_ok=True)

        engine.shutdown()
        assert engine.warmup_notice(settings), "expected a warmup notice again after shutdown()"
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_shutdown_then_synthesize_starts_a_fresh_process():
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)

        result1 = engine.synthesize("before shutdown", settings)
        engine.shutdown()
        result2 = engine.synthesize("after shutdown", settings)
        try:
            assert len(popen_factory.processes) == 2, "expected a new process after shutdown()"
        finally:
            result1.samples_path.unlink(missing_ok=True)
            result2.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_without_reference_builds_null_request():
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    captured_requests = []

    def handler(request):
        captured_requests.append(request)
        return _writes_wav_and_succeeds(request)

    popen_factory = _PopenFactory(handler=handler)
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]  # "nano"
        settings = SynthesisSettings(voice=voice, reference_audio_path=None)
        result = engine.synthesize("hello there", settings)
        try:
            assert result.samples_path.exists()
            assert result.engine == "chatterbox"
            assert captured_requests[0]["text"] == "hello there"
            assert captured_requests[0]["reference_audio_path"] is None
            assert captured_requests[0]["voice_id"] == "nano"
            assert captured_requests[0]["cmd"] == "synthesize"
        finally:
            result.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_with_reference_clip_passes_its_path_through():
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    captured_requests = []

    def handler(request):
        captured_requests.append(request)
        return _writes_wav_and_succeeds(request)

    popen_factory = _PopenFactory(handler=handler)
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as ref:
            ref.write(b"not a real wav, just needs to exist")
            ref_path = Path(ref.name)
        try:
            settings = SynthesisSettings(voice=voice, reference_audio_path=ref_path)
            result = engine.synthesize("clone my voice", settings)
            try:
                assert captured_requests[0]["reference_audio_path"] == str(ref_path)
            finally:
                result.samples_path.unlink(missing_ok=True)
        finally:
            ref_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_request_includes_native_sampling_fields():
    """The request dict crossing into the worker process always carries
    all seven native-control fields (see chatterbox_engine.py's
    synthesize() comment on why: it's the worker's _handle_synthesize()
    that's the authoritative tier-gate on which of these actually reach
    model.generate(), not this dict's shape)."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    captured_requests = []

    def handler(request):
        captured_requests.append(request)
        return _writes_wav_and_succeeds(request)

    popen_factory = _PopenFactory(handler=handler)
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]  # "nano"
        settings = SynthesisSettings(
            voice=voice, exaggeration=0.7, cfg_weight=0.3, temperature=0.9,
            repetition_penalty=1.3, min_p=0.1, top_p=0.9, top_k=500,
        )
        result = engine.synthesize("hello there", settings)
        try:
            request = captured_requests[0]
            assert request["exaggeration"] == 0.7
            assert request["cfg_weight"] == 0.3
            assert request["temperature"] == 0.9
            assert request["repetition_penalty"] == 1.3
            assert request["min_p"] == 0.1
            assert request["top_p"] == 0.9
            assert request["top_k"] == 500
        finally:
            result.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_uses_the_selected_model_tier():
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    captured_requests = []

    def handler(request):
        captured_requests.append(request)
        return _writes_wav_and_succeeds(request)

    popen_factory = _PopenFactory(handler=handler)
    try:
        engine = ChatterboxTTSEngine()
        voices = {v.id: v for v in engine.available_voices()}
        settings = SynthesisSettings(voice=voices["original"])
        result = engine.synthesize("highest quality please", settings)
        try:
            assert captured_requests[0]["voice_id"] == "original"
        finally:
            result.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_raises_when_reference_clip_is_missing():
    env = _FakeEnv(exists=True)
    popen_factory = _PopenFactory(handler=lambda request: (_ for _ in ()).throw(
        AssertionError("the Chatterbox worker must not run when the reference clip is missing")
    ))
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        missing = Path(tempfile.gettempdir()) / "definitely_not_a_real_reference_clip.wav"
        settings = SynthesisSettings(voice=voice, reference_audio_path=missing)
        try:
            engine.synthesize("text", settings)
            assert False, "expected SynthesisFailedError"
        except SynthesisFailedError:
            pass
    finally:
        popen_factory.close()
        env.close()


def test_synthesize_raises_on_worker_error_response():
    env = _FakeEnv(exists=True)
    popen_factory = _PopenFactory(handler=lambda request: {"ok": False, "error": "model failed to load"})
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)
        try:
            engine.synthesize("text", settings)
            assert False, "expected SynthesisFailedError"
        except SynthesisFailedError as exc:
            assert "model failed to load" in str(exc)
    finally:
        popen_factory.close()
        env.close()


def test_synthesize_raises_when_process_dies_without_responding():
    """Simulates the worker crashing mid-request (EOF on stdout with no
    response line) -- chatterbox_engine.py must surface this clearly and
    tear down the dead process rather than hang or silently succeed."""
    env = _FakeEnv(exists=True)

    class _DyingProcess(_FakeProcess):
        def _on_stdin_write(self, text):
            self.stderr.push_line("Traceback (most recent call last):\nRuntimeError: worker crashed\n")
            self.stderr.close()
            self._returncode = 1
            self.stdout.close()  # deliberately no response line -- EOF

    popen_factory = _PopenFactory(process_factory=lambda: _DyingProcess(_writes_wav_and_succeeds))
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        settings = SynthesisSettings(voice=voice)
        try:
            engine.synthesize("text", settings)
            assert False, "expected SynthesisFailedError"
        except SynthesisFailedError as exc:
            assert "worker crashed" in str(exc)
    finally:
        popen_factory.close()
        env.close()


def test_synthesize_applies_volume_gain():
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    try:
        import numpy as np
        import soundfile as sf

        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]

        result_quiet = engine.synthesize("gain test", SynthesisSettings(voice=voice, volume=1.0))
        result_loud = engine.synthesize("gain test", SynthesisSettings(voice=voice, volume=1.5))
        try:
            quiet_samples, _ = sf.read(str(result_quiet.samples_path))
            loud_samples, _ = sf.read(str(result_loud.samples_path))
            assert np.abs(loud_samples).max() > np.abs(quiet_samples).max()
        finally:
            result_quiet.samples_path.unlink(missing_ok=True)
            result_loud.samples_path.unlink(missing_ok=True)
    finally:
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_synthesize_calls_apply_speed_and_pitch_with_settings_values():
    """V4 follow-up #2: confirms synthesize() actually forwards
    settings.speed/pitch_semitones into _apply_speed_and_pitch() --
    that function's own real-ffmpeg DSP behavior is exercised separately
    in test_chatterbox_speed_pitch_dsp_v4.py, deliberately NOT re-tested
    here: doing so would need the fake worker's output file (written via
    this file's own custom fake-soundfile format -- see this file's
    module docstring) to also be a real, ffmpeg-parseable WAV, which the
    two fakes aren't compatible with. Monkeypatching the call instead
    proves the wiring without needing to reconcile that."""
    env = _FakeEnv(exists=True)
    _install_fake_soundfile()
    popen_factory = _PopenFactory()
    calls = []
    original = chatterbox_engine._apply_speed_and_pitch
    chatterbox_engine._apply_speed_and_pitch = lambda path, speed, pitch: calls.append((speed, pitch))
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        engine.synthesize(
            "speed/pitch wiring test", SynthesisSettings(voice=voice, speed=1.25, pitch_semitones=-2.0)
        )
        assert calls == [(1.25, -2.0)]
    finally:
        chatterbox_engine._apply_speed_and_pitch = original
        popen_factory.close()
        _remove_fake_soundfile()
        env.close()


def test_estimate_duration_factors_in_speed():
    """Matches the pattern piper_engine.py/kokoro_engine.py already use
    for their own estimate_duration() -- a rough placeholder, but one
    that at least moves in the right direction once Speed is a real
    control rather than always a no-op 1.0x."""
    env = _FakeEnv(exists=True)
    try:
        engine = ChatterboxTTSEngine()
        voice = engine.available_voices()[0]
        normal = engine.estimate_duration("ten short words here to estimate duration for", SynthesisSettings(voice=voice, speed=1.0))
        faster = engine.estimate_duration(
            "ten short words here to estimate duration for", SynthesisSettings(voice=voice, speed=2.0)
        )
        assert faster < normal
    finally:
        env.close()


if __name__ == "__main__":
    test_is_available_false_when_environment_missing()
    test_is_available_true_when_environment_and_package_both_present()
    test_is_available_false_when_environment_exists_but_package_missing()
    test_is_available_false_on_a_partial_install_missing_one_dependency()
    test_available_voices_exposes_three_model_tiers_nano_first()
    test_available_voices_sets_tier_specific_native_control_flags()
    test_available_voices_sets_speed_and_pitch_capability_and_ranges()
    test_synthesize_raises_engine_unavailable_when_environment_missing()
    test_worker_process_is_started_once_and_reused_across_calls()
    test_warmup_notice_is_shown_before_first_synthesize_and_cleared_after()
    test_warmup_notice_reappears_after_switching_model_tier()
    test_warmup_notice_reappears_after_shutdown()
    test_shutdown_then_synthesize_starts_a_fresh_process()
    test_synthesize_without_reference_builds_null_request()
    test_synthesize_with_reference_clip_passes_its_path_through()
    test_synthesize_request_includes_native_sampling_fields()
    test_synthesize_uses_the_selected_model_tier()
    test_synthesize_raises_when_reference_clip_is_missing()
    test_synthesize_raises_on_worker_error_response()
    test_synthesize_raises_when_process_dies_without_responding()
    test_synthesize_applies_volume_gain()
    test_synthesize_calls_apply_speed_and_pitch_with_settings_values()
    test_estimate_duration_factors_in_speed()
    print("All Chatterbox V4 engine tests passed.")
