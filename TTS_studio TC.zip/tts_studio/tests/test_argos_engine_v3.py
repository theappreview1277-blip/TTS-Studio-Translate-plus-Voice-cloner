"""V3: exercise ArgosTranslationEngine's new package-management methods
(installed_packages/available_packages/install_package/has_translation)
against fake `argostranslate.package`/`argostranslate.translate` modules
injected into sys.modules -- argostranslate itself isn't installable in
this sandbox (see ARCHITECTURE.md's closing risk note), but this still
verifies this app's own glue code: the filtering (`type == "translate"`,
skipping e.g. STT/TTS-type packages Argos's index can also list), the
sorting, and the not-found error path -- not argostranslate's own
internals, which are out of scope for this app to re-test."""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class _FakePackage:
    def __init__(self, from_code, from_name, to_code, to_name, pkg_type="translate"):
        self.from_code = from_code
        self.from_name = from_name
        self.to_code = to_code
        self.to_name = to_name
        self.type = pkg_type
        self.installed = False

    def install(self):
        self.installed = True


def _install_fake_argostranslate_modules():
    installed_packages = [_FakePackage("en", "English", "es", "Spanish")]
    available_packages = [
        _FakePackage("en", "English", "es", "Spanish"),
        _FakePackage("en", "English", "fr", "French"),
        _FakePackage("en", "English", "de", "German", pkg_type="stt"),  # must be filtered out
    ]

    fake_package_module = types.ModuleType("argostranslate.package")
    fake_package_module.get_installed_packages = lambda: installed_packages
    fake_package_module.get_available_packages = lambda: available_packages
    fake_package_module.update_package_index = lambda: None

    class _FakeLang:
        def __init__(self, code):
            self.code = code

        def get_translation(self, target):
            return object() if self.code == "en" and target.code == "es" else None

    fake_translate_module = types.ModuleType("argostranslate.translate")
    fake_translate_module.get_installed_languages = lambda: [_FakeLang("en"), _FakeLang("es")]

    fake_argostranslate_pkg = types.ModuleType("argostranslate")
    fake_argostranslate_pkg.package = fake_package_module
    fake_argostranslate_pkg.translate = fake_translate_module

    sys.modules["argostranslate"] = fake_argostranslate_pkg
    sys.modules["argostranslate.package"] = fake_package_module
    sys.modules["argostranslate.translate"] = fake_translate_module
    return available_packages


def test_available_packages_filters_non_translate_types_and_sorts():
    _install_fake_argostranslate_modules()
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    packages = engine.available_packages(refresh=True)
    assert len(packages) == 2  # the "stt" one must be excluded
    assert [p["to_code"] for p in packages] == ["fr", "es"]  # sorted by to_name: French before Spanish


def test_installed_packages_reflects_only_installed():
    _install_fake_argostranslate_modules()
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    installed = engine.installed_packages()
    assert len(installed) == 1
    assert installed[0]["from_code"] == "en" and installed[0]["to_code"] == "es"


def test_has_translation_true_for_installed_pair_false_otherwise():
    _install_fake_argostranslate_modules()
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    assert engine.has_translation("en", "es") is True
    assert engine.has_translation("en", "fr") is False
    assert engine.has_translation("en", "en") is True  # same-language shortcut, no lookup needed


def test_install_package_calls_install_on_the_matching_package():
    available = _install_fake_argostranslate_modules()
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    engine.install_package("en", "fr")
    fr_package = next(p for p in available if p.to_code == "fr")
    assert fr_package.installed is True


def test_install_package_raises_unsupported_language_when_no_match():
    _install_fake_argostranslate_modules()
    from tts_studio.core.exceptions import UnsupportedLanguageError
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    try:
        engine.install_package("en", "zh")
        assert False, "expected UnsupportedLanguageError"
    except UnsupportedLanguageError:
        pass


if __name__ == "__main__":
    test_available_packages_filters_non_translate_types_and_sorts()
    test_installed_packages_reflects_only_installed()
    test_has_translation_true_for_installed_pair_false_otherwise()
    test_install_package_calls_install_on_the_matching_package()
    test_install_package_raises_unsupported_language_when_no_match()
    print("All Argos V3 engine tests passed.")
