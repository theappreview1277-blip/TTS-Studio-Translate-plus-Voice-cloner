"""Tests for the removal side of the Download Manager: uninstalling an
Argos package, deleting a Piper voice's local files, and deleting the
Kokoro voice pack. Added alongside the "Remove Selected"/"Remove Voice
Pack" buttons so package/voice management isn't install-only."""
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tts_studio.core.exceptions import ResourceRemovalError, UnsupportedLanguageError
from tts_studio.engines.tts.kokoro_engine import KokoroTTSEngine, MODEL_FILENAME, VOICES_FILENAME
from tts_studio.engines.tts.piper_engine import PiperTTSEngine


# -- Argos ------------------------------------------------------------------
class _FakePackage:
    def __init__(self, from_code, to_code, pkg_type="translate"):
        self.from_code = from_code
        self.from_name = from_code
        self.to_code = to_code
        self.to_name = to_code
        self.type = pkg_type
        self.uninstalled = False


def _install_fake_argostranslate(installed_packages):
    fake_package_module = types.ModuleType("argostranslate.package")
    fake_package_module.get_installed_packages = lambda: installed_packages

    def _uninstall(pkg):
        pkg.uninstalled = True
        installed_packages.remove(pkg)

    fake_package_module.uninstall = _uninstall

    fake_argostranslate_pkg = types.ModuleType("argostranslate")
    fake_argostranslate_pkg.package = fake_package_module
    sys.modules["argostranslate"] = fake_argostranslate_pkg
    sys.modules["argostranslate.package"] = fake_package_module


def test_uninstall_package_removes_matching_package():
    packages = [_FakePackage("en", "es"), _FakePackage("en", "fr")]
    _install_fake_argostranslate(packages)
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    engine.uninstall_package("en", "es")
    assert len(packages) == 1
    assert packages[0].to_code == "fr"


def test_uninstall_package_raises_when_not_installed():
    packages = [_FakePackage("en", "es")]
    _install_fake_argostranslate(packages)
    from tts_studio.engines.translation.argos_engine import ArgosTranslationEngine

    engine = ArgosTranslationEngine()
    try:
        engine.uninstall_package("en", "de")
        assert False, "expected UnsupportedLanguageError"
    except UnsupportedLanguageError:
        pass


# -- Piper --------------------------------------------------------------
def test_remove_voice_deletes_both_files():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        voices_dir = Path(tmp)
        (voices_dir / "en_US-lessac-medium.onnx").write_bytes(b"model")
        (voices_dir / "en_US-lessac-medium.onnx.json").write_text("{}")
        engine = PiperTTSEngine(voices_dir=voices_dir)

        engine.remove_voice("en_US-lessac-medium")

        assert not (voices_dir / "en_US-lessac-medium.onnx").exists()
        assert not (voices_dir / "en_US-lessac-medium.onnx.json").exists()


def test_remove_voice_raises_when_not_installed():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        engine = PiperTTSEngine(voices_dir=Path(tmp))
        try:
            engine.remove_voice("nonexistent-voice")
            assert False, "expected ResourceRemovalError"
        except ResourceRemovalError:
            pass


def test_remove_voice_cleans_up_half_installed_pair():
    """Only the .onnx file exists (interrupted download) -- remove_voice
    should still succeed and clean it up, not refuse because the .json
    companion is missing."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        voices_dir = Path(tmp)
        (voices_dir / "broken-voice.onnx").write_bytes(b"partial")
        engine = PiperTTSEngine(voices_dir=voices_dir)
        engine.remove_voice("broken-voice")
        assert not (voices_dir / "broken-voice.onnx").exists()


# -- Kokoro -------------------------------------------------------------
def test_remove_voice_pack_deletes_both_files():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        voices_dir = Path(tmp)
        (voices_dir / MODEL_FILENAME).write_bytes(b"model")
        (voices_dir / VOICES_FILENAME).write_bytes(b"voices")
        engine = KokoroTTSEngine(voices_dir=voices_dir)

        engine.remove_voice_pack()

        assert not (voices_dir / MODEL_FILENAME).exists()
        assert not (voices_dir / VOICES_FILENAME).exists()
        assert engine.voice_pack_status() == "Not installed"


def test_remove_voice_pack_raises_when_not_installed():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        engine = KokoroTTSEngine(voices_dir=Path(tmp))
        try:
            engine.remove_voice_pack()
            assert False, "expected ResourceRemovalError"
        except ResourceRemovalError:
            pass


if __name__ == "__main__":
    test_uninstall_package_removes_matching_package()
    test_uninstall_package_raises_when_not_installed()
    test_remove_voice_deletes_both_files()
    test_remove_voice_raises_when_not_installed()
    test_remove_voice_cleans_up_half_installed_pair()
    test_remove_voice_pack_deletes_both_files()
    test_remove_voice_pack_raises_when_not_installed()
    print("All resource-removal tests passed.")
