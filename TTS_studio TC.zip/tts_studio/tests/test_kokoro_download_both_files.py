"""
V3 regression test: this is the exact bug found in a third-party fork of
this codebase during review -- its download_voice_pack() only fetched
voices-v1.0.bin and left kokoro-v1.0.onnx missing, so the button reported
success while synthesize() still raised ModelNotFoundError afterward.
This test runs a real local HTTP server (stdlib only, no network needed)
and asserts BOTH files land on disk after one download_voice_pack() call.
"""
import http.server
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import tts_studio.engines.tts.kokoro_engine as kokoro_engine
from tts_studio.engines.tts.kokoro_engine import KokoroTTSEngine, MODEL_FILENAME, VOICES_FILENAME


def _serve_dummy_files(directory: Path):
    (directory / MODEL_FILENAME).write_bytes(b"dummy onnx model bytes")
    (directory / VOICES_FILENAME).write_bytes(b"dummy voice pack bytes")

    handler_cls = lambda *args, **kwargs: http.server.SimpleHTTPRequestHandler(
        *args, directory=str(directory), **kwargs
    )
    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def test_download_voice_pack_fetches_both_files():
    with tempfile.TemporaryDirectory() as source_dir, tempfile.TemporaryDirectory() as dest_dir:
        server = _serve_dummy_files(Path(source_dir))
        try:
            port = server.server_address[1]
            original_base_url = kokoro_engine._RELEASE_BASE_URL
            kokoro_engine._RELEASE_BASE_URL = f"http://127.0.0.1:{port}"
            try:
                engine = KokoroTTSEngine(voices_dir=Path(dest_dir))
                assert engine.voice_pack_status() == "Not installed"
                engine.download_voice_pack()
                assert (Path(dest_dir) / MODEL_FILENAME).exists(), "model file was not downloaded"
                assert (Path(dest_dir) / VOICES_FILENAME).exists(), "voices file was not downloaded"
                assert (Path(dest_dir) / MODEL_FILENAME).read_bytes() == b"dummy onnx model bytes"
                assert (Path(dest_dir) / VOICES_FILENAME).read_bytes() == b"dummy voice pack bytes"
                # No leftover .part files from the atomic-rename download.
                assert not list(Path(dest_dir).glob("*.part"))
            finally:
                kokoro_engine._RELEASE_BASE_URL = original_base_url
        finally:
            server.shutdown()


def test_download_voice_pack_skips_files_already_present():
    """If the model file already exists (e.g. from the manual curl steps
    in README.md) but the voices file doesn't, only the missing one
    should be fetched -- and an unreachable server for the *other* file
    should never be hit."""
    with tempfile.TemporaryDirectory() as source_dir, tempfile.TemporaryDirectory() as dest_dir:
        server = _serve_dummy_files(Path(source_dir))
        try:
            port = server.server_address[1]
            original_base_url = kokoro_engine._RELEASE_BASE_URL
            kokoro_engine._RELEASE_BASE_URL = f"http://127.0.0.1:{port}"
            try:
                dest = Path(dest_dir)
                dest.mkdir(exist_ok=True)
                (dest / MODEL_FILENAME).write_bytes(b"already have this one")
                engine = KokoroTTSEngine(voices_dir=dest)
                engine.download_voice_pack()
                # The pre-existing model file must be left untouched.
                assert (dest / MODEL_FILENAME).read_bytes() == b"already have this one"
                assert (dest / VOICES_FILENAME).read_bytes() == b"dummy voice pack bytes"
            finally:
                kokoro_engine._RELEASE_BASE_URL = original_base_url
        finally:
            server.shutdown()


if __name__ == "__main__":
    test_download_voice_pack_fetches_both_files()
    test_download_voice_pack_skips_files_already_present()
    print("All Kokoro download_voice_pack tests passed.")
