"""V4: exercise _chatterbox_worker.py's own pure-Python logic.

Unlike chatterbox_engine.py (tested in test_chatterbox_engine_v4.py by
faking subprocess.Popen), this file has NO tts_studio imports at all --
it's the script that actually runs inside `.venv-chatterbox`, with
torch/chatterbox-tts/perth as its only real dependencies. Neither is
installable in this sandbox, so:

- Pure logic with no such dependency (the CPU map_location patch, the
  friendly-error categorization, the JSON-lines framing) is tested
  directly against the real module, imported by adding its directory to
  sys.path (it's a standalone script, not a package member, hence the
  leading underscore keeping it out of normal import paths).
- `_load_model`'s tier-selection and nano-fallback logic is tested
  against fake `chatterbox.tts`/`chatterbox.tts_turbo`/`perth` modules
  injected into sys.modules, verifying this file's own control flow
  (which class, which kwargs, the retry-without-nano behaviour) without
  needing the real packages.
- The JSON-lines protocol itself (including the OS-level stdout
  hijack in `_stdout_seized_for_protocol`) is exercised by running the
  REAL worker script as a REAL subprocess, under this sandbox's plain
  python3 (which lacks torch/chatterbox-tts) -- so the expected result
  is a clean `{"ok": false, "error": ...}` response, not a successful
  synthesis, but that failure still has to travel through the exact
  same protocol framing a real success would. This is the one test in
  this file that isn't mocked at all.
"""
import io
import json
import os
import subprocess
import sys
import types
from pathlib import Path

_WORKER_DIR = Path(__file__).resolve().parents[1] / "tts_studio" / "engines" / "tts"
_WORKER_PATH = _WORKER_DIR / "_chatterbox_worker.py"
sys.path.insert(0, str(_WORKER_DIR))

import _chatterbox_worker as worker  # noqa: E402 - path insert must come first


# -- _patch_torch_load_for_cpu_safety -----------------------------------

class _FakeTorchModule:
    def __init__(self):
        self.load_calls = []

    def load(self, *args, **kwargs):
        self.load_calls.append((args, kwargs))
        return "loaded"

    def device(self, name):
        return f"device({name})"


def test_cpu_patch_injects_map_location_on_cpu():
    torch_module = _FakeTorchModule()
    worker._patch_torch_load_for_cpu_safety(torch_module, "cpu")
    torch_module.load("ckpt.pt")
    assert torch_module.load_calls[-1][1] == {"map_location": "device(cpu)"}


def test_cpu_patch_is_a_noop_on_cuda():
    # Bound methods aren't cached (torch_module.load is torch_module.load
    # is always False even unpatched), so identity can't be the check --
    # instead confirm no map_location got injected, i.e. the patch never
    # replaced the attribute at all.
    torch_module = _FakeTorchModule()
    worker._patch_torch_load_for_cpu_safety(torch_module, "cuda")
    torch_module.load("ckpt.pt")
    assert torch_module.load_calls[-1][1] == {}


def test_cpu_patch_does_not_override_an_explicit_map_location():
    torch_module = _FakeTorchModule()
    worker._patch_torch_load_for_cpu_safety(torch_module, "cpu")
    torch_module.load("ckpt.pt", map_location="device(explicit)")
    assert torch_module.load_calls[-1][1]["map_location"] == "device(explicit)"


def test_cpu_patch_does_not_stack_wrappers_on_repeated_calls():
    """Real bug from code review: _load_model() re-runs this patch every
    time the selected tier changes in the same long-running persistent
    worker (nano -> turbo -> original, etc.), and without a guard each
    call would wrap the previous wrapper in yet another layer -- still
    functionally correct, but a pointlessly growing call stack. The
    marker attribute makes a second call a real no-op: confirmed here by
    checking `torch.load`'s identity is unchanged after a second patch
    call (bound-method identity doesn't apply here since `_cpu_safe_load`
    is a plain function assigned as an attribute, not a bound method, so
    this identity check is meaningful, unlike the pitfall noted in
    test_cpu_patch_is_a_noop_on_cuda)."""
    torch_module = _FakeTorchModule()
    worker._patch_torch_load_for_cpu_safety(torch_module, "cpu")
    first_patched_load = torch_module.load
    worker._patch_torch_load_for_cpu_safety(torch_module, "cpu")
    assert torch_module.load is first_patched_load, "expected the second call to be a no-op"
    torch_module.load("ckpt.pt")
    assert torch_module.load_calls[-1][1] == {"map_location": "device(cpu)"}, "single wrapper must still work correctly"


# -- _check_perth_watermarker --------------------------------------------

def test_check_perth_watermarker_raises_when_none():
    fake_perth = types.ModuleType("perth")
    fake_perth.PerthImplicitWatermarker = None
    sys.modules["perth"] = fake_perth
    try:
        try:
            worker._check_perth_watermarker()
            assert False, "expected RuntimeError"
        except RuntimeError as exc:
            assert "setuptools" in str(exc)
    finally:
        sys.modules.pop("perth", None)


def test_check_perth_watermarker_passes_when_real_class():
    fake_perth = types.ModuleType("perth")
    fake_perth.PerthImplicitWatermarker = object
    sys.modules["perth"] = fake_perth
    try:
        worker._check_perth_watermarker()  # must not raise
    finally:
        sys.modules.pop("perth", None)


# -- _friendly_detail ------------------------------------------------------

def test_friendly_detail_categorizes_cuda_deserialization():
    exc = RuntimeError("Attempting to deserialize object on a CUDA device but torch.cuda.is_available() is False.")
    assert "GPU" in worker._friendly_detail(exc)


def test_friendly_detail_categorizes_network_failure():
    exc = Exception("huggingface_hub.utils._errors.LocalEntryNotFoundError: Connection error")
    detail = worker._friendly_detail(exc)
    assert "network" in detail.lower() or "Hugging Face" in detail


def test_friendly_detail_categorizes_perth_setuptools_issue():
    exc = TypeError("'NoneType' object is not callable")
    assert "setuptools" in worker._friendly_detail(exc)


def test_friendly_detail_falls_back_for_unknown_errors():
    assert "unexpected" in worker._friendly_detail(Exception("something else entirely")).lower()


# -- _load_model: tier selection and the nano= fallback -------------------

def _reset_model_cache() -> None:
    """_MODEL_CACHE is module-level global state in the real worker
    script, so every test that touches _load_model() needs to reset it
    both before (in case a previous test in the same process left it
    populated) and after (so it doesn't leak into whatever runs next) --
    all five keys, including the reference-conditional-caching ones
    added alongside default_conds/prepared_reference_audio_path, not
    just the original three."""
    worker._MODEL_CACHE.update(
        {
            "voice_id": None,
            "device": None,
            "model": None,
            "default_conds": None,
            "prepared_reference_audio_path": None,
        }
    )


class _FakeModel:
    def __init__(self, tag):
        self.tag = tag
        # A real chatterbox model always has *some* self.conds right
        # after from_pretrained() -- either its built-in voice, loaded
        # from conds.pt, or None if that file wasn't shipped (see
        # _chatterbox_worker.py's docstring, "Reference-conditional
        # caching"). A distinct, recognizable-per-instance sentinel
        # string (not None) lets tests tell "still on this model's own
        # default" apart from "actually got reset to None somehow" --
        # see test_load_model_stashes_the_freshly_loaded_models_own_conds_
        # as_the_default() below.
        self.conds = f"default-conds-{tag}-{id(self)}"


class _FakeChatterboxTTS:
    calls = []

    @classmethod
    def from_pretrained(cls, device):
        cls.calls.append({"device": device})
        return _FakeModel("original")


def _install_fake_chatterbox_modules(turbo_from_pretrained):
    fake_torch = types.ModuleType("torch")
    fake_torch.load = lambda *a, **k: None
    fake_torch.device = lambda name: f"device({name})"
    # Matches real torch's actual shape, not a convenience shortcut: a
    # real torch install always exposes `torch.cuda`, even a CPU-only
    # build (`is_available()` is just False) -- _release_cached_model()
    # calls this unconditionally, same as production code would against
    # the real package.
    fake_cuda = types.ModuleType("torch.cuda")
    fake_cuda.is_available = lambda: False
    fake_cuda.empty_cache = lambda: None
    fake_torch.cuda = fake_cuda
    sys.modules["torch"] = fake_torch

    fake_perth = types.ModuleType("perth")
    fake_perth.PerthImplicitWatermarker = object
    sys.modules["perth"] = fake_perth

    fake_chatterbox = types.ModuleType("chatterbox")
    fake_tts = types.ModuleType("chatterbox.tts")
    _FakeChatterboxTTS.calls = []
    fake_tts.ChatterboxTTS = _FakeChatterboxTTS
    fake_tts_turbo = types.ModuleType("chatterbox.tts_turbo")

    class _FakeChatterboxTurboTTS:
        calls = []
        from_pretrained = staticmethod(turbo_from_pretrained)

    fake_tts_turbo.ChatterboxTurboTTS = _FakeChatterboxTurboTTS

    sys.modules["chatterbox"] = fake_chatterbox
    sys.modules["chatterbox.tts"] = fake_tts
    sys.modules["chatterbox.tts_turbo"] = fake_tts_turbo

    # Real hermeticity bug, found in review: `_load_model()` calls
    # `_check_pkg_resources_available()` for real (it isn't mocked
    # anywhere else), which does a genuine `import pkg_resources`. An
    # earlier version of this fixture relied on the AMBIENT
    # test-running interpreter happening to have real setuptools
    # installed for that import to succeed -- true in this sandbox, but
    # not guaranteed anywhere else (a bare Python 3.12+ install without
    # setuptools bundled is exactly the bug the rest of this project
    # fixes for `.venv-chatterbox`, and nothing stops the same gap
    # existing in whatever interpreter happens to run this test suite).
    # A previous reviewer hit exactly that: these tests failed on their
    # machine because pkg_resources genuinely wasn't importable there.
    # Injecting a fake module here, the same way torch/perth/chatterbox
    # are faked, makes this deterministic regardless of the ambient
    # interpreter's own setuptools status.
    sys.modules["pkg_resources"] = types.ModuleType("pkg_resources")

    return _FakeChatterboxTurboTTS


def _remove_fake_chatterbox_modules():
    for name in ("torch", "perth", "chatterbox", "chatterbox.tts", "chatterbox.tts_turbo", "pkg_resources"):
        sys.modules.pop(name, None)


def test_load_model_original_tier_uses_chatterbox_tts():
    _install_fake_chatterbox_modules(lambda device, nano=False: _FakeModel(f"turbo(nano={nano})"))
    _reset_model_cache()
    try:
        model = worker._load_model("original", "cpu")
        assert model.tag == "original"
        assert _FakeChatterboxTTS.calls == [{"device": "cpu"}]
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_nano_and_turbo_pass_the_right_nano_flag():
    calls = []

    def fake_from_pretrained(device, nano=False):
        calls.append({"device": device, "nano": nano})
        return _FakeModel(f"turbo(nano={nano})")

    _install_fake_chatterbox_modules(fake_from_pretrained)
    _reset_model_cache()
    try:
        nano_model = worker._load_model("nano", "cpu")
        turbo_model = worker._load_model("turbo", "cpu")
        assert nano_model.tag == "turbo(nano=True)"
        assert turbo_model.tag == "turbo(nano=False)"
        assert calls == [{"device": "cpu", "nano": True}, {"device": "cpu", "nano": False}]
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_retries_without_nano_kwarg_on_typeerror():
    """Real, observed discrepancy (see module docstring): upstream's docs
    and examples show a `nano=` kwarg that a direct source read of
    tts_turbo.py didn't show at all. This is the fallback for a
    chatterbox-tts release that genuinely doesn't accept it."""
    calls = []

    def fake_from_pretrained(device, nano=None):
        if nano is not None:
            raise TypeError("from_pretrained() got an unexpected keyword argument 'nano'")
        calls.append({"device": device})
        return _FakeModel("turbo-no-nano-support")

    _install_fake_chatterbox_modules(fake_from_pretrained)
    _reset_model_cache()
    try:
        model = worker._load_model("nano", "cpu")
        assert model.tag == "turbo-no-nano-support"
        assert calls == [{"device": "cpu"}]
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_caches_and_only_reloads_on_tier_change():
    calls = []
    _install_fake_chatterbox_modules(lambda device, nano=False: calls.append((device, nano)) or _FakeModel("t"))
    _reset_model_cache()
    try:
        first = worker._load_model("nano", "cpu")
        second = worker._load_model("nano", "cpu")  # same tier+device: must be cached, no new call
        assert first is second
        assert len(calls) == 1

        worker._load_model("turbo", "cpu")  # different tier: must reload
        assert len(calls) == 2
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_releases_old_model_before_loading_a_new_tier():
    """Real risk flagged in review: switching tiers used to just
    overwrite _MODEL_CACHE's dict entries, leaving the OLD model
    reachable until some later, unpredictable GC cycle -- on a
    memory-constrained machine, briefly holding two full models at once
    is a realistic way to hit an out-of-memory error. _release_cached_model()
    (called from _load_model before constructing the new model) must
    clear the cache, force a collection, and -- when CUDA is available --
    hand freed memory back via torch.cuda.empty_cache()."""
    _install_fake_chatterbox_modules(lambda device, nano=False: _FakeModel(f"t-{nano}"))
    _reset_model_cache()

    gc_calls = []
    original_gc_collect = worker.gc.collect
    worker.gc.collect = lambda: gc_calls.append(1)

    empty_cache_calls = []
    fake_torch = sys.modules["torch"]
    fake_torch.cuda.is_available = lambda: True
    fake_torch.cuda.empty_cache = lambda: empty_cache_calls.append(1)

    try:
        worker._load_model("nano", "cpu")
        assert gc_calls == [], "must not release anything before the very first model is loaded"
        assert empty_cache_calls == []

        worker._load_model("turbo", "cpu")  # tier switch -- must release the old model first
        assert gc_calls == [1]
        assert empty_cache_calls == [1], "CUDA available -> empty_cache() must be called on release"
    finally:
        worker.gc.collect = original_gc_collect
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_rejects_unknown_tier():
    _install_fake_chatterbox_modules(lambda device, nano=False: _FakeModel("t"))
    _reset_model_cache()
    try:
        try:
            worker._load_model("ultra-max", "cpu")
            assert False, "expected ValueError"
        except ValueError as exc:
            assert "ultra-max" in str(exc)
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_stashes_the_freshly_loaded_models_own_conds_as_the_default():
    """See _chatterbox_worker.py's module docstring, "Reference-
    conditional caching": _load_model() must capture a fresh model's own
    self.conds (its built-in voice) the moment it's constructed, since
    that's what a later _sync_reference_conditionals() call restores
    when reverting from a custom reference clip back to the default."""
    _install_fake_chatterbox_modules(lambda device, nano=False: _FakeModel(f"t-{nano}"))
    _reset_model_cache()
    try:
        model = worker._load_model("original", "cpu")
        assert worker._MODEL_CACHE["default_conds"] is model.conds
        assert worker._MODEL_CACHE["prepared_reference_audio_path"] is None
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


def test_load_model_stashes_a_fresh_default_conds_per_tier_switch():
    """Switching tiers constructs a genuinely new model with its own
    conds -- the stashed default must track whichever model is actually
    loaded right now, not linger from a previous tier."""
    _install_fake_chatterbox_modules(lambda device, nano=False: _FakeModel(f"turbo-{nano}"))
    _reset_model_cache()
    try:
        nano_model = worker._load_model("nano", "cpu")
        nano_default = worker._MODEL_CACHE["default_conds"]
        assert nano_default is nano_model.conds

        original_model = worker._load_model("original", "cpu")
        assert worker._MODEL_CACHE["default_conds"] is original_model.conds
        assert worker._MODEL_CACHE["default_conds"] is not nano_default
    finally:
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


# -- _sync_reference_conditionals (V4 follow-up: reference-conditional --
# -- caching) -------------------------------------------------------------

class _FakeModelWithConds:
    """A minimal stand-in for a real chatterbox model, just enough for
    _sync_reference_conditionals() -- which only ever reads/writes
    `.conds` -- to exercise without needing torch/chatterbox at all."""

    def __init__(self, conds):
        self.conds = conds


def test_sync_reference_conditionals_is_unchanged_from_the_default_is_a_no_op():
    """Common case: no reference ever requested, none prepared -- the
    most frequent call this function ever handles (every section of a
    project using a tier's own built-in voice)."""
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": None, "default_conds": "the-default"})
    model = _FakeModelWithConds("the-default")
    result = worker._sync_reference_conditionals(model, None)
    assert result is None
    assert model.conds == "the-default", "must not have touched conds at all"


def test_sync_reference_conditionals_prepares_a_new_reference_the_first_time():
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": None, "default_conds": "the-default"})
    model = _FakeModelWithConds("the-default")
    result = worker._sync_reference_conditionals(model, "voice_a.wav")
    assert result == "voice_a.wav", "must forward the path so generate() actually re-prepares"
    assert worker._MODEL_CACHE["prepared_reference_audio_path"] == "voice_a.wav"


def test_sync_reference_conditionals_reuses_conditionals_for_the_same_reference_twice():
    """The actual optimization: the second call with the identical
    reference clip must skip prepare_conditionals() entirely."""
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": "voice_a.wav", "default_conds": "the-default"})
    model = _FakeModelWithConds("prepared-for-voice_a")
    result = worker._sync_reference_conditionals(model, "voice_a.wav")
    assert result is None, "must NOT ask generate() to re-prepare an already-current reference"
    assert model.conds == "prepared-for-voice_a", "must not have touched already-correct conds"


def test_sync_reference_conditionals_reprepares_on_a_genuinely_different_reference():
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": "voice_a.wav", "default_conds": "the-default"})
    model = _FakeModelWithConds("prepared-for-voice_a")
    result = worker._sync_reference_conditionals(model, "voice_b.wav")
    assert result == "voice_b.wav"
    assert worker._MODEL_CACHE["prepared_reference_audio_path"] == "voice_b.wav"


def test_sync_reference_conditionals_reverts_to_the_built_in_voice_when_reference_cleared():
    """The real, separate bug this caching work surfaced and fixed as a
    side effect: previously, going back to "no reference" after a custom
    clone would NOT actually restore the built-in voice, because
    omitting audio_prompt_path just reuses self.conds unchanged. Here,
    model.conds must be explicitly reset to the stashed default."""
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": "voice_a.wav", "default_conds": "the-default"})
    model = _FakeModelWithConds("prepared-for-voice_a")
    result = worker._sync_reference_conditionals(model, None)
    assert result is None, "generate() must not be given a path in this branch"
    assert model.conds == "the-default", "must have restored the built-in default conditionals"
    assert worker._MODEL_CACHE["prepared_reference_audio_path"] is None


def test_sync_reference_conditionals_treats_empty_string_the_same_as_none():
    """A falsy-but-not-None reference_audio_path (an empty string, say,
    from a slightly different caller) must be treated identically to
    None -- both mean "no custom reference requested"."""
    worker._MODEL_CACHE.update({"prepared_reference_audio_path": "voice_a.wav", "default_conds": "the-default"})
    model = _FakeModelWithConds("prepared-for-voice_a")
    result = worker._sync_reference_conditionals(model, "")
    assert result is None
    assert model.conds == "the-default"


def test_handle_synthesize_only_passes_audio_prompt_path_on_the_first_of_two_identical_calls():
    """End-to-end confirmation that _handle_synthesize() actually wires
    _sync_reference_conditionals() in: two consecutive synthesize()
    calls with the same reference clip must only trigger a real
    prepare_conditionals()-equivalent (audio_prompt_path passed to
    generate()) once, not twice."""
    import tempfile

    class _RecordingModel:
        sr = 24000

        def __init__(self):
            self.generate_calls = []
            self.conds = "the-default"

        def generate(self, text, **kwargs):
            self.generate_calls.append(kwargs)
            if "audio_prompt_path" in kwargs:
                self.conds = f"prepared-for-{kwargs['audio_prompt_path']}"
            return "wav-data"

    model = _RecordingModel()
    _install_fake_chatterbox_modules(lambda device, nano=False: model)
    fake_ta = types.ModuleType("torchaudio")
    fake_ta.save = lambda path, wav, sr: None
    sys.modules["torchaudio"] = fake_ta
    _reset_model_cache()
    try:
        fd, output_path = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        try:
            request = {
                "text": "hello",
                "output_path": output_path,
                "reference_audio_path": "voice_a.wav",
                "voice_id": "turbo",
            }
            worker._handle_synthesize(request)
            worker._handle_synthesize(request)
            assert len(model.generate_calls) == 2
            assert model.generate_calls[0].get("audio_prompt_path") == "voice_a.wav"
            assert "audio_prompt_path" not in model.generate_calls[1], (
                "second call with the identical reference must skip re-preparing"
            )
        finally:
            Path(output_path).unlink(missing_ok=True)
    finally:
        sys.modules.pop("torchaudio", None)
        _remove_fake_chatterbox_modules()
        _reset_model_cache()


# -- _sampling_kwargs_for_tier / _handle_synthesize (native controls) ----

def test_sampling_kwargs_for_tier_original_includes_expression_and_min_p_but_not_top_k():
    request = {
        "exaggeration": 0.7, "cfg_weight": 0.3, "temperature": 0.9,
        "repetition_penalty": 1.3, "min_p": 0.1, "top_p": 0.9, "top_k": 500,
    }
    kwargs = worker._sampling_kwargs_for_tier("original", request)
    assert kwargs == {
        "temperature": 0.9, "repetition_penalty": 1.3, "top_p": 0.9,
        "exaggeration": 0.7, "cfg_weight": 0.3, "min_p": 0.1,
    }
    assert "top_k" not in kwargs  # Original's generate() has no such parameter -- would raise TypeError


def test_sampling_kwargs_for_tier_turbo_nano_includes_top_k_but_not_expression_or_min_p():
    request = {
        "exaggeration": 0.7, "cfg_weight": 0.3, "temperature": 0.9,
        "repetition_penalty": 1.3, "min_p": 0.1, "top_p": 0.9, "top_k": 500,
    }
    for voice_id in ("nano", "turbo"):
        kwargs = worker._sampling_kwargs_for_tier(voice_id, request)
        assert kwargs == {"temperature": 0.9, "repetition_penalty": 1.3, "top_p": 0.9, "top_k": 500}
        # Not TypeError-unsafe like top_k is for Original, but upstream's
        # own source warns these are ignored for Turbo/Nano -- left out
        # entirely rather than sent-but-pointless (and warning-printing).
        assert "exaggeration" not in kwargs
        assert "cfg_weight" not in kwargs
        assert "min_p" not in kwargs


def test_sampling_kwargs_for_tier_omits_fields_missing_from_the_request_rather_than_passing_none():
    # An older saved project (or any caller sending a partial request)
    # shouldn't result in `generate(temperature=None)`, which would raise
    # against the real upstream signature -- missing means "don't pass
    # this kwarg at all," not "pass it as None."
    kwargs = worker._sampling_kwargs_for_tier("original", {"temperature": 0.9})
    assert kwargs == {"temperature": 0.9}
    kwargs = worker._sampling_kwargs_for_tier("nano", {})
    assert kwargs == {}


def test_handle_synthesize_forwards_tier_appropriate_kwargs_to_generate():
    """End-to-end (with fake torch/chatterbox/torchaudio modules): makes
    sure _load_model's returned model and _sampling_kwargs_for_tier's
    output actually connect correctly inside _handle_synthesize, which
    the two functions' own separate unit tests can't catch on their own
    (e.g. a typo in a dict key that happens to match on both sides)."""
    import tempfile

    class _RecordingModel:
        sr = 24000

        def __init__(self):
            self.generate_calls = []
            # _load_model() now reads model.conds right after
            # construction (see _reset_model_cache()'s docstring) --
            # None is a legitimate real value here (a model whose
            # checkpoint didn't ship a conds.pt), and this test's own
            # request has no reference_audio_path, so
            # _sync_reference_conditionals() never touches it anyway.
            self.conds = None

        def generate(self, text, **kwargs):
            self.generate_calls.append((text, kwargs))
            return "wav-data"

    model = _RecordingModel()
    # "turbo"/"nano" go through ChatterboxTurboTTS.from_pretrained, which
    # _install_fake_chatterbox_modules lets this test control directly
    # (unlike "original", which always uses the fixed _FakeChatterboxTTS
    # class above) -- picking this tier here is just about reusing that
    # existing fixture cleanly, not about testing this tier specifically;
    # the exact per-tier kwargs are already covered precisely by the
    # _sampling_kwargs_for_tier unit tests above for both tiers.
    _install_fake_chatterbox_modules(lambda device, nano=False: model)
    fake_ta = types.ModuleType("torchaudio")
    save_calls = []
    fake_ta.save = lambda path, wav, sr: save_calls.append((path, wav, sr))
    sys.modules["torchaudio"] = fake_ta
    _reset_model_cache()
    try:
        fd, output_path = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        request = {
            "voice_id": "turbo",
            "text": "Hello there.",
            "output_path": output_path,
            "reference_audio_path": None,
            "exaggeration": 0.7,
            "cfg_weight": 0.3,
            "temperature": 0.9,
            "repetition_penalty": 1.3,
            "min_p": 0.1,
            "top_p": 0.9,
            "top_k": 500,
        }
        worker._handle_synthesize(request)
        assert len(model.generate_calls) == 1
        text, kwargs = model.generate_calls[0]
        assert text == "Hello there."
        assert kwargs == {"temperature": 0.9, "repetition_penalty": 1.3, "top_p": 0.9, "top_k": 500}
        assert "exaggeration" not in kwargs and "cfg_weight" not in kwargs and "min_p" not in kwargs
        assert save_calls == [(output_path, "wav-data", 24000)]
    finally:
        sys.modules.pop("torchaudio", None)
        _remove_fake_chatterbox_modules()
        _reset_model_cache()
        os.unlink(output_path)


# -- _download_all_tiers --------------------------------------------------

def _install_fake_huggingface_hub(*, nano_raises=False):
    fake_hub = types.ModuleType("huggingface_hub")
    hf_hub_download_calls = []
    snapshot_download_calls = []

    def fake_hf_hub_download(repo_id, filename):
        hf_hub_download_calls.append((repo_id, filename))

    def fake_snapshot_download(repo_id, allow_patterns=None):
        snapshot_download_calls.append(repo_id)
        if nano_raises and repo_id == worker._NANO_REPO_ID:
            raise RuntimeError("simulated: this repo doesn't exist under this name")

    fake_hub.hf_hub_download = fake_hf_hub_download
    fake_hub.snapshot_download = fake_snapshot_download
    sys.modules["huggingface_hub"] = fake_hub
    return hf_hub_download_calls, snapshot_download_calls


def _remove_fake_huggingface_hub():
    sys.modules.pop("huggingface_hub", None)


def test_download_all_tiers_fetches_nano_separately_from_turbo():
    """Real gap flagged in review: the installer's pre-download step only
    ever fetched _TURBO_REPO_ID, on the assumption that it covered both
    Turbo and Nano -- but ResembleAI/chatterbox-nano is a real, separate
    Hugging Face repo, so Nano's actual weights were never pre-fetched at
    all, meaning the first real Nano generation (Nano being this app's
    default tier) would silently need the network despite the installer
    reporting success. Fixed by fetching both repos; this confirms both
    calls actually happen."""
    hf_hub_calls, snapshot_calls = _install_fake_huggingface_hub()
    try:
        worker._download_all_tiers()
        assert (worker._ORIGINAL_REPO_ID, "ve.safetensors") in hf_hub_calls
        assert worker._TURBO_REPO_ID in snapshot_calls
        assert worker._NANO_REPO_ID in snapshot_calls
    finally:
        _remove_fake_huggingface_hub()


def test_download_all_tiers_survives_a_nano_repo_failure():
    """Non-fatal by design: if the Nano repo ever doesn't exist under
    this exact name (renamed, merged into Turbo's repo, etc. upstream),
    that must not take down Original/Turbo's own downloads with it --
    those are separately verified and already working."""
    hf_hub_calls, snapshot_calls = _install_fake_huggingface_hub(nano_raises=True)
    try:
        worker._download_all_tiers()  # must not raise
        assert worker._TURBO_REPO_ID in snapshot_calls
        assert worker._NANO_REPO_ID in snapshot_calls  # attempted, even though it failed
        assert len(hf_hub_calls) == len(worker._ORIGINAL_FILES)  # Original's own downloads still ran
    finally:
        _remove_fake_huggingface_hub()


# -- real subprocess: the JSON-lines protocol end to end -------------------

def test_persistent_loop_protocol_end_to_end_without_chatterbox_installed():
    """Runs the REAL worker script as a REAL subprocess (this sandbox's
    plain python3, which has neither torch nor chatterbox-tts) to prove
    the JSON-lines framing and the OS-level stdout hijack actually work,
    not just in theory. Chatterbox being unavailable here means the
    expected outcome is a clean {"ok": false, "error": ...} response
    instead of a successful synthesis -- still a fully valid protocol
    round-trip, which is what this test checks."""
    proc = subprocess.Popen(
        [sys.executable, str(_WORKER_PATH)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    try:
        request = {
            "cmd": "synthesize",
            "id": 1,
            "text": "hi",
            "output_path": "/tmp/does_not_matter.wav",
            "reference_audio_path": None,
            "voice_id": "nano",
        }
        proc.stdin.write(json.dumps(request) + "\n")
        proc.stdin.flush()
        line = proc.stdout.readline()
        assert line, "expected a JSON response line, got EOF -- the stdout protocol is likely broken"
        response = json.loads(line)  # raises if any stray non-JSON text leaked onto stdout
        assert response["id"] == 1
        assert response["ok"] is False
        assert "error" in response and response["error"]

        proc.stdin.write(json.dumps({"cmd": "shutdown", "id": 2}) + "\n")
        proc.stdin.flush()
        shutdown_line = proc.stdout.readline()
        shutdown_response = json.loads(shutdown_line)
        assert shutdown_response == {"id": 2, "ok": True}
        assert proc.wait(timeout=10) == 0
    finally:
        if proc.poll() is None:
            proc.kill()


def test_diagnose_cli_mode_produces_valid_json():
    """--diagnose is a one-shot mode (not the persistent loop) -- run for
    real against this sandbox's plain python3. Every dependency it
    checks is genuinely missing here, so this mainly proves the command
    doesn't crash and always emits one valid JSON object with the
    expected shape, whatever it finds."""
    result = subprocess.run(
        [sys.executable, str(_WORKER_PATH), "--diagnose"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    report = json.loads(result.stdout)
    for key in (
        "python_version",
        "chatterbox_version",
        "torch_version",
        "cuda_available",
        "setuptools_available",
        "setuptools_version",
        "perth_watermarker_ok",
        "cached_chatterbox_repos",
        "model_tier_tested",
        "test_generation",
    ):
        assert key in report
    assert report["test_generation"]["ok"] is False  # torch/chatterbox aren't installed here


def test_diagnose_cli_seizes_stdout_so_stray_prints_cant_corrupt_the_json():
    """Real bug, hit by a real user through the GUI's Diagnose button:
    `_diagnose()` loads an actual model and runs an actual test
    generation, and chatterbox's own library code prints plain progress
    text straight to stdout while doing that -- confirmed verbatim from a
    real report: "loaded PerthNet (Implicit) at step 250,000" and "S3
    Token -> Mel Inference..." showed up glued to the front of the JSON.
    `chatterbox_engine.py`'s `run_diagnostics()` does a plain
    `json.loads()` on this process's entire captured stdout, so that
    leading text broke parsing every time, surfacing as "Unreadable
    diagnostics output" in the GUI. `main()`'s --diagnose branch now
    wraps the whole call in `_stdout_seized_for_protocol()`, the same
    mechanism the persistent loop already relied on. This test proves
    that mechanism actually blocks stray prints in-process (faster and
    more precisely than another real subprocess run): redirect the real
    OS-level fd 1 to a pipe this test controls, monkeypatch `_diagnose`
    with a stand-in that prints extra lines before returning its report
    (standing in for chatterbox's own prints), run the real `main()`,
    and confirm only the final JSON ever reached the pipe."""
    read_fd, write_fd = os.pipe()
    saved_fd1 = os.dup(1)
    os.dup2(write_fd, 1)
    os.close(write_fd)

    original_diagnose = worker._diagnose

    def _fake_diagnose_with_stray_prints():
        print("loaded PerthNet (Implicit) at step 250,000")
        print("S3 Token -> Mel Inference...")
        return {"ok": True, "marker": "diagnose-ran"}

    worker._diagnose = _fake_diagnose_with_stray_prints
    try:
        worker.main(["_chatterbox_worker.py", "--diagnose"])
    finally:
        worker._diagnose = original_diagnose
        os.dup2(saved_fd1, 1)
        os.close(saved_fd1)

    os.set_blocking(read_fd, False)
    captured = b""
    try:
        while True:
            chunk = os.read(read_fd, 65536)
            if not chunk:
                break
            captured += chunk
    except BlockingIOError:
        pass
    os.close(read_fd)

    report = json.loads(captured.decode())  # raises if any stray text leaked through
    assert report == {"ok": True, "marker": "diagnose-ran"}


if __name__ == "__main__":
    test_cpu_patch_injects_map_location_on_cpu()
    test_cpu_patch_is_a_noop_on_cuda()
    test_cpu_patch_does_not_override_an_explicit_map_location()
    test_cpu_patch_does_not_stack_wrappers_on_repeated_calls()
    test_check_perth_watermarker_raises_when_none()
    test_check_perth_watermarker_passes_when_real_class()
    test_friendly_detail_categorizes_cuda_deserialization()
    test_friendly_detail_categorizes_network_failure()
    test_friendly_detail_categorizes_perth_setuptools_issue()
    test_friendly_detail_falls_back_for_unknown_errors()
    test_load_model_original_tier_uses_chatterbox_tts()
    test_load_model_nano_and_turbo_pass_the_right_nano_flag()
    test_load_model_retries_without_nano_kwarg_on_typeerror()
    test_load_model_caches_and_only_reloads_on_tier_change()
    test_load_model_releases_old_model_before_loading_a_new_tier()
    test_load_model_rejects_unknown_tier()
    test_load_model_stashes_the_freshly_loaded_models_own_conds_as_the_default()
    test_load_model_stashes_a_fresh_default_conds_per_tier_switch()
    test_sync_reference_conditionals_is_unchanged_from_the_default_is_a_no_op()
    test_sync_reference_conditionals_prepares_a_new_reference_the_first_time()
    test_sync_reference_conditionals_reuses_conditionals_for_the_same_reference_twice()
    test_sync_reference_conditionals_reprepares_on_a_genuinely_different_reference()
    test_sync_reference_conditionals_reverts_to_the_built_in_voice_when_reference_cleared()
    test_sync_reference_conditionals_treats_empty_string_the_same_as_none()
    test_handle_synthesize_only_passes_audio_prompt_path_on_the_first_of_two_identical_calls()
    test_sampling_kwargs_for_tier_original_includes_expression_and_min_p_but_not_top_k()
    test_sampling_kwargs_for_tier_turbo_nano_includes_top_k_but_not_expression_or_min_p()
    test_sampling_kwargs_for_tier_omits_fields_missing_from_the_request_rather_than_passing_none()
    test_handle_synthesize_forwards_tier_appropriate_kwargs_to_generate()
    test_download_all_tiers_fetches_nano_separately_from_turbo()
    test_download_all_tiers_survives_a_nano_repo_failure()
    test_persistent_loop_protocol_end_to_end_without_chatterbox_installed()
    test_diagnose_cli_mode_produces_valid_json()
    test_diagnose_cli_seizes_stdout_so_stray_prints_cant_corrupt_the_json()
    print("All Chatterbox V4 worker tests passed.")
