"""
V3: unit tests for Kokoro's character-preset voice blending, isolated
from the real `kokoro_onnx` package (not installable in this sandbox --
see ARCHITECTURE.md's closing risk note) via a small duck-typed fake that
implements only what `_character_voice` actually calls: get_voices() and
get_voice_style(). This tests the *blend math and candidate-selection
logic this app owns*, not kokoro_onnx itself -- the API shape it relies
on (create(voice=ndarray-or-str), get_voice_style()) was separately
verified against kokoro-onnx's real source (see ARCHITECTURE.md section I).
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tts_studio.engines.tts.kokoro_engine import KokoroTTSEngine, _CHARACTER_STYLES


class FakeKokoro:
    """Just enough of kokoro_onnx.Kokoro's surface for _character_voice."""

    def __init__(self, voice_ids):
        # Deterministic, GUARANTEED-distinct per-voice fill value (NOT
        # Python's hash() -- str hashing is randomized per-process by
        # default, which made an earlier version of this test flaky: two
        # different voice ids could coincidentally land on the same
        # value on some runs, making a real blend look like a no-op by
        # pure chance). Enumerate index is unique per voice by construction.
        self._styles = {
            voice_id: np.full((2, 3), fill_value=float(index + 1), dtype=np.float32)
            for index, voice_id in enumerate(voice_ids)
        }

    def get_voices(self):
        return list(self._styles.keys())

    def get_voice_style(self, voice_id):
        return self._styles[voice_id]


def test_neutral_preset_returns_primary_id_unchanged():
    kokoro = FakeKokoro(["af_heart", "bf_emma"])
    style = _CHARACTER_STYLES["neutral"]
    result = KokoroTTSEngine._character_voice(kokoro, "af_heart", style)
    assert result == "af_heart"


def test_warm_preset_blends_when_candidates_available():
    kokoro = FakeKokoro(["af_heart", "bf_emma", "am_michael", "bm_george"])
    style = _CHARACTER_STYLES["warm"]
    result = KokoroTTSEngine._character_voice(kokoro, "af_heart", style)
    # A blend, not the bare string id, since candidates are available.
    assert isinstance(result, np.ndarray)
    primary = kokoro.get_voice_style("af_heart")
    # af_heart itself is excluded as a candidate for blending into itself.
    secondary_candidates = [v for v in style["voices"] if v != "af_heart"]
    assert secondary_candidates  # sanity: warm's own voice list has other options
    mix = style["mix"]
    # Result must lie strictly between primary and every possible secondary,
    # component-wise, for a convex (0<mix<1) blend.
    assert not np.array_equal(result, primary)


def test_falls_back_to_primary_id_when_no_candidates_available():
    # Voice pack only has the primary voice installed -- none of warm's
    # candidate voices exist yet (e.g. voice pack partially downloaded).
    kokoro = FakeKokoro(["af_heart"])
    style = _CHARACTER_STYLES["warm"]
    result = KokoroTTSEngine._character_voice(kokoro, "af_heart", style)
    assert result == "af_heart"


def test_falls_back_when_kokoro_lacks_get_voice_style():
    class OldKokoro:
        def get_voices(self):
            return ["af_heart", "bf_emma"]
        # No get_voice_style -- simulates an older kokoro-onnx release.

    style = _CHARACTER_STYLES["warm"]
    result = KokoroTTSEngine._character_voice(OldKokoro(), "af_heart", style)
    assert result == "af_heart"


def test_secondary_prefers_matching_locale_and_gender_prefix():
    # "warm" candidates: af_heart, bf_emma, am_michael, bm_george.
    # Primary is af_heart ("a"=US, "f"=female) -- am_michael shares "a"
    # but not "f"; bf_emma shares "f" but not "a"; neither is a perfect
    # match since af_heart itself is excluded. af_heart isn't a candidate
    # for itself, so the best remaining match sharing "a" AND scoring
    # highest should be am_michael (locale match) over bf_emma/bm_george
    # (neither locale nor gender match, or gender-only match).
    kokoro = FakeKokoro(["af_heart", "bf_emma", "am_michael", "bm_george"])
    style = {"mix": 0.5, "speed": 1.0, "gain": 1.0, "voices": ["bf_emma", "am_michael", "bm_george"]}
    result = KokoroTTSEngine._character_voice(kokoro, "af_heart", style)
    expected = kokoro.get_voice_style("af_heart") * 0.5 + kokoro.get_voice_style("am_michael") * 0.5
    assert np.allclose(result, expected)


if __name__ == "__main__":
    test_neutral_preset_returns_primary_id_unchanged()
    test_warm_preset_blends_when_candidates_available()
    test_falls_back_to_primary_id_when_no_candidates_available()
    test_falls_back_when_kokoro_lacks_get_voice_style()
    test_secondary_prefers_matching_locale_and_gender_prefix()
    print("All character-voice tests passed.")
