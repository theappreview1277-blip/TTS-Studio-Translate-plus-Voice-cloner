"""
V3: tests for bundled_voice_ids()/voice_pack_status() against a REAL
numpy .npz file saved with the misleading ".bin" extension kokoro-onnx's
own releases actually use -- this is the concrete check behind the claim
in kokoro_engine.py's docstring that `np.load()` sniffs the real file
format rather than trusting the extension. If that claim were wrong,
this test would fail with an exception instead of returning voice ids.
"""
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tts_studio.engines.tts.kokoro_engine import KokoroTTSEngine, MODEL_FILENAME, VOICES_FILENAME


def test_bundled_voice_ids_reads_npz_saved_with_bin_extension():
    with tempfile.TemporaryDirectory() as tmp:
        voices_dir = Path(tmp)
        voices_path = voices_dir / VOICES_FILENAME
        # np.savez always appends ".npz" to the filename it's given, so
        # write to a real .npz temp name and then rename to the actual
        # "voices-v1.0.bin" name kokoro-onnx publishes -- exactly what a
        # real download produces (a .npz archive under a .bin name).
        npz_tmp = voices_dir / "voices.npz"
        np.savez(npz_tmp, af_heart=np.zeros((2, 3), dtype=np.float32), bf_emma=np.ones((2, 3), dtype=np.float32))
        npz_tmp.replace(voices_path)

        engine = KokoroTTSEngine(voices_dir=voices_dir)
        assert engine.bundled_voice_ids() == ["af_heart", "bf_emma"]
        # Model file still missing -- status should say "Incomplete", not "Installed".
        assert "Incomplete" in engine.voice_pack_status()

        (voices_dir / MODEL_FILENAME).write_bytes(b"not a real onnx model, just for the status check")
        assert "Installed" in engine.voice_pack_status()
        assert "2 voices" in engine.voice_pack_status()


def test_voice_pack_status_not_installed_when_nothing_downloaded():
    with tempfile.TemporaryDirectory() as tmp:
        engine = KokoroTTSEngine(voices_dir=Path(tmp))
        assert engine.voice_pack_status() == "Not installed"


def test_bundled_voice_ids_falls_back_to_known_table_when_pack_missing():
    with tempfile.TemporaryDirectory() as tmp:
        engine = KokoroTTSEngine(voices_dir=Path(tmp))
        ids = engine.bundled_voice_ids()
        assert "af_heart" in ids  # from the static _KOKORO_VOICE_TABLE fallback
        assert len(ids) >= 50  # the full known 54-voice catalog


if __name__ == "__main__":
    test_bundled_voice_ids_reads_npz_saved_with_bin_extension()
    test_voice_pack_status_not_installed_when_nothing_downloaded()
    test_bundled_voice_ids_falls_back_to_known_table_when_pack_missing()
    print("All Kokoro voice-pack tests passed.")
