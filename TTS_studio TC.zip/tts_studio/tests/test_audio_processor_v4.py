"""V4 follow-up #2: AudioProcessor.normalize_peak(), the DSP behind the
"Normalise final audio" checkbox in OutputPanel (see main_window.py's
_rejoin_and_preview()). Pure numpy -- no soundfile, no ffmpeg, no
chatterbox -- so this is the one audio-related test file in this project
that needs no fakes at all; audio_processor.py itself has never had a
dedicated test file before this, since none of its other methods
(load/join/export*) are practical to exercise without soundfile
installed (not available in this sandbox -- see test_chatterbox_engine_
v4.py's docstring for why).
"""
import sys
import types
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# audio_processor.py does `import soundfile as sf` at module level (unlike
# chatterbox_engine.py's lazy, function-local import), so it has to be
# faked *before* the import below even for a normalize_peak() test that
# never calls into soundfile at all -- an empty stub is enough, since
# nothing here exercises load()/export*() (soundfile isn't installed in
# this sandbox; see test_chatterbox_engine_v4.py's docstring for why).
sys.modules.setdefault("soundfile", types.ModuleType("soundfile"))

from tts_studio.audio.audio_processor import AudioProcessor


def test_normalize_peak_scales_quiet_audio_up_to_target():
    processor = AudioProcessor()
    samples = np.array([0.1, -0.2, 0.15, -0.1], dtype=np.float32)

    result = processor.normalize_peak(samples, target_peak=0.98)

    assert abs(float(np.max(np.abs(result))) - 0.98) < 1e-6
    # Shape unchanged -- normalize_peak only rescales amplitude, never
    # trims or pads samples.
    assert result.shape == samples.shape


def test_normalize_peak_scales_loud_audio_down_to_target():
    processor = AudioProcessor()
    samples = np.array([0.5, -1.0, 0.8, -0.9], dtype=np.float32)

    result = processor.normalize_peak(samples, target_peak=0.98)

    assert abs(float(np.max(np.abs(result))) - 0.98) < 1e-6


def test_normalize_peak_preserves_relative_amplitude_between_samples():
    """Normalization should scale everything by the same factor -- it's
    not per-sample compression/limiting, just a single overall gain."""
    processor = AudioProcessor()
    samples = np.array([0.2, -0.4, 0.1], dtype=np.float32)

    result = processor.normalize_peak(samples, target_peak=0.98)

    ratio = result[1] / result[0]
    original_ratio = samples[1] / samples[0]
    assert abs(float(ratio) - float(original_ratio)) < 1e-5


def test_normalize_peak_is_a_no_op_for_silence():
    """An all-zero clip has no peak to normalize against -- dividing by
    a zero peak would raise/produce NaN/inf, so this must be a no-op
    (returned unchanged) rather than a crash. A section that failed to
    generate any real audio shouldn't turn "click Normalise" into an
    error."""
    processor = AudioProcessor()
    samples = np.zeros(10, dtype=np.float32)

    result = processor.normalize_peak(samples)

    assert np.array_equal(result, samples)


def test_normalize_peak_is_a_no_op_for_an_empty_array():
    processor = AudioProcessor()
    samples = np.zeros(0, dtype=np.float32)

    result = processor.normalize_peak(samples)

    assert result.size == 0


def test_normalize_peak_never_exceeds_full_scale():
    """Belt-and-suspenders: even with a target_peak right at 1.0 and
    floating-point rounding, output must stay within the valid
    [-1.0, 1.0] range a 16-bit PCM export can represent without
    wrapping/clipping artifacts."""
    processor = AudioProcessor()
    samples = np.array([0.999, -1.0, 0.5], dtype=np.float32)

    result = processor.normalize_peak(samples, target_peak=1.0)

    assert np.max(np.abs(result)) <= 1.0


if __name__ == "__main__":
    test_normalize_peak_scales_quiet_audio_up_to_target()
    test_normalize_peak_scales_loud_audio_down_to_target()
    test_normalize_peak_preserves_relative_amplitude_between_samples()
    test_normalize_peak_is_a_no_op_for_silence()
    test_normalize_peak_is_a_no_op_for_an_empty_array()
    test_normalize_peak_never_exceeds_full_scale()
    print("All AudioProcessor V4 follow-up tests passed.")
