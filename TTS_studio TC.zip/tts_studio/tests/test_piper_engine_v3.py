"""V3: exercise PiperTTSEngine's new downloadable_voice_ids()/download_voice()
methods -- the catalog fetch against a real local stdlib HTTP server (no
network needed), and the download subprocess call against a monkeypatched
subprocess.run (since actually invoking `python -m piper.download_voices`
would need piper-tts installed, which isn't possible in this sandbox)."""
import http.server
import json
import subprocess
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import tts_studio.engines.tts.piper_engine as piper_engine
from tts_studio.core.exceptions import ResourceDownloadError
from tts_studio.engines.tts.piper_engine import PiperTTSEngine

_CATALOG = {
    "en_US-lessac-medium": {"key": "en_US-lessac-medium"},
    "en_GB-alan-medium": {"key": "en_GB-alan-medium"},
}


def _serve_catalog():
    body = json.dumps(_CATALOG).encode("utf-8")

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def test_downloadable_voice_ids_parses_catalog_json():
    server = _serve_catalog()
    original_url = piper_engine._VOICE_CATALOG_URL
    try:
        port = server.server_address[1]
        piper_engine._VOICE_CATALOG_URL = f"http://127.0.0.1:{port}/voices.json"
        engine = PiperTTSEngine()
        ids = engine.downloadable_voice_ids()
        assert ids == sorted(_CATALOG.keys())
    finally:
        piper_engine._VOICE_CATALOG_URL = original_url
        server.shutdown()


def test_downloadable_voice_ids_raises_resource_download_error_on_failure():
    engine = PiperTTSEngine()
    original_url = piper_engine._VOICE_CATALOG_URL
    try:
        # Nothing listening on this port -- simulates a network failure.
        piper_engine._VOICE_CATALOG_URL = "http://127.0.0.1:1/voices.json"
        try:
            engine.downloadable_voice_ids()
            assert False, "expected ResourceDownloadError"
        except ResourceDownloadError:
            pass
    finally:
        piper_engine._VOICE_CATALOG_URL = original_url


def test_download_voice_raises_on_nonzero_exit(monkeypatch, tmp_path=None):
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        engine = PiperTTSEngine(voices_dir=Path(tmp))

        def fake_run(*args, **kwargs):
            return subprocess.CompletedProcess(args, returncode=1, stdout="", stderr="voice not found")

        original_run = subprocess.run
        subprocess.run = fake_run
        try:
            try:
                engine.download_voice("nonexistent-voice")
                assert False, "expected ResourceDownloadError"
            except ResourceDownloadError as exc:
                assert "voice not found" in str(exc)
        finally:
            subprocess.run = original_run


def test_download_voice_succeeds_on_zero_exit():
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        engine = PiperTTSEngine(voices_dir=Path(tmp))

        def fake_run(*args, **kwargs):
            return subprocess.CompletedProcess(args, returncode=0, stdout="", stderr="")

        original_run = subprocess.run
        subprocess.run = fake_run
        try:
            engine.download_voice("en_US-lessac-medium")  # should not raise
        finally:
            subprocess.run = original_run


if __name__ == "__main__":
    test_downloadable_voice_ids_parses_catalog_json()
    test_downloadable_voice_ids_raises_resource_download_error_on_failure()
    test_download_voice_raises_on_nonzero_exit(None)
    test_download_voice_succeeds_on_zero_exit()
    print("All Piper V3 engine tests passed.")
