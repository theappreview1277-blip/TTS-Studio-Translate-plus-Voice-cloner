"""V3: confirm character_preset and translation_engine survive a save/load
round trip -- these are new Project fields added alongside the V3 work
and it would be easy to add one to the payload dict but forget the
matching read-back in load(), or vice versa."""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tts_studio.core.models import Project
from tts_studio.project.project_manager import ProjectManager


def test_character_preset_and_translation_engine_round_trip():
    project = Project(
        source_text="hello",
        source_language="en",
        target_language="es",
        translation_engine="argos",
        character_preset="dramatic",
    )
    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "MyProject"
        manager = ProjectManager()
        manager.save(project, project_dir)

        reloaded = manager.load(project_dir)
        assert reloaded.character_preset == "dramatic"
        assert reloaded.translation_engine == "argos"


def test_character_preset_defaults_to_neutral_for_old_projects():
    """A project.json saved before V3 existed has no "character_preset"
    key at all -- load() must default it to "neutral", not KeyError."""
    import json
    from datetime import datetime, timezone

    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "OldProject"
        project_dir.mkdir()
        (project_dir / "source.txt").write_text("hi", encoding="utf-8")
        payload = {
            "schema_version": 1,
            "name": "OldProject",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "modified_at": datetime.now(timezone.utc).isoformat(),
            "source_language": "en",
            "target_language": "es",
            "translation_engine": "argos",
            "tts_engine": "piper",
            "tts_voice_id": "en_US-lessac-medium",
            "speed": 1.0,
            "volume": 1.0,
            "pitch_semitones": 0.0,
            # no "character_preset" key -- simulates a pre-V3 project file
            "output_format": "wav",
            "chunk_mode": "automatic",
            "max_chunk_chars": 500,
            "sections": [],
        }
        (project_dir / "project.json").write_text(json.dumps(payload), encoding="utf-8")

        reloaded = ProjectManager().load(project_dir)
        assert reloaded.character_preset == "neutral"


def test_v4_reference_audio_path_round_trip():
    """V4: Chatterbox's cloning reference-clip path is a new Project field
    too -- same save/forget-the-read-back risk as V3's fields above."""
    project = Project(
        source_text="hello",
        tts_engine="chatterbox",
        tts_reference_audio_path="/home/user/my_voice_sample.wav",
    )
    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "ClonedVoiceProject"
        manager = ProjectManager()
        manager.save(project, project_dir)

        reloaded = manager.load(project_dir)
        assert reloaded.tts_reference_audio_path == "/home/user/my_voice_sample.wav"


def test_v4_reference_audio_path_defaults_to_none_for_old_projects():
    """A pre-V4 project.json has no "tts_reference_audio_path" key at all --
    load() must default it to None, not KeyError."""
    import json
    from datetime import datetime, timezone

    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "OldProject"
        project_dir.mkdir()
        (project_dir / "source.txt").write_text("hi", encoding="utf-8")
        payload = {
            "schema_version": 1,
            "name": "OldProject",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "modified_at": datetime.now(timezone.utc).isoformat(),
            "source_language": "en",
            "target_language": "es",
            "translation_engine": "argos",
            "tts_engine": "piper",
            "tts_voice_id": "en_US-lessac-medium",
            "speed": 1.0,
            "volume": 1.0,
            "pitch_semitones": 0.0,
            "character_preset": "neutral",
            # no "tts_reference_audio_path" key -- simulates a pre-V4 project file
            "output_format": "wav",
            "chunk_mode": "automatic",
            "max_chunk_chars": 500,
            "sections": [],
        }
        (project_dir / "project.json").write_text(json.dumps(payload), encoding="utf-8")

        reloaded = ProjectManager().load(project_dir)
        assert reloaded.tts_reference_audio_path is None


def test_v4_native_chatterbox_controls_round_trip():
    """V4 follow-up: Chatterbox's Expression/Voice Guidance/Advanced
    sampling fields are new Project fields too -- same save/forget-the-
    read-back risk as every other field-addition test in this file."""
    project = Project(
        source_text="hello",
        tts_engine="chatterbox",
        tts_voice_id="original",
        tts_exaggeration=0.8,
        tts_cfg_weight=0.3,
        tts_temperature=0.9,
        tts_repetition_penalty=1.3,
        tts_min_p=0.1,
        tts_top_p=0.9,
        tts_top_k=500,
    )
    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "NativeControlsProject"
        manager = ProjectManager()
        manager.save(project, project_dir)

        reloaded = manager.load(project_dir)
        assert reloaded.tts_exaggeration == 0.8
        assert reloaded.tts_cfg_weight == 0.3
        assert reloaded.tts_temperature == 0.9
        assert reloaded.tts_repetition_penalty == 1.3
        assert reloaded.tts_min_p == 0.1
        assert reloaded.tts_top_p == 0.9
        assert reloaded.tts_top_k == 500


def test_v4_native_chatterbox_controls_default_for_old_projects():
    """A pre-follow-up project.json has none of these seven keys --
    load() must default every one of them, not KeyError."""
    import json
    from datetime import datetime, timezone

    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "OldProject"
        project_dir.mkdir()
        (project_dir / "source.txt").write_text("hi", encoding="utf-8")
        payload = {
            "schema_version": 1,
            "name": "OldProject",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "modified_at": datetime.now(timezone.utc).isoformat(),
            "source_language": "en",
            "target_language": "es",
            "translation_engine": "argos",
            "tts_engine": "chatterbox",
            "tts_voice_id": "nano",
            "speed": 1.0,
            "volume": 1.0,
            "pitch_semitones": 0.0,
            "character_preset": "neutral",
            "tts_reference_audio_path": None,
            # no native-controls keys at all -- simulates a project saved
            # before this follow-up pass existed
            "output_format": "wav",
            "chunk_mode": "automatic",
            "max_chunk_chars": 500,
            "sections": [],
        }
        (project_dir / "project.json").write_text(json.dumps(payload), encoding="utf-8")

        reloaded = ProjectManager().load(project_dir)
        assert reloaded.tts_exaggeration == 0.5
        assert reloaded.tts_cfg_weight == 0.5
        assert reloaded.tts_temperature == 0.8
        assert reloaded.tts_repetition_penalty == 1.2
        assert reloaded.tts_min_p == 0.05
        assert reloaded.tts_top_p == 1.0
        assert reloaded.tts_top_k == 1000


def test_v4_normalize_output_round_trip():
    """V4 follow-up #2: the 'Normalise final audio' checkbox's state is
    a new Project field too -- same save/forget-the-read-back risk as
    every other field-addition test in this file."""
    project = Project(source_text="hello", normalize_output=True)
    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "NormalizedProject"
        manager = ProjectManager()
        manager.save(project, project_dir)

        reloaded = manager.load(project_dir)
        assert reloaded.normalize_output is True


def test_v4_normalize_output_defaults_to_false_for_old_projects():
    """A pre-follow-up project.json has no "normalize_output" key at
    all -- load() must default it to False, not KeyError."""
    import json
    from datetime import datetime, timezone

    with tempfile.TemporaryDirectory() as tmp:
        project_dir = Path(tmp) / "OldProject"
        project_dir.mkdir()
        (project_dir / "source.txt").write_text("hi", encoding="utf-8")
        payload = {
            "schema_version": 1,
            "name": "OldProject",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "modified_at": datetime.now(timezone.utc).isoformat(),
            "source_language": "en",
            "target_language": "es",
            "translation_engine": "argos",
            "tts_engine": "piper",
            "tts_voice_id": "en_US-lessac-medium",
            "speed": 1.0,
            "volume": 1.0,
            "pitch_semitones": 0.0,
            "character_preset": "neutral",
            "tts_reference_audio_path": None,
            # no "normalize_output" key -- simulates a project saved
            # before this follow-up pass existed
            "output_format": "wav",
            "chunk_mode": "automatic",
            "max_chunk_chars": 500,
            "sections": [],
        }
        (project_dir / "project.json").write_text(json.dumps(payload), encoding="utf-8")

        reloaded = ProjectManager().load(project_dir)
        assert reloaded.normalize_output is False


if __name__ == "__main__":
    test_character_preset_and_translation_engine_round_trip()
    test_character_preset_defaults_to_neutral_for_old_projects()
    test_v4_reference_audio_path_round_trip()
    test_v4_reference_audio_path_defaults_to_none_for_old_projects()
    test_v4_native_chatterbox_controls_round_trip()
    test_v4_native_chatterbox_controls_default_for_old_projects()
    test_v4_normalize_output_round_trip()
    test_v4_normalize_output_defaults_to_false_for_old_projects()
    print("All project_manager V3/V4 tests passed.")
