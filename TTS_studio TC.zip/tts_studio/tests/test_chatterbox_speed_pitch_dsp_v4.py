"""V4 follow-up #2: Chatterbox's new Speed/Pitch controls, implemented as
ffmpeg DSP on the finished WAV since Chatterbox's own generate() has no
speed/pitch parameter at all -- see chatterbox_engine.py's module
docstring ("Speed and Pitch, added in a second follow-up pass...") for
the full rationale and the exact ffmpeg techniques used (`atempo` for
Speed, the standard `asetrate`+`aresample`+`atempo` trick for Pitch).

Unlike test_chatterbox_engine_v4.py (which fakes the whole persistent
worker and never touches real audio), these tests exercise the actual
`_apply_speed_and_pitch()` function against a real ffmpeg subprocess and
a real WAV file, written with the stdlib `wave` module rather than
`soundfile` (not installed in this sandbox -- see below). ffmpeg itself
IS available in this sandbox (unlike a second Python environment or
chatterbox-tts), so there's no reason to fake the one piece that matters
most here: whether the actual ffmpeg filter graph does what the code
comments claim it does.

`soundfile` is only used inside `_apply_speed_and_pitch()` for one
thing -- `sf.info(path).samplerate`, to know the file's own sample rate
before building the filter graph -- so the fake installed below is
deliberately tiny: just enough to answer that one question by reading a
real WAV's header via the stdlib `wave` module, not a re-implementation
of soundfile's read/write like test_chatterbox_engine_v4.py's fake (that
one's fake WAV format isn't a real WAV at all, which is exactly why it
can't be reused here -- real ffmpeg needs a real, parseable WAV file).
"""
import math
import struct
import sys
import tempfile
import types
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import tts_studio.engines.tts.chatterbox_engine as chatterbox_engine
from tts_studio.core.exceptions import SynthesisFailedError
from tts_studio.engines.tts.chatterbox_engine import _apply_speed_and_pitch


class _FakeSFInfo:
    def __init__(self, samplerate: int):
        self.samplerate = samplerate


def _install_fake_soundfile_info_only():
    """See module docstring: only `.info()` is faked, and it's backed by
    the stdlib `wave` module reading a real WAV header -- not a
    reimplementation of soundfile's own format handling."""
    fake = types.ModuleType("soundfile")

    def info(path):
        with wave.open(str(path), "rb") as wf:
            return _FakeSFInfo(wf.getframerate())

    fake.info = info
    sys.modules["soundfile"] = fake


def _remove_fake_soundfile():
    sys.modules.pop("soundfile", None)


def _write_real_wav(path: Path, seconds: float = 1.0, sample_rate: int = 24000, freq: float = 220.0) -> None:
    """A real, standard PCM16 mono WAV -- something real ffmpeg can
    actually decode, unlike test_chatterbox_engine_v4.py's fake-format
    files (which only the *fake* soundfile module in that file
    understands)."""
    n = int(seconds * sample_rate)
    frames = bytearray()
    for i in range(n):
        value = int(3000 * math.sin(2 * math.pi * freq * i / sample_rate))
        frames += struct.pack("<h", value)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(bytes(frames))


def _wav_duration_and_rate(path: Path) -> tuple[float, int]:
    with wave.open(str(path), "rb") as wf:
        return wf.getnframes() / wf.getframerate(), wf.getframerate()


def test_no_op_at_defaults_never_touches_the_file_or_needs_ffmpeg_or_soundfile():
    """speed=1.0, pitch=0 is the common case (nobody touched either
    slider) -- it must short-circuit before ever importing soundfile or
    shelling out to ffmpeg, so a path that doesn't even exist is fine
    here, and this test runs correctly with neither fake installed."""
    _apply_speed_and_pitch(Path("/nonexistent/should-never-be-touched.wav"), speed=1.0, pitch_semitones=0.0)


def test_raises_a_clear_ffmpeg_missing_error_without_touching_soundfile():
    """shutil.which() is checked before sf.info() is ever called, so this
    doesn't need the soundfile fake installed either -- if it reached
    sf.info() first, this test would fail with an import error instead
    of the intended SynthesisFailedError, which would itself be a sign
    the ordering in the real function regressed."""
    original_which = chatterbox_engine.shutil.which
    chatterbox_engine.shutil.which = lambda _name: None
    try:
        try:
            _apply_speed_and_pitch(Path("/tmp/whatever.wav"), speed=1.25, pitch_semitones=0.0)
            assert False, "expected SynthesisFailedError"
        except SynthesisFailedError as exc:
            assert "ffmpeg" in str(exc).lower()
    finally:
        chatterbox_engine.shutil.which = original_which


def test_speed_change_shortens_duration_proportionally():
    _install_fake_soundfile_info_only()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "clip.wav"
            _write_real_wav(path, seconds=2.0, sample_rate=24000)
            original_duration, _ = _wav_duration_and_rate(path)

            _apply_speed_and_pitch(path, speed=1.5, pitch_semitones=0.0)

            new_duration, new_rate = _wav_duration_and_rate(path)
            # atempo=1.5 plays the clip 1.5x faster, i.e. 1/1.5 the
            # duration -- a few percent of tolerance for ffmpeg's own
            # frame-boundary rounding, not for the filter being wrong.
            expected = original_duration / 1.5
            assert abs(new_duration - expected) / expected < 0.05
            assert new_rate == 24000  # atempo alone never touches sample rate
    finally:
        _remove_fake_soundfile()


def test_pitch_shift_preserves_duration_and_sample_rate():
    _install_fake_soundfile_info_only()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "clip.wav"
            _write_real_wav(path, seconds=2.0, sample_rate=24000)
            original_duration, original_rate = _wav_duration_and_rate(path)

            _apply_speed_and_pitch(path, speed=1.0, pitch_semitones=4.0)

            new_duration, new_rate = _wav_duration_and_rate(path)
            # The whole point of the asetrate+aresample+atempo chain is
            # that the pitch shifts but the duration and sample rate come
            # back out matching the original -- that's what distinguishes
            # this from a naive "just change the sample rate" approach,
            # which would shift duration right along with pitch.
            assert abs(new_duration - original_duration) / original_duration < 0.03
            assert new_rate == original_rate
    finally:
        _remove_fake_soundfile()


def test_combined_speed_and_pitch_still_produces_valid_output():
    """Both controls at once chains two separate `atempo` filters (one
    from the pitch-correction step, one for Speed itself) in a single
    `-af` graph -- this is the case most likely to break if the two
    filter stages were built incorrectly (e.g. overwriting each other's
    `-af` argument instead of joining them)."""
    _install_fake_soundfile_info_only()
    try:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "clip.wav"
            _write_real_wav(path, seconds=2.0, sample_rate=24000)
            original_duration, _ = _wav_duration_and_rate(path)

            _apply_speed_and_pitch(path, speed=1.25, pitch_semitones=-3.0)

            new_duration, new_rate = _wav_duration_and_rate(path)
            expected = original_duration / 1.25  # pitch shift alone shouldn't change duration
            assert abs(new_duration - expected) / expected < 0.05
            assert new_rate == 24000
    finally:
        _remove_fake_soundfile()


if __name__ == "__main__":
    test_no_op_at_defaults_never_touches_the_file_or_needs_ffmpeg_or_soundfile()
    test_raises_a_clear_ffmpeg_missing_error_without_touching_soundfile()
    test_speed_change_shortens_duration_proportionally()
    test_pitch_shift_preserves_duration_and_sample_rate()
    test_combined_speed_and_pitch_still_produces_valid_output()
    print("All Chatterbox Speed/Pitch DSP tests passed.")
