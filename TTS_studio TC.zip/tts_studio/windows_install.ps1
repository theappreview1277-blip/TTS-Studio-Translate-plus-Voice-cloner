$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Find-Python312 {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        try {
            $candidate = (& $launcher.Source -3.12 -c "import sys; print(sys.executable)" 2>$null)
            if ($LASTEXITCODE -eq 0 -and $candidate -and (Test-Path $candidate.Trim())) {
                return $candidate.Trim()
            }
        } catch { }
    }

    $locations = @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:ProgramFiles\Python312\python.exe"
    )
    foreach ($path in $locations) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

# Chatterbox specifically wants Python 3.11, not 3.12 like the rest of
# the app: upstream develops and tests chatterbox-tts against 3.11 (its
# own README says so), and -- found the hard way, debugging a real
# install failure -- Python 3.12's `venv` module stopped bundling
# `setuptools` by default, which chatterbox's `perth` dependency needs
# and fails on silently instead of raising (see
# requirements-chatterbox.txt and _chatterbox_worker.py for the full
# story). Mirrors Find-Python312 above, just for 3.11; if this can't
# find or install 3.11, the caller falls back to whatever Python built
# the main .venv non-fatally -- _chatterbox_worker.py's own defenses
# still cover that fallback case.
function Find-Python311 {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        try {
            $candidate = (& $launcher.Source -3.11 -c "import sys; print(sys.executable)" 2>$null)
            if ($LASTEXITCODE -eq 0 -and $candidate -and (Test-Path $candidate.Trim())) {
                return $candidate.Trim()
            }
        } catch { }
    }

    $locations = @(
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:ProgramFiles\Python311\python.exe"
    )
    foreach ($path in $locations) {
        if (Test-Path $path) { return $path }
    }

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "Installing Python 3.11 for Chatterbox's environment (the main app stays on Python 3.12)..." -ForegroundColor Yellow
        & $winget.Source install --id Python.Python.3.11 --exact --source winget --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -eq 0) {
            foreach ($path in $locations) {
                if (Test-Path $path) { return $path }
            }
            $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
            if ($launcher) {
                try {
                    $candidate = (& $launcher.Source -3.11 -c "import sys; print(sys.executable)" 2>$null)
                    if ($LASTEXITCODE -eq 0 -and $candidate -and (Test-Path $candidate.Trim())) {
                        return $candidate.Trim()
                    }
                } catch { }
            }
        }
    }
    return $null
}

# Real installation risk, found in review (not hypothetical): chatterbox-tts
# 0.1.7's own dependency list pins its watermarking dependency as
# `resemble-perth @ git+https://github.com/resemble-ai/Perth.git@master`
# -- a VCS direct-URL requirement, not a normal PyPI version pin
# (confirmed against chatterbox's own pyproject.toml on GitHub). pip's
# git support needs a real `git.exe` on PATH to do that clone; a clean
# Windows 11 machine has no reason to already have one, and this
# installer previously checked for Python, FFmpeg, and espeak-ng but
# never for git, even though Chatterbox's own pip install can depend on
# it. (A published `resemble-perth` package does exist on PyPI too, so a
# future round could consider overriding chatterbox-tts's git dependency
# with that instead -- but that needs real verification that pip's
# resolver actually prefers an already-satisfied same-name package over
# a direct URL requirement from a dependency's metadata, which is
# resolver-version-sensitive and wasn't something this pass could test
# in an environment with no package-index network access. Installing git
# itself, exactly as upstream expects, is the safer choice for now.)
function Find-Git {
    $existing = Get-Command git.exe -ErrorAction SilentlyContinue
    if ($existing) { return $existing.Source }

    $locations = @(
        "$env:ProgramFiles\Git\cmd\git.exe",
        "${env:ProgramFiles(x86)}\Git\cmd\git.exe"
    )
    foreach ($path in $locations) {
        if (Test-Path $path) { return $path }
    }

    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "Installing Git (needed by Chatterbox's own pip install -- it pins one dependency via a git URL)..." -ForegroundColor Yellow
        & $winget.Source install --id Git.Git --exact --source winget --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -eq 0) {
            foreach ($path in $locations) {
                if (Test-Path $path) { return $path }
            }
            $existing = Get-Command git.exe -ErrorAction SilentlyContinue
            if ($existing) { return $existing.Source }
            Write-Host "Git was installed but isn't on PATH yet in this session -- you may need to restart Windows before Chatterbox's own pip install can succeed." -ForegroundColor Yellow
        }
    }
    return $null
}

Write-Host "TTS Studio - Windows 11 setup" -ForegroundColor Cyan
Write-Host "This installs Python packages, offline English voices, and the Chatterbox voice-cloning model. It's a bigger download than earlier versions and can take a while depending on your connection."
Write-Host ""

$python = Find-Python312
if (-not $python) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw "Python 3.12 is not installed and Windows Package Manager (winget) was not found. Install Python 3.12 from python.org, tick 'Add python.exe to PATH', then run this installer again."
    }
    Write-Host "Installing Python 3.12..." -ForegroundColor Yellow
    & $winget.Source install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw "Python installation failed (winget exit code $LASTEXITCODE)." }
    $python = Find-Python312
    if (-not $python) { throw "Python was installed but could not be found. Restart Windows, then run this installer again." }
}

Write-Host "Using $python"
$rebuildEnvironment = $false
if (Test-Path ".venv\Scripts\python.exe") {
    $environmentVersion = (& ".venv\Scripts\python.exe" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    if ($environmentVersion.Trim() -ne "3.12") {
        Write-Host "Replacing the earlier Python $environmentVersion environment with Python 3.12..." -ForegroundColor Yellow
        $rebuildEnvironment = $true
    }
}
if ($rebuildEnvironment) {
    Remove-Item -LiteralPath (Join-Path $PSScriptRoot ".venv") -Recurse -Force
}
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Creating the private Python environment..." -ForegroundColor Yellow
    & $python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Could not create the Python environment." }
}

$venvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
Write-Host "Installing TTS Studio components..." -ForegroundColor Yellow
& $venvPython -m pip install --upgrade pip wheel
if ($LASTEXITCODE -ne 0) { throw "Could not update pip." }
& $venvPython -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Could not install the required Python packages." }

if (-not (Get-Command ffmpeg.exe -ErrorAction SilentlyContinue)) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "Installing FFmpeg (needed for MP3/OGG export)..." -ForegroundColor Yellow
        & $winget.Source install --id Gyan.FFmpeg --exact --source winget --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) {
            Write-Host "FFmpeg installation did not complete automatically. WAV and FLAC export will still work without it; install FFmpeg manually (https://ffmpeg.org/download.html) for MP3/OGG export." -ForegroundColor Yellow
        } elseif (-not (Get-Command ffmpeg.exe -ErrorAction SilentlyContinue)) {
            Write-Host "FFmpeg was installed but isn't on PATH yet -- you may need to restart Windows before MP3/OGG export works. WAV and FLAC export work either way." -ForegroundColor Yellow
        }
    } else {
        Write-Host "FFmpeg wasn't found and Windows Package Manager isn't available to install it. WAV and FLAC export will still work; install FFmpeg manually for MP3/OGG (https://ffmpeg.org/download.html)." -ForegroundColor Yellow
    }
}

if (-not (Get-Command espeak-ng.exe -ErrorAction SilentlyContinue)) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "Installing espeak-ng (needed by Kokoro, especially for non-English voices)..." -ForegroundColor Yellow
        & $winget.Source install --id eSpeak-NG.eSpeak-NG --exact --source winget --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) {
            Write-Host "espeak-ng installation did not complete automatically. Kokoro's English voices still work without it; install espeak-ng manually (https://github.com/espeak-ng/espeak-ng/releases) for non-English Kokoro voices." -ForegroundColor Yellow
        } elseif (-not (Get-Command espeak-ng.exe -ErrorAction SilentlyContinue)) {
            Write-Host "espeak-ng was installed but isn't on PATH yet -- you may need to restart Windows before non-English Kokoro voices work correctly." -ForegroundColor Yellow
        }
    } else {
        Write-Host "espeak-ng wasn't found and Windows Package Manager isn't available to install it. Kokoro's English voices still work; install espeak-ng manually for non-English voices (https://github.com/espeak-ng/espeak-ng/releases)." -ForegroundColor Yellow
    }
}

New-Item -ItemType Directory -Force -Path "models\piper", "models\kokoro" | Out-Null

$piperModel = "models\piper\en_US-lessac-medium.onnx"
if (-not (Test-Path $piperModel)) {
    Write-Host "Downloading the Piper English voice..." -ForegroundColor Yellow
    & $venvPython -m piper.download_voices en_US-lessac-medium --data-dir "models\piper"
    if ($LASTEXITCODE -ne 0) { throw "The Piper voice download failed." }
}

$kokoroModel = "models\kokoro\kokoro-v1.0.onnx"
$kokoroVoices = "models\kokoro\voices-v1.0.bin"
if (-not (Test-Path $kokoroModel)) {
    Write-Host "Downloading the Kokoro model (this is a large download)..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx" -OutFile $kokoroModel
}
if (-not (Test-Path $kokoroVoices)) {
    Write-Host "Downloading Kokoro voices..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin" -OutFile $kokoroVoices
}

Write-Host "Checking the installation..." -ForegroundColor Yellow
& $venvPython -c "import PySide6, numpy, soundfile, argostranslate, lingua, kokoro_onnx, docx, pypdf; print('Core components: OK')"
if ($LASTEXITCODE -ne 0) { throw "The final component check failed." }
& $venvPython -m piper --help *> $null
if ($LASTEXITCODE -ne 0) { throw "Piper did not start correctly." }

# Chatterbox (voice cloning) gets its OWN virtual environment, separate
# from .venv above. Reason: chatterbox-tts pins numpy<2.0.0, which
# directly conflicts with kokoro-onnx's numpy>=2.0.2 requirement -- the
# two packages cannot coexist in one environment, full stop, not just a
# "loosen a pin" problem. chatterbox_engine.py talks to this environment
# over a subprocess, the same mechanism (not the same reason) Piper
# already uses. This whole block is non-fatal: if it fails for any
# reason, every other engine in the app is completely unaffected.
Write-Host ""
Write-Host "Setting up Chatterbox (voice cloning) in its own environment..." -ForegroundColor Yellow
$chatterboxOk = $true

# Targets Python 3.11 specifically -- see Find-Python311's comment above
# for why. Falls back to the same Python that built the main .venv if
# 3.11 truly isn't available anywhere and winget can't install it;
# _chatterbox_worker.py's own setuptools/perth checks still cover that
# fallback case, just with less margin for other 3.12-only rough edges.
$chatterboxPythonSeed = Find-Python311
if (-not $chatterboxPythonSeed) {
    Write-Host "Couldn't find or install Python 3.11 (chatterbox-tts's own tested version); using Python 3.12 for Chatterbox instead. This usually still works." -ForegroundColor Yellow
    $chatterboxPythonSeed = $python
}

$rebuildChatterboxEnv = $false
if (Test-Path ".venv-chatterbox\Scripts\python.exe") {
    $chatterboxEnvVersion = (& ".venv-chatterbox\Scripts\python.exe" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    $seedVersion = (& $chatterboxPythonSeed -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    if ($chatterboxEnvVersion.Trim() -ne $seedVersion.Trim()) {
        Write-Host "Replacing Chatterbox's Python $($chatterboxEnvVersion.Trim()) environment with Python $($seedVersion.Trim())..." -ForegroundColor Yellow
        $rebuildChatterboxEnv = $true
    }
}
if ($rebuildChatterboxEnv) {
    Remove-Item -LiteralPath (Join-Path $PSScriptRoot ".venv-chatterbox") -Recurse -Force
}
if (-not (Test-Path ".venv-chatterbox\Scripts\python.exe")) {
    & $chatterboxPythonSeed -m venv .venv-chatterbox
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Couldn't create Chatterbox's environment. Every other engine is unaffected; voice cloning just won't be available. See README.md's 'Voice cloning (Chatterbox)' section to set it up by hand later." -ForegroundColor Yellow
        $chatterboxOk = $false
    }
}
if ($chatterboxOk) {
    $chatterboxPython = Join-Path $PSScriptRoot ".venv-chatterbox\Scripts\python.exe"
    # setuptools explicitly, not just pip/wheel: even on Python 3.11 (see
    # above) it's cheap insurance, and it's the actual fix if this ended
    # up falling back to 3.12, whose venv no longer bundles setuptools by
    # default -- chatterbox-tts's `perth` watermarking dependency needs
    # it (via pkg_resources) at import time and silently no-ops instead
    # of erroring when it's missing. See requirements-chatterbox.txt and
    # _chatterbox_worker.py for the full story, found by debugging a
    # real "TypeError: 'NoneType' object is not callable" crash report
    # against this app.
    #
    # setuptools is given an exact version here, not `--upgrade`ed
    # unconstrained like pip/wheel: setuptools itself removed
    # pkg_resources outright in v82.0.0 (setuptools's own changelog,
    # "Deprecations and Removals"), so letting this line pick "whatever
    # is newest" would reintroduce the exact crash this block exists to
    # avoid. An exact version (as opposed to a lower-bound range) also
    # means pip installs precisely this version even if a newer,
    # incompatible one is already sitting in the venv -- not just "some
    # setuptools is present" -- matching the pin in
    # requirements-chatterbox.txt so the two installs never fight.
    & $chatterboxPython -m pip install --upgrade pip wheel "setuptools==80.9.0"
    # Captured immediately, before Find-Git runs below: Find-Git may
    # itself shell out to winget, which would overwrite $LASTEXITCODE
    # and silently corrupt the gate a few lines down if this weren't
    # saved first.
    $setuptoolsExitCode = $LASTEXITCODE

    # See Find-Git's own comment above for why this needs checking at
    # all: chatterbox-tts pins its watermarking dependency via a git+
    # https URL, so pip needs a real git.exe on PATH for this install to
    # succeed, on top of everything else this venv is already assembling.
    # Non-fatal like everything else in this block: if git truly can't be
    # found or installed, let the pip install below run anyway and fail
    # with its own (git-specific) error rather than skipping straight to
    # a less informative failure message.
    if (-not (Find-Git)) {
        Write-Host "Couldn't find or install Git. Chatterbox's own pip install may fail because one of its dependencies is fetched via a git URL -- see README.md's 'Voice cloning (Chatterbox)' section if the next step reports a git-related error." -ForegroundColor Yellow
    }

    # Defaults to failed (1), not 0/unset: if $setuptoolsExitCode was
    # already non-zero, the block below never runs at all, and this must
    # still read as a failure rather than silently passing the check
    # after it -- same reasoning as capturing $setuptoolsExitCode itself
    # above, so nothing in between (here, Find-Git's own winget call)
    # can corrupt the final pass/fail decision via a stale $LASTEXITCODE.
    $requirementsExitCode = 1
    if ($setuptoolsExitCode -eq 0) {
        Write-Host "Installing Chatterbox's components (this is the bigger download mentioned above)..." -ForegroundColor Yellow
        & $chatterboxPython -m pip install -r requirements-chatterbox.txt
        $requirementsExitCode = $LASTEXITCODE
    }
    if ($setuptoolsExitCode -ne 0 -or $requirementsExitCode -ne 0) {
        Write-Host "Couldn't install Chatterbox's components. Every other engine is unaffected; voice cloning just won't be available. See README.md's 'Voice cloning (Chatterbox)' section to retry by hand later." -ForegroundColor Yellow
        $chatterboxOk = $false
    }
}
if ($chatterboxOk) {
    Write-Host "Downloading Chatterbox's voice-cloning models (large, several GB, only happens once)..." -ForegroundColor Yellow
    # Download-only, deliberately NOT `ChatterboxTTS.from_pretrained()`:
    # from_pretrained() also *constructs* the full model in memory after
    # downloading it, which can consume real RAM during install and made
    # this step look hung on a modest machine. --download-only fetches
    # the same files via the same hf_hub_download/snapshot_download
    # calls (verified against chatterbox's own source) without building
    # anything -- see _chatterbox_worker.py's module docstring.
    & $chatterboxPython (Join-Path $PSScriptRoot "tts_studio\engines\tts\_chatterbox_worker.py") --download-only
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Chatterbox installed, but its models couldn't be pre-downloaded (e.g. a network hiccup). They'll download automatically the first time you actually use Chatterbox in the app instead -- same one-time download, just deferred." -ForegroundColor Yellow
    }
}

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "TTS Studio.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $PSScriptRoot "Run TTS Studio.cmd"
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Description = "Start TTS Studio"
$shortcut.Save()

Write-Host ""
Write-Host "TTS Studio is ready. A shortcut was added to your Desktop." -ForegroundColor Green
