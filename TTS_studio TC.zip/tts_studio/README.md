# TTS Studio (V4)

An open-source, modular translation + text-to-speech desktop app for Windows.
This build implements the **V4** stage of the staged roadmap in
`ARCHITECTURE.md`: everything V3 already did (in-app Download Manager,
Kokoro character presets, real DirectML GPU wiring) on top of everything
V2 did before that (paste/import text, detect/select a language,
translate section-by-section with independent editing and regeneration,
WAV/MP3/FLAC/OGG export, project save/load), plus V4's first **voice
cloning** engine: **Chatterbox** (MIT-licensed), installed by default
along with everything else.

## What this build does

- **Text input**: paste, type, or import a `.txt`, `.md`, `.docx`, or `.pdf` document
- Offline source-language detection (`lingua`), with a manual override
- **Argos Translate** (fully offline, no server) as the translation engine
- **Download Languages...**: install (or remove) Argos translation packages
  from inside the app -- or let it offer to install one automatically the
  first time you hit Translate on a pair you don't have yet -- no more
  `argospm`/curl steps
- **Splits text into sections** (sentence / paragraph / automatic / custom-length modes)
- A sections table where each section's translation is independently editable, and each
  section can be **regenerated on its own** without re-running the whole document
- Two offline TTS engines: **Piper** and **Kokoro**, each with voice
  selection, speed, and volume (pitch is disabled -- no engine here
  supports it yet; see `ARCHITECTURE.md`)
- A third TTS engine, **Chatterbox**, for **voice cloning**: upload a
  short reference clip and it speaks in that voice, or leave it blank for
  its own built-in voice -- see "Voice cloning (Chatterbox)" below
- **Download Voices...**: browse, install, and remove Piper voices, or
  download/repair/remove Kokoro's voice pack, all from inside the app
- **Kokoro character presets** (Neutral / Warm / Calm / Energetic / Dramatic /
  Storyteller): blends in a second, stylistically-matched Kokoro voice and
  nudges speed/gain to taste -- see "Kokoro character presets" below.
  Piper voices don't support this (the preset control hides itself, the
  same way the pitch control hides itself for voices that can't pitch-shift)
- Live status-bar progress during translation and speech generation
- Audio preview and export to **WAV, MP3, FLAC, or OGG**
- **Project save/load**: a project directory holding the source text, translations,
  per-section audio, and all settings -- see `ARCHITECTURE.md` section E for the exact layout
- Automatic CPU/GPU device detection, now with real DirectML acceleration
  for Kokoro on non-NVIDIA Windows GPUs -- see "GPU acceleration" below

Still staged for later versions: Qwen3-TTS as a second cloning engine, and
wiring up Chatterbox's own Multilingual variant (23 languages) -- see
`ARCHITECTURE.md` sections H and J. Chatterbox's Nano/Turbo tiers, unlike
Multilingual, *are* wired up as of this version -- see "Voice cloning
(Chatterbox)" below.

**FFmpeg is required for MP3 and OGG export** (WAV and FLAC work without it, via
`soundfile`). The Windows installer below installs it automatically; see the
manual setup steps if you're installing by hand.

**Heads up: this install is noticeably bigger than V1-V3's.** Chatterbox
is installed by default, but into its *own* separate environment
(`.venv-chatterbox`, alongside the main `.venv`) rather than mixed in
with everything else -- see "Voice cloning (Chatterbox)" below for why
it needs one. Either way, expect a multi-gigabyte PyTorch download and a
few extra minutes on top of what V1-V3 needed. If you'd rather skip that
and don't need voice cloning, it's safe to just not run that part of the
setup (see below) -- Piper and Kokoro work exactly the same either way,
and Chatterbox just shows "(not installed)" in the Engine dropdown instead.

## Windows 11: simple setup

1. Extract the ZIP fully (do not run it from inside the ZIP preview).
2. Double-click **Install TTS Studio.cmd**.
3. When it finishes, use the new **TTS Studio** Desktop shortcut, or
   double-click **Run TTS Studio.cmd**.

The installer obtains Python 3.12 through Windows Package Manager when needed,
creates the main app environment (`.venv`) and installs its components,
installs FFmpeg and espeak-ng if they aren't already on your system,
downloads an English Piper voice and the Kokoro model/voices, then
separately obtains Python 3.11 (Chatterbox's own tested version -- see
"Voice cloning (Chatterbox)" below) and creates a second environment
(`.venv-chatterbox`) from it, installs Chatterbox's voice-cloning
package and every model tier's weights into that, checks the
installation, and adds the Desktop shortcut. An internet connection
is required during setup, and Chatterbox's step specifically makes this a
noticeably bigger one-time download than earlier versions needed (see
the heads-up above). The Chatterbox step is entirely **non-fatal** -- if
it fails for any reason (no network, disk space, whatever), the installer
keeps going and every other engine works completely normally; Chatterbox
just won't be available until you retry that step by hand (see "Voice
cloning (Chatterbox)" below). You can also skip the Piper/Kokoro voice
downloads here and use **Download Voices...** inside the app instead,
whenever you're ready.

If Windows displays a SmartScreen warning, choose **More info**, check that the
file name is `Install TTS Studio.cmd`, and then choose **Run anyway**. The script
is plain text and can be opened in Notepad before running.

## Manual Windows setup

1. **Python 3.12** -- https://www.python.org/downloads/
   During install, tick "Add python.exe to PATH".

2. **Create a virtual environment and install dependencies:**

   ```powershell
   py -3.12 -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```

   This does **not** include Chatterbox (voice cloning) -- see "Voice
   cloning (Chatterbox)" below for why it needs its own separate
   environment and how to set that up.

3. **espeak-ng** (needed by Kokoro, especially for non-English voices):
   The Windows installer (`windows_install.ps1`) installs this
   automatically via winget. Installing by hand instead: download the
   installer from https://github.com/espeak-ng/espeak-ng/releases and run
   it, or `winget install --id eSpeak-NG.eSpeak-NG` if you have winget.

4. **FFmpeg** (needed for MP3 and OGG export; WAV/FLAC work without it):
   `winget install Gyan.FFmpeg`, or download from
   https://ffmpeg.org/download.html and make sure `ffmpeg` is on your PATH.

5. **Voice models:** as of V3 you no longer have to do this by hand --
   launch the app and use **Download Voices...** next to the voice selector
   to fetch a Piper voice or the Kokoro pack. The manual commands still work
   if you prefer them or are scripting a headless setup:

   **Piper** (pick any voice from https://rhasspy.github.io/piper-samples/):

   ```powershell
   python -m piper.download_voices en_US-lessac-medium --data-dir models\piper
   ```

   **Kokoro:**

   ```powershell
   mkdir models\kokoro
   curl -L -o models\kokoro\kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
   curl -L -o models\kokoro\voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
   ```

6. **Run it:**

   ```powershell
   python run.py
   ```

### GPU acceleration

Piper and Kokoro run on `onnxruntime`, which stays CPU-only by default --
that's what `requirements.txt` installs for those two engines,
deliberately, so nobody gets a CUDA-specific download they didn't ask
for on top of Chatterbox's already-larger PyTorch install in its own
`.venv-chatterbox` (see the size heads-up near the top of this document).

- **NVIDIA GPU:** `pip uninstall onnxruntime && pip install onnxruntime-gpu`
  enables Piper's `--cuda` flag and gets picked up by Kokoro automatically.
- **Non-NVIDIA GPU (Intel/AMD, integrated or discrete):**
  `pip uninstall onnxruntime && pip install onnxruntime-directml` enables
  DirectML. **This only accelerates Kokoro** as of V3 -- `kokoro_engine.py`
  builds its own onnxruntime session with the best available provider
  (CUDA, then DirectML, then CPU) via `Kokoro.from_session()`. Piper's own
  CLI (`OHF-Voice/piper1-gpl`) was checked directly against its documented
  flags while building this, and it currently exposes `--cuda` only --
  there's no DirectML flag to wire up there yet, so Piper stays CPU-only on
  non-NVIDIA hardware until that's added upstream.

`core/device.py` detects available providers automatically (checking what
`onnxruntime` actually reports, not just whether a GPU exists) -- no
setting to change either way.

## Kokoro character presets

The **Character** dropdown next to Kokoro's voice controls (Neutral, Warm,
Calm, Energetic, Dramatic, Storyteller) blends a small amount of a second,
stylistically-matched Kokoro voice's style vector into your chosen voice,
via `kokoro_onnx`'s own `get_voice_style()`/ndarray-voice API, and nudges
speed/gain a little to match. It's a lightweight effect, not a different
voice or a different engine, and it's saved with the project like any other
TTS setting. It only shows up for Kokoro voices -- Piper has no equivalent
capability, so its voices simply don't offer the control, the same way a
voice that can't pitch-shift doesn't show a pitch slider.

## Voice cloning (Chatterbox)

Installed by default as of V4, but into its **own separate environment**,
`.venv-chatterbox`, not the main app's `.venv`. That's not a licensing
choice (Chatterbox is MIT, same as Piper's subprocess isolation is about
GPL-3.0, not this) -- it's because `chatterbox-tts` requires
`numpy<2.0.0`, while `kokoro-onnx` (already required by the main app)
requires `numpy>=2.0.2`. Those two constraints can never both be
satisfied in one environment, so Chatterbox genuinely cannot live
alongside Kokoro in `.venv`; the app talks to `.venv-chatterbox` over a
persistent background process instead (see
`tts_studio/engines/tts/chatterbox_engine.py`'s module docstring for the
full technical story).

`.venv-chatterbox` targets **Python 3.11**, not 3.12 like the main app --
that's the version chatterbox-tts itself is developed and tested against
upstream, and it sidesteps a real rough edge where Python 3.12's `venv`
stopped bundling `setuptools` by default (chatterbox's watermarking
dependency needs it and fails silently, not loudly, when it's missing --
see resemble-ai/chatterbox issue #198). That's only half the story,
though: `setuptools` itself removed the module chatterbox actually needs
(`pkg_resources`) outright as of version 82, so the installer also pins
an exact version below that (see `requirements-chatterbox.txt`) rather
than just installing "whatever `setuptools` is newest" -- 3.11 avoids one
cause of this bug, the pin avoids the other. The installer falls back to
Python 3.12 non-fatally if 3.11 can't be found or installed. `Run TTS
Studio.cmd` only *checks* for this on every launch now, without
installing or changing anything itself -- an earlier version of this
launcher tried to silently `pip install setuptools` on every start, but
that both meant reaching out to the network before you'd asked to
generate anything, and didn't even work reliably (an unpinned install is
a no-op once *any* `setuptools` is present, even a broken one). If you
ever see a "Speech generation failed" error mentioning
`PerthImplicitWatermarker` or `setuptools`, or the launcher's own note
about it on startup, just run **Install TTS Studio.cmd** again -- no
command prompt needed, it repairs `.venv-chatterbox` in place.

One of Chatterbox's own dependencies (`resemble-perth`, its watermarking
library) is published as a direct Git reference rather than a normal
package release, so installing `requirements-chatterbox.txt` needs
`git.exe` on PATH. The Windows installer checks for Git the same way it
checks for Python 3.11 -- PATH, then common install locations, then a
winget install (`Git.Git`) if it's still missing -- so this is normally
invisible; if you're installing by hand on a machine without Git, install
it first (https://git-scm.com/download/win, or `winget install --id
Git.Git`) or that one `pip install` step below will fail.

The Windows installer sets `.venv-chatterbox` up automatically -- creates
it, installs `requirements-chatterbox.txt` into it, and pre-downloads
every model tier's weights (without loading them into memory -- see
below) as one non-fatal step (see "Windows 11: simple setup" above). If
you're installing by hand, or that step failed and you want to retry it:

```powershell
py -3.11 -m venv .venv-chatterbox
.venv-chatterbox\Scripts\activate
pip install -r requirements-chatterbox.txt
deactivate
```

Once it's set up: pick **Chatterbox** from the Engine dropdown, then a
model tier from the Voice dropdown --

- **Nano** (default): the smallest, fastest tier, and the one upstream
  explicitly recommends for CPU/on-device use (their own numbers: about
  3x realtime on 8 CPU cores). Start here, especially without a GPU.
- **Turbo**: same family as Nano, larger and higher quality; best with a
  GPU, works on CPU too, just slower than Nano.
- **Original**: the base ~500M-class model this app supported before
  Nano/Turbo were added -- highest quality, slowest, heaviest.

A "Reference audio:" row appears next to the voice controls once
Chatterbox is selected (Piper/Kokoro don't show it -- same
capability-flag pattern as the pitch/character controls). Click
**Choose Clip...** and pick a short (~10 second), clean speech recording
of the voice you want to clone, or click **Clear** to use that tier's
own built-in voice instead.

Analyzing that reference clip (loading it, resampling it, running it
through Chatterbox's voice encoder) is genuinely expensive, so this app
now only does it when the reference clip actually changes, added in a
later pass. Generating several sections in a row with the same cloned
voice re-uses that analysis instead of redoing it every single section,
which used to happen unconditionally; only the first section after you
pick (or switch) a reference clip pays that cost. This also fixed a real
bug along the way: clicking **Clear** after using a custom reference clip
now correctly goes back to producing audio in that tier's own built-in
voice, which it didn't reliably do before this pass.

**Chatterbox's own native generation controls are exposed too, not just
fixed at their defaults**, tucked behind a **"Chatterbox voice
tuning"** toggle (collapsed by default -- click it to expand). What
shows up inside depends on which tier is selected, since Original and
Turbo/Nano genuinely support different things:

- **Original** shows **Expression** and **Voice Guidance** sliders.
  Expression (Chatterbox calls this "exaggeration") turns up emotional
  intensity/delivery -- higher can mean more dramatic, but pushed too
  far it can also sound less stable. Voice Guidance (Chatterbox's "CFG
  weight") controls how closely generation sticks to the reference
  voice/pacing -- lower values often work better paired with a higher
  Expression value, and vice versa, so the two are worth adjusting
  together rather than in isolation.
- **Turbo** and **Nano** don't show Expression or Voice Guidance --
  their models accept those values without erroring, but Chatterbox's
  own code silently ignores them, so this app hides them rather than
  showing controls that would quietly do nothing.
- A **Style preset** dropdown (different choices for Original vs.
  Turbo/Nano) quick-fills the sliders below it to a starting
  combination -- Natural, Calm, Storyteller, Dramatic, Consistent for
  Original; Consistent, Natural, Creative for Turbo/Nano. Picking one
  just sets numbers, the same as dragging the sliders yourself; it
  isn't saved as a named choice, so if you nudge a slider afterward the
  project simply remembers the resulting numbers. Treat these as
  starting points to fine-tune by ear, not verified "correct" values.
- An **Advanced** section, collapsed by default, exposes
  Temperature, Top-P, Top-K, Min-P, and Repetition-penalty --
  finer-grained sampling controls that affect randomness and
  repetition. Min-P only appears for Original; Top-K only appears for
  Turbo/Nano, matching what each tier's `generate()` actually accepts
  behind the scenes. Most people can leave this section closed; it's
  there for tuning once you already know you want to adjust it.

This is the most control-dense panel in the app, and a later pass
tidied it up after a real user found the app "cluttered and busy." The
first attempt at that (extra spacing and bold sub-headings, nothing
hidden) actually made things worse for that same user -- this panel and
the rest of the window share one fixed-size, non-scrolling area, so
extra height spent here came straight out of the source-text box and
the sections table below, shrinking both. The fix that actually
shipped instead collapses Expression/Voice Guidance/Style preset behind
the "Chatterbox voice tuning" toggle above, off by default -- the same
click-to-expand pattern "Advanced sampling controls" already used, and
it makes this panel *smaller* by default than before any of this,
rather than just rearranging the same amount of visible content.

(An earlier version of this build also had a row of Turbo/Nano-only
**sound tag** insert buttons above the source text box --
`[laugh]`/`[chuckle]`/`[cough]`, documented in Chatterbox's own README
as real, working tags. They were removed after testing showed
`[laugh]`/`[chuckle]` didn't actually produce a laugh/chuckle sound in
practice; all three buttons came out together rather than leaving one
untested tag behind on its own.)

**The model for whichever tier you're using loads once and stays loaded**
for as long as Chatterbox stays selected, not once per section -- an
earlier version of this app restarted the whole process (and reloaded
the full model) for every single section, which on CPU meant minutes of
dead time before each section even started generating; that's fixed now.
Switching to a different engine (or closing the app) shuts the loaded
model down; switching to a different Chatterbox tier mid-session swaps
which one is loaded, one at a time, rather than keeping several in memory
at once.

**That very first load, though, is still genuinely slow on CPU** --
anywhere from under a minute to several minutes, longer for "Original"
than "Nano" -- and has no progress bar of its own while it happens. The
status area now says so explicitly ("Loading the Chatterbox... model for
the first time this session...") instead of showing the normal
"Generating audio..." message unchanged for that whole time, which a
real user reasonably mistook for a frozen app before this was added. If
you see that specific message sitting there for a while, it's working;
switching tiers mid-session brings it back too, since only one tier's
model stays resident at a time.

Troubleshooting: use the **Diagnose...** button next to the Engine/Voice
dropdowns to run a real, independent check -- it loads a model and
generates a short test clip in a separate one-off process (not the
long-running one you're using for real generation), and reports Python/
Chatterbox/Torch versions, CUDA availability, the actual installed
`setuptools` version and whether the setuptools/perth issue above is
present, what's already cached locally, and exactly what happened when
it tried to generate, all without needing a command prompt. Running
Diagnose shuts down the long-running Chatterbox process first (so the two
can't both have a model loaded in memory at once) -- your next real
generation afterward will show the "loading for the first time" message
again as a result, which is expected, not a sign anything's wrong.

**Speed and Pitch now work for Chatterbox too**, added in a later pass --
worth knowing how, since it's different from how Expression/Voice
Guidance/Advanced sampling above work. Chatterbox's own models have no
speed or pitch parameter at all, unlike Piper/Kokoro (which handle Speed
as part of their own synthesis); this app adds both afterward instead,
by running the finished clip through ffmpeg (a standard tempo change for
Speed, a pitch-shift-without-changing-duration trick for Pitch). Because
that's a DSP effect rather than something Chatterbox itself is doing,
the usable range is narrower than Piper/Kokoro's Speed slider: **0.75x to
1.50x** for Speed and **-4 to +4 semitones** for Pitch, versus their wider
0.5x-2.0x. Push either far enough and you'll start hearing it -- a
slight warble on Pitch, a "sped-up recording" quality on Speed -- well
before you'd notice anything on a Piper/Kokoro voice, which is exactly
why the range is capped tighter here. Leaving both at their defaults
(1.00x, 0 semitones) skips this processing entirely, so it costs nothing
if you don't touch them, and it does mean ffmpeg needs to be on your
PATH the moment you do -- the same ffmpeg this app already needs for
MP3/OGG export.

A **"Normalise final audio"** checkbox also appeared near Export, for
any engine, not just Chatterbox: check it and the joined preview/export
clip gets scaled so its loudest moment sits just under full volume.
Useful if some sections ended up quieter than others -- a cloned voice
whose reference clip was recorded softer than Chatterbox's own built-in
voice, for instance. It's a simple peak-based normalization (matching
the loudest sample), not full loudness normalization, and it applies
once to the whole joined clip rather than to each section individually,
so relative loudness between sections is preserved -- only the overall
level moves.

A few honest limitations, worth knowing before you rely on this:

- English only in this build. Chatterbox also ships a Multilingual
  variant (23 languages), which isn't wired up yet -- see
  `ARCHITECTURE.md` section I for why.
- The reference clip's file path is saved with your project, but the
  clip itself is **not** copied into the project folder the way
  generated audio is. Moving a project to another computer (or sharing
  it) means bringing that reference clip along separately if you want to
  regenerate with the same cloned voice there.
- A GPU speeds this up a lot; it still runs on CPU (Nano is the tier
  built for that), just slower. `.venv-chatterbox` picks CUDA
  automatically if it's available there (checked independently of
  `onnxruntime`/`core/device.py`, which only ever looks at the main
  `.venv`'s providers).

## Project layout

See `ARCHITECTURE.md` section E for the full annotated tree and section D
for why each dependency was chosen over the alternatives that were
evaluated (Piper vs. Kokoro vs. XTTS vs. Chatterbox vs. F5-TTS vs.
Qwen3-TTS; Argos vs. LibreTranslate vs. NLLB vs. Marian/OPUS-MT).

A saved project is a folder you can move, back up, or reopen later:

```
MyProject/
    project.json          settings, target language, per-section status
    source.txt             full source text (read-only mirror)
    translation.txt         concatenated translations (read-only mirror)
    audio/
        section_0000.wav
        section_0001.wav
        ...
```

One exception to "fully self-contained": if you used Chatterbox's voice
cloning, `project.json` records the reference clip's file path but does
not copy the clip itself into this folder -- see "Voice cloning
(Chatterbox)" above.

## Licensing notes (short version -- see ARCHITECTURE.md section I for the full picture)

- This app's own code: MIT (suggested -- pick what you prefer).
- **Piper's engine code is GPL-3.0** (the actively maintained
  OHF-Voice/piper1-gpl fork; the old MIT rhasspy/piper is archived and
  unmaintained). This app runs Piper as a subprocess rather than an
  in-process import specifically to keep GPL-3.0 out of this
  application's own process -- see the docstring in
  `tts_studio/engines/tts/piper_engine.py`.
- **Kokoro's weights are Apache-2.0** -- fully permissive, commercial
  use is explicitly welcomed by the model card.
- **Argos Translate is MIT/CC0** -- fully permissive.
- **Chatterbox's code and model weights are both MIT** -- fully
  permissive; verified against the repo's `LICENSE` file and the
  `ResembleAI/chatterbox` Hugging Face model card directly rather than
  assumed. Installed by default as of V4, into its own environment (see
  "Voice cloning (Chatterbox)" above) for dependency reasons, not
  licensing ones.
- Individual Piper *voices* can carry their own licenses (mostly
  permissive, a few more restrictive) -- check each voice's
  `MODEL_CARD` before shipping a product built on it.
